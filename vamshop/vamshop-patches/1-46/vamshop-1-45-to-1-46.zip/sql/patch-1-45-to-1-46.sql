ALTER TABLE extra_fields MODIFY fields_input_type int(11) default '0' not null;
ALTER TABLE extra_fields ADD fields_input_value text NOT NULL AFTER fields_input_type;
