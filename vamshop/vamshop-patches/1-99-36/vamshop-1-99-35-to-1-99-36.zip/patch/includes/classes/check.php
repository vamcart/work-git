<?php
/* -----------------------------------------------------------------------------------------
   VamShop - http://vamshop.com
   -----------------------------------------------------------------------------------------
   Copyright (c) 2014 VamSoft Ltd.
   License - http://vamshop.com/license.html
   ---------------------------------------------------------------------------------------*/
class check
{

	public $demo_period_days = 14;	

    function __construct() {
    }
    	
    public function check()
    {

    }

    public function get_info()
    {
     	if($this->check_domain(LICENSE) != 'true') {
    	
		$config_filename = DIR_WS_INCLUDES . '/configure.php';
		if(is_readable($config_filename)) {
			if (filesize($config_filename) > 0) {
    			$current_install = filemtime($config_filename);  
    			$demo_period = $current_install + (bindec(1110) * 24 * 60 * 60);
    			$current_date = time();  
    			if ($current_date <= $demo_period) {
    			} else {
    			//echo 'Trial version of VamShop is over. Purchase unlimited version of VamShop at <a href="http://vamshop.ru/vamshop.html">http://vamshop.ru/vamshop.html</a>';
    			//die();
    			}
    		}
    	}
    	} else {
    	}
    }

	public function get ($licenseID)
	{
    	$host = $this->check_host();
        if(strpos($host,'www.') !== FALSE) $host = str_replace('www.','',$host);
    	return file_get_contents(CheckServer.'check/'.$licenseID.'/'.$host);
	}

	public function check_domain ($licenseID)
	{
    	$host = $this->check_host();
		if(strpos($host,'www.') !== FALSE) $host = str_replace('www.','',$host);
		$cache_file = CACHE . 'persistent' . DS . $host;
		if (file_exists($cache_file) && (filemtime($cache_file) > (time() - 7 * 24 * 60 * 60 ))) {
			$domain = file_get_contents($cache_file);
		} else {
			$domain = file_get_contents(CheckServer.'check/domain/'.$licenseID.'/'.$host);
			file_put_contents($cache_file, $domain, LOCK_EX);
		}
		
		if ($domain == '') $domain = 'false';	
		
    	return $domain;
	}

	public function get_latest_update_version()
	{
    	$host = $this->check_host();
        if(strpos($host,'www.') !== FALSE) $host = str_replace('www.','',$host);
			App::import('Model', 'License');
	    	$License = new License();
   	     $this->data = $License->find('first');
    	return file_get_contents(CheckServer.'check/update/'.$this->data['License']['licenseKey'].'/'.$host);
	}

	public function get_list_update_version($current_version)
	{
    	$host = $this->check_host();
        if(strpos($host,'www.') !== FALSE) $host = str_replace('www.','',$host);
			App::import('Model', 'License');
	   	$License = new License();
			$this->data = $License->find('first');
    	return file_get_contents(CheckServer.'check/update/list/'.$this->data['License']['licenseKey'].'/'.$host.'/'.$current_version);
	}

	public function get_update_archive($version)
	{
		$host = $this->check_host();
		if(strpos($host,'www.') !== FALSE) $host = str_replace('www.','',$host);
		App::import('Model', 'License');
    	$License = new License();
		$this->data = $License->find('first');
		$origFileName = '../tmp/updates/'.$version.'.zip';

		$fp = @fopen(CheckServer.'check/update/get/'.$this->data['License']['licenseKey'].'/'.$host.'/'.$version, 'rb');
		$fd = @fopen($origFileName, 'w');
		if ($fp && $fd) {
			while (!feof($fp)) {
				$st = fread($fp, 4096);
				fwrite($fd, $st);
			}
		}
		@fclose($fp);
		@fclose($fd);
	}

	public function check_host()
	{
		$host = $host1 = getenv('HTTP_HOST');
		$host2 = getenv('HTTP_HOST');
		if(function_exists('apache_getenv'))
			$host3 = apache_getenv('HTTP_HOST');
		else
			$host3 = $host1;

		if(!($host1 == $host2 && $host1 == $host3))
			return false;
		else
			return $host;
	}

}
?>