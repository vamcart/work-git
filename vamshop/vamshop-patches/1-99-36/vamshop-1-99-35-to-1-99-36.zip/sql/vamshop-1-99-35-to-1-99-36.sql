ALTER TABLE orders ADD tracking_code varchar(255);
