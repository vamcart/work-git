alter table customers add customers_personal_discount decimal(4,2);

CREATE TABLE customers_to_manufacturers_discount (
  discount_id int(11) NOT NULL auto_increment,
  customers_id int(11) default NULL,
  manufacturers_id int(11) default NULL,
  discount decimal(4,2) default NULL,
  PRIMARY KEY  (discount_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

