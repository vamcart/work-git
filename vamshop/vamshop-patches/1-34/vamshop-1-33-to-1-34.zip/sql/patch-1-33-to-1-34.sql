
DROP TABLE IF EXISTS customers_status_orders_status;
CREATE TABLE customers_status_orders_status (
  customers_status_id int(11) default '0' not null ,
  orders_status_id int(11) default '0' not null
);

ALTER TABLE `customers_status` MODIFY `customers_status_accumulated_limit` decimal(15,4) DEFAULT '0';
