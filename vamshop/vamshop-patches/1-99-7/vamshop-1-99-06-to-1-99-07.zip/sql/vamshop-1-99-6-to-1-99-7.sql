SET SQL_MODE = "";

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('SOCIAL_LOGIN', 'true', 1, 39, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
update configuration set configuration_value = "False" where configuration_key = "SPECIFICATIONS_BOX_COMPARISON";