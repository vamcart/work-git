
ALTER TABLE `content_manager` ADD `content_meta_title` TEXT;
ALTER TABLE `content_manager` ADD `content_meta_description` TEXT;
ALTER TABLE `content_manager` ADD `content_meta_keywords` TEXT;
