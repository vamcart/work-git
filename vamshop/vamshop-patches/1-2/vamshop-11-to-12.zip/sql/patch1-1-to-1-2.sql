DROP TABLE IF EXISTS customers_status_orders_status;
CREATE TABLE customers_status_orders_status (
  customers_status_id int(11) default '0' not null ,
  orders_status_id int(11) default '0' not null ,
  PRIMARY KEY  (customers_status_id)
);

ALTER TABLE customers_status ADD customers_status_accumulated_limit decimal(4,2) DEFAULT '0';

INSERT INTO configuration (configuration_id,  configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES   ('', 'MAX_UPLOADED_FILESIZE', '524288', '25', '17', NULL , '0000-00-00 00:00:00', NULL , NULL);

ALTER TABLE content_manager ADD content_url text NOT NULL;
