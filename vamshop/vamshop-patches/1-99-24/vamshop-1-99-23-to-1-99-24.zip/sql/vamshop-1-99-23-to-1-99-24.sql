SET SQL_MODE = "";
ALTER TABLE faq ADD `show_popular_products` TINYINT(1) NOT NULL DEFAULT '0';
ALTER TABLE faq ADD `show_discount_products` TINYINT(1) NOT NULL DEFAULT '0';

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DARK_THEME', 'true', 1, 68, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
