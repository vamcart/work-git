ALTER TABLE `products` ADD `products_quantity_min` INT(4) NOT NULL;
ALTER TABLE `products` ADD `products_quantity_max` INT(4) NOT NULL;

ALTER TABLE admin_access ADD select_special INT( 1 ) NOT NULL;
UPDATE admin_access SET select_special = 1 WHERE customers_id = 1 LIMIT 1;
