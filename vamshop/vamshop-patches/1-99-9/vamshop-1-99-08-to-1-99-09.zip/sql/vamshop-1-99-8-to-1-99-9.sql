SET SQL_MODE = "";

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('ENABLE_COOKIE_ALERT', 'false', 1, 40, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
