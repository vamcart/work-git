CREATE INDEX manufacturers_id ON products(manufacturers_id);
CREATE INDEX specification ON products_specifications(specification,products_specification_id);
