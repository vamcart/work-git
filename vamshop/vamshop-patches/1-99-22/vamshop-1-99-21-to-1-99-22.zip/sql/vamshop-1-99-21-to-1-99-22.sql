SET SQL_MODE = "";

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('SPECIFICATIONS_FILTERS_HIDE_EMPTY_FILTERS_GROUP', 'True', 1610, 133, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

DROP TABLE IF EXISTS articles_to_categories;
CREATE TABLE articles_to_categories (
  articles_id int NOT NULL,
  categories_id int NOT NULL,
  PRIMARY KEY (articles_id,categories_id),
  KEY idx_categories_id (categories_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS articles_to_products;
CREATE TABLE articles_to_products (
  articles_id int NOT NULL,
  products_id int NOT NULL,
  PRIMARY KEY (articles_id,products_id),
  KEY idx_products_id (products_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS faq_to_categories;
CREATE TABLE faq_to_categories (
  faq_id int NOT NULL,
  categories_id int NOT NULL,
  PRIMARY KEY (faq_id,categories_id),
  KEY idx_categories_id (categories_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS faq_to_products;
CREATE TABLE faq_to_products (
  faq_id int NOT NULL,
  products_id int NOT NULL,
  PRIMARY KEY (faq_id,products_id),
  KEY idx_products_id (products_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS latest_news_to_categories;
CREATE TABLE latest_news_to_categories (
  news_id int NOT NULL,
  categories_id int NOT NULL,
  PRIMARY KEY (news_id,categories_id),
  KEY idx_categories_id (categories_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS latest_news_to_products;
CREATE TABLE latest_news_to_products (
  news_id int NOT NULL,
  products_id int NOT NULL,
  PRIMARY KEY (news_id,products_id),
  KEY idx_products_id (products_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS specification_filters_statistics;
CREATE TABLE IF NOT EXISTS specification_filters_statistics (
  `specifications_id` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `specification_value_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS specification_filters_statistics_agregate;
CREATE TABLE IF NOT EXISTS specification_filters_statistics_agregate (
  `specifications_id` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `specification_value_id` int(11) NOT NULL DEFAULT '0',
  `date_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
