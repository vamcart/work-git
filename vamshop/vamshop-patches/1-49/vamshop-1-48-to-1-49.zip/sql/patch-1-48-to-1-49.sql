ALTER TABLE categories ADD yml_enable TINYINT(1) DEFAULT '1' NOT NULL;
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('YML_USE_CDATA', 'true', '23', '13', NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
ALTER TABLE `manufacturers_info` ADD `manufacturers_description` VARCHAR(255) NOT NULL;
