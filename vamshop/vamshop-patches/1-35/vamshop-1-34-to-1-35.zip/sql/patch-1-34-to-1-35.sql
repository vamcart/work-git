INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES   ('MAX_DISPLAY_CART', '50', 3, 26, 'NULL', '', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES   ('MAX_DISPLAY_SHORT_DESCRIPTION', '80', 3, 27, 'NULL', '', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES   ('ENABLE_TABS', 'true', 1, 31, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

update languages set language_charset = 'utf-8' where language_charset = 'windows-1251';

ALTER TABLE customers_status MODIFY customers_status_discount decimal(15,4) DEFAULT '0' NOT NULL;