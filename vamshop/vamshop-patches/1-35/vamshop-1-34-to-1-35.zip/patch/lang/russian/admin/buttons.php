<?php
/* --------------------------------------------------------------
   $Id: buttons.php 1125 2007-02-07 17:36:57 VaM $

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   --------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(categories.php,v 1.22 2002/08/17); www.oscommerce.com 
   (c) 2003	 nextcommerce (categories.php,v 1.10 2003/08/14); www.nextcommerce.org
   (c) 2004	 xt:Commerce (categories.php,v 1.10 2003/08/14); xt-commerce.com

   Released under the GNU General Public License 
   --------------------------------------------------------------*/

// buttons
define('BUTTON_REVERSE_SELECTION', 'Отметить всё/Снять отметку');
define('BUTTON_SWITCH_PRODUCTS', 'Только товары');
define('BUTTON_SWITCH_CATEGORIES', 'Только категории');
define('BUTTON_NEW_CATEGORIES', 'Новая категория');
define('BUTTON_NEW_PRODUCTS', 'Новый товар');
define('BUTTON_COPY', 'Копировать');
define('BUTTON_BACK', 'Вернуться');
define('BUTTON_CANCEL', 'Отменить');
define('BUTTON_EDIT', 'Редактировать');
define('BUTTON_DELETE', 'Удалить');
define('BUTTON_MOVE', 'Переместить');
define('BUTTON_SAVE', 'Сохранить');
define('BUTTON_STATUS_ON', 'Включить');
define('BUTTON_STATUS_OFF', 'Выключить');
define('BUTTON_EDIT_ATTRIBUTES', 'Атрибуты');
define('BUTTON_INSERT', 'Добавить');
define('BUTTON_UPDATE', 'Обновить');
define('BUTTON_EXPORT', 'Экспорт');
define('BUTTON_REVIEW_APPROVE', 'Одобрить');
define('BUTTON_SEND_EMAIL', 'Отправить E-Mail');
define('BUTTON_SEND_COUPON', 'Отправить купон');
define('BUTTON_INVOICE', 'Счёт');
define('BUTTON_PACKINGSLIP', 'Накладная');
define('BUTTON_REMOVE_CC_INFO', 'Удалить информацию о карточке');
define('BUTTON_AFTERBUY_SEND', 'Отправить');
define('BUTTON_NEW_NEWSLETTER', 'Новая рассылка');
define('BUTTON_RESET', 'Сбросить');
define('BUTTON_STATUS', 'Статус покупателя');
define('BUTTON_ACCOUNTING', 'Доступ в админку');
define('BUTTON_ORDERS', 'Заказы');
define('BUTTON_EMAIL', 'Отправить E-Mail');
define('BUTTON_IPLOG', 'IP-Log');
define('BUTTON_NEW_ORDER', 'Создать заказ');
define('BUTTON_CREATE_ACCOUNT', 'Создать покупателя');
define('BUTTON_SEARCH', 'Поиск');
define('BUTTON_PRODUCT_OPTIONS', 'Атрибуты');
define('BUTTON_PREVIEW', 'Предварительные просмотр');
define('BUTTON_MODULE_REMOVE', 'Удалить');
define('BUTTON_MODULE_INSTALL', 'Установить');
define('BUTTON_START', 'Старт');
define('BUTTON_NEW_CONTENT', 'Новая страница');
define('BUTTON_BACKUP', 'Создать копию');
define('BUTTON_RESTORE', 'Восстановить');
define('BUTTON_NEW_BANNER', 'Новый баннер');
define('BUTTON_UPLOAD', 'Загрузить');
define('BUTTON_IMPORT', 'Импорт');
define('BUTTON_EXPORT', 'Экспорт');
define('BUTTON_CONFIRM', 'Подтвердить');
define('BUTTON_REPORT', 'Отчёт');
define('BUTTON_RELEASE', 'Активировать');
define('BUTTON_NEW_LANGUAGE', 'Новый язык');
define('BUTTON_NEW_COUNTRY', 'Новая страна');
define('BUTTON_NEW_CURRENCY', 'Новая валюта');
define('BUTTON_NEW_ZONE', 'Новый регион');
define('BUTTON_DETAILS', 'Настроить');
define('BUTTON_NEW_TAX_CLASS', 'Новый налог');
define('BUTTON_NEW_TAX_RATE', 'Новая ставка налога');
define('BUTTON_SEND', 'Отправить');

?>