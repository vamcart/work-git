<?php
/**
 * DBConverter2UTF8
 *
 * @package eCommerce-Service
 * @copyright Copyright 2004-2007, Andrew Berezin eCommerce-Service.com
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DBConverter2UTF8.php, v 2.0.1 16.10.2007 14:47 Andrew Berezin $
 */
?>
<div class="wrap">
  <h1>UTF-8 Database Converter</h1>
<?php
if (!isset($_POST['submit']) ) {
?>
    <p>Before proceed with the final step please make a complete backup of your database.<br/>
    <form action="" method="post" id="utf8-db-converter">
      <input type="submit" name="submit" value="Start converting &raquo;" />
    </form>
<?php
} else {
  require('includes/configure.php');
  UTF8_DB_Converter(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE);
?>
    <p><strong>The database has been succesfully converted to UTF-8</strong>. <a href="<?php echo HTTP_SERVER; ?>" target="_blank">View site &raquo;</a></p>
<?php
}
?>
  </div>
<?php
function UTF8_DB_Converter($dbServer, $dbUser, $dbPassword, $dbDatabase) {
  global $dbStat;
  $time_start = microtime_float();
  @set_time_limit(0);
  $dbStat = array();

  echo 'Connecting to DB server ' . $dbServer . '<br />' . "\n";
  if (!$link_id = mysql_connect($dbServer, $dbUser, $dbPassword)) {
    echo 'Error connecting to mySQL: ' . mysql_errno() . ': ' . mysql_error() . '<br />' . "\n";
    die;
  }
  echo 'Select DB: ' . $dbDatabase . '<br />' . "\n";
  if (!mysql_select_db($dbDatabase)) {
    echo 'Error selecting data base: ' . mysql_errno() . ': ' . mysql_error() . '<br />' . "\n";
    die;
  }

  $mySQLversion = mysql_get_server_info();
  echo 'mySQL Server version ' . $mySQLversion . '<br />' . "\n";

  preg_match("/^(\d+)\.(\d+)\.(\d+)/", mysql_get_server_info(), $m);
  $mySQLversionClear = sprintf("%d%02d%02d", $m[1], $m[2], $m[3]);
  if ($mySQLversionClear <= 40101) {
    die('This version not supported!!!');
  }

  $query = db_query("SHOW CHARACTER SET LIKE 'utf8'");
  if(!$charset = mysql_fetch_assoc($query)) {
    die("Charset 'utf8' not found!!!");
  }

  $totalProcessingTables = $totalConvertedDataTables = $totalConvertedTables = 0;
  $query_tables = db_query("SHOW TABLE STATUS FROM " . $dbDatabase);
  while($table = mysql_fetch_array($query_tables, MYSQL_ASSOC)) {
    $totalProcessingTables++;
    echo "Process table <strong>" . $table['Name'] . '</strong> ' . ($table['Comment'] != '' ? ' (' . $table['Comment'] . ')' : '') . ' updated ' . $table['Update_time'] . ', collation <em>' . $table['Collation'] . '</em>, rows ' . $table['Rows'] . ', data length ' . $table['Data_length'] . '<br />' . "\n";
    @ob_flush();flush();
    if($table['Collation'] == 'utf8_general_ci') {
//      echo 'Already in utf8 - skipping...' . '<br />' . "\n";
//      continue;
    }
    $totalConvertedTables++;

    $query_fields = db_query("SHOW FULL columns FROM `" . $table['Name'] . "`");
    $tables_fields = array();
    while($fields = mysql_fetch_assoc($query_fields)) {
//      echo '<pre>';var_dump($fields);echo '</pre>';
      if (preg_match('@(char)|(text)$@', $fields['Type']) && $fields['Collation'] != 'utf8_general_ci') {
        @list($fieldType, $fieldLeng) = explode('(', rtrim($fields['Type'], ')'));
        switch($fieldType) {
          case 'longtext':
          case 'mediumtext':
            $fields['NewType'] = 'longtext';
            break;
          case 'text':
            $fields['NewType'] = 'mediumtext';
            break;
          case 'tinytext':
            $fields['NewType'] = 'text';
            break;
          case 'varchar':
            $fields['NewType'] = 'varchar(' . max($fieldType*2, 255) . ')';
            break;
          case 'char':
            $fields['NewType'] = 'char(' . max($fieldType*2, 255) . ')';
            break;
        }
//        echo $table['Name'] . ':' . $fields['Field'] . ' ' . $fields['Type'] . ' ==> ' . $fields['NewType'] . '<br />' . "\n";
        $tables_fields[$fields['Field']] = $fields['NewType'] . ' ' .
                                           ($fields['Null'] == 'YES' ? 'NULL ' : 'NOT NULL ' ) .
                                           (!is_null($fields['Default']) ? "DEFAULT '" . mysql_escape_string($fields['Default']) . "'" : "");
      }
    }

    echo 'Alter table structure... ';
    db_query("ALTER TABLE `" . $table['Name'] . "` CONVERT TO CHARACTER SET utf8");
    db_query("ALTER TABLE `" . $table['Name'] . "` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci");

    if(sizeof($tables_fields) > 0) {
    	echo 'Convert data...' . '<br />' . "\n";
    	@ob_flush();flush();
      foreach($tables_fields as $field => $field_options) {
        db_query("ALTER TABLE `" . $table['Name'] . "` MODIFY `" . $field . "` " . $field_options);
      }
      $totalConvertedDataTables++;
    } else {
      echo "No char/text/enum/set fields found. Skip converting data in table..." . '<br />' . "\n";
      @ob_flush();flush();
    }
    db_query("OPTIMIZE TABLE `" . $table['Name'] . "`");
  }
  db_query("ALTER DATABASE " . $dbDatabase . " CHARACTER SET utf8 COLLATE utf8_general_ci");

  mysql_close($link_id);

  $total_time = microtime_float() - $time_start;
  echo '================================================================<br />' . "\n";
  echo 'Total processing tables ' . $totalProcessingTables . ', converted tables ' . $totalConvertedTables . ', data converted tables ' . $totalConvertedDataTables . '. Execution time ' . timefmt($total_time) . '<br />' . "\n";
  echo 'DB statistic: ';
  foreach($dbStat as $sql_command => $time) {
  	echo '&nbsp;' . $sql_command . ': ' . sizeof($time) . ' ' . timefmt(array_sum($time)) . '; ';
  }
  echo '<br />' . "\n";

  return true;
}
function db_query($sql) {
  global $link_id;
  global $dbStat;
	$st = microtime_float();
  if(!$ret = mysql_query($sql)) {
    echo 'Error: ' . mysql_errno() . ': ' . mysql_error() . '<br />' . "\n";
    echo 'SQL: ' . $sql . '<br />' . "\n";
  }
  $sql_command = explode(' ', substr($sql, 0, 16));
  $sql_command = strtolower($sql_command[0]);
  $dbStat[$sql_command][] = microtime_float()-$st;
  return($ret);
}

function microtime_float() {
   list($usec, $sec) = explode(" ", microtime());
   return ((float)$usec + (float)$sec);
}

function timefmt($s) {
  $m = floor($s/60);
  $s = $s - $m*60;
  $h = floor($m/60);
  $m = $m - $h*60;
  if($h > 0) {
    $tfmt = $h . ":" . $m . ":" . number_format($s, 4);
  } elseif($m > 0) {
    $tfmt = $m . ":" . number_format($s, 4);
  } else {
    $tfmt = number_format($s, 4);
  }
  return $tfmt;
}
?>
