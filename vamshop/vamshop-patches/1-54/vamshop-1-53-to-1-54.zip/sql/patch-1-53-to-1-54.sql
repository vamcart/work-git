INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DISPLAY_START_PAGE', 'true', '24', '9', NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('XSELL_CART', 'false',  17, 19, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

ALTER TABLE admin_access ADD select_featured INT( 1 ) NOT NULL;
UPDATE admin_access SET select_featured = 1 WHERE customers_id = 1 LIMIT 1;
