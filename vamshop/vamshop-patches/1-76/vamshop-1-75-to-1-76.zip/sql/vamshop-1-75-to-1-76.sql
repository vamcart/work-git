ALTER TABLE admin_access ADD product_labels INT( 1 ) NOT NULL;
UPDATE admin_access SET product_labels = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE `products` ADD `label_id` int(10) AFTER `manufacturers_id`;

DROP TABLE IF EXISTS product_labels;
CREATE TABLE `product_labels` (
  `id` int(10) auto_increment,
  `default` tinyint(4),
  `name` varchar(255) collate utf8_unicode_ci,
  `alias` varchar(255) collate utf8_unicode_ci,
  `html` varchar(255) collate utf8_unicode_ci,
  `active` tinyint(4) default '1',
  `sort_order` int(3),
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `product_labels` (`id`, `default`, `name`, `alias`, `html`, `active`, `sort_order`) VALUES 
(1, 1, 'Новинка', 'new', '', 1, 1),
(2, 0, 'Хит', 'hit', '', 1, 2),
(3, 0, 'Распродажа', 'sale', '', 1, 3);

INSERT INTO content_manager VALUES (NULL, 0, 0, '', 1, '404', '404', 'Не найдены товары, соответствующие Вашему запросу.\r\n\r\n<form name="new_find" id="new_find" action="advanced_search_result.php" method="get">\r\n<span class="bold">Воспользуйтесь поиском!</span>\r\n<br />\r\n<br />\r\n<!-- форма -->\r\n<fieldset class="form">\r\n<legend>Ключевые слова:</legend>\r\n<p><input type="text" name="keywords" size="30" maxlength="30" /></p>\r\n<p><span class="button"><button type="submit"><img src="images/icons/buttons/search.png" alt="Поиск" title=" Поиск " width="12" height="12" /> Поиск</button></span></p>\r\n</fieldset>\r\n<!-- /форма -->\r\n</form>', '', 0, 0, '', 0, 12, 1, '', '', '', '404.html');
