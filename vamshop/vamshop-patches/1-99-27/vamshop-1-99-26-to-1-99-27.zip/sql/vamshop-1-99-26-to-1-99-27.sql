SET SQL_MODE = "";

DROP TABLE IF EXISTS markers_geocod;
CREATE TABLE markers_geocod (
  id int(11) NOT NULL auto_increment,
  name varchar(300) NOT NULL,
  address varchar(300) NOT NULL,
  lat varchar(255) NOT NULL,
  lng varchar(255) NOT NULL,
  telephon varchar(60) NOT NULL,
  city varchar(255) NOT NULL,
  company varchar(255) NOT NULL,
  worktime varchar(100) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS block;
CREATE TABLE block (
   id int(11) NOT NULL AUTO_INCREMENT,
   url text,
   date_added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   last_modified datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   status tinyint(1) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

ALTER TABLE admin_access ADD block INT( 1 ) NOT NULL;
UPDATE admin_access SET block = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE categories ADD google_category_id varchar(255);