SET SQL_MODE = "";

ALTER TABLE admin_access ADD tags INT( 1 ) NOT NULL;
UPDATE admin_access SET tags = 1 WHERE customers_id = 1 LIMIT 1;

DROP TABLE IF EXISTS tags;
CREATE TABLE tags (
   tags_id int(11) NOT NULL AUTO_INCREMENT,
   tags_name text,
   tags_title text,
   tags_description text,
   tags_url varchar(255) NOT NULL,
   tags_mainpage tinyint(1) DEFAULT '0' NOT NULL,
   tags_head_title text,
   tags_head_desc text,
   tags_head_keys text,
   date_added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   language int(11) NOT NULL default '1',
   status tinyint(1) DEFAULT '0' NOT NULL,
   tags_page_url varchar(255),
   sort_order int(4) NOT NULL default '0',
   likes int(3) DEFAULT "0" NOT NULL,
   dislikes int(3) DEFAULT "0" NOT NULL,
   PRIMARY KEY (tags_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS tags_to_categories;
CREATE TABLE tags_to_categories (
  tags_id int NOT NULL,
  categories_id int NOT NULL,
  PRIMARY KEY (tags_id,categories_id),
  KEY idx_categories_id (categories_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS tags_to_products;
CREATE TABLE tags_to_products (
  tags_id int NOT NULL,
  products_id int NOT NULL,
  PRIMARY KEY (tags_id,products_id),
  KEY idx_products_id (products_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MAX_DISPLAY_TAGS', '20', 3, 29, 'NULL', '', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MAX_DISPLAY_TAGS_PAGE', '20', 3, 30, 'NULL', '', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MAX_DISPLAY_TAGS_DESCRIPTION', '150', 3, 31, 'NULL', '', NULL, NULL);

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MAX_DISPLAY_REVIEW_TEXT', '100', 3, 28, 'NULL', '', NULL, NULL);

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_DAYS', '1', 1, 47, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_HAVE', '1', 1, 48, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS', '2', 1, 49, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_DAYS_2', '7', 1, 50, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_HAVE_2', '2', 1, 51, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_2', '3', 1, 52, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_DAYS_3', '3', 1, 53, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_HAVE_3', '4', 1, 54, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_3', '5', 1, 55, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_DAYS_4', '14', 1, 56, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_HAVE_4', '5', 1, 57, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_4', '6', 1, 58, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_MINUTES_5', '10', 1, 59, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_HAVE_5', '1', 1, 60, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_5', '2', 1, 61, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_MINUTES_6', '60', 1, 62, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_HAVE_6', '2', 1, 63, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MODULE_ORDER_STATUS_6', '3', 1, 64, NULL, '0000-00-00 00:00:00', 'vam_get_order_status_name', 'vam_cfg_pull_down_order_statuses(');

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('SIMILAR_PRODUCTS', 'true', 1, 65, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('SIMILAR_PRODUCTS_FULL', '20', 1, 66, 'NULL', '', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('SIMILAR_PRODUCTS_RAND', '150', 1, 67, 'NULL', '', NULL, NULL);
