SET SQL_MODE = "";

ALTER TABLE `categories` ADD `guid` TEXT NOT NULL AFTER `categories_id`;
ALTER TABLE `products` ADD `guid` TEXT NOT NULL AFTER `products_id`;
ALTER TABLE `orders` ADD `guid` TEXT NOT NULL AFTER `orders_id`;
ALTER TABLE `products_attributes` ADD `guid` TEXT NOT NULL AFTER `products_attributes_id`;
ALTER TABLE `products_attributes_download` ADD `guid` TEXT NOT NULL AFTER `products_attributes_id`;
ALTER TABLE `orders_products` ADD `guid` TEXT NOT NULL AFTER `orders_products_id`;
ALTER TABLE `orders_products_attributes` ADD `guid` TEXT NOT NULL AFTER `orders_products_attributes_id`;
ALTER TABLE `orders_products_download` ADD `guid` TEXT NOT NULL AFTER `orders_products_download_id`;

INSERT INTO configuration_group VALUES ('100', 'CG_1C_EXCHANGE', '1С:Предприятие', 'Двусторонний обмен заказами, ценами, остатками, номенклатурой между VamShop и 1С:Предприятие.', '1', '1');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('ENABLE_1C_EXCHANGE', 'false', '100', '1', now(), now(), NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

ALTER TABLE `author_reviews_description` ADD `reviews_answer` TEXT NOT NULL AFTER `reviews_text`;
ALTER TABLE `article_reviews_description` ADD `reviews_answer` TEXT NOT NULL AFTER `reviews_text`;
ALTER TABLE `company_reviews_description` ADD `reviews_answer` TEXT NOT NULL AFTER `reviews_text`;
ALTER TABLE `site_reviews_description` ADD `reviews_answer` TEXT NOT NULL AFTER `reviews_text`;
ALTER TABLE `reviews_description` ADD `reviews_answer` TEXT NOT NULL AFTER `reviews_text`;
