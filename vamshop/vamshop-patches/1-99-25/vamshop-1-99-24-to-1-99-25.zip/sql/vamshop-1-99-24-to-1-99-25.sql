SET SQL_MODE = "";

DROP TABLE IF EXISTS reviews_images;
CREATE TABLE `reviews_images` (
  image_id int(10) auto_increment,
  reviews_id int(10) NOT NULL,
  products_id int(10) NOT NULL,
  customers_id int(10) NOT NULL,
  sort_order int(10) NOT NULL,
  image varchar(255) NOT NULL,
  created datetime NOT NULL,
  modified datetime NOT NULL,
  PRIMARY KEY (image_id),
  INDEX products_id (products_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('REVIEWS_IMAGES_UPLOAD', 'true', 1, 69, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('ENABLE_WISHLIST', 'true', 1, 71, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

DROP TABLE IF EXISTS customers_wishlist;
CREATE TABLE customers_wishlist (
  customers_wishlist_id int NOT NULL auto_increment,
  customers_id int NOT NULL,
  products_id tinytext,
  customers_wishlist_quantity int(2) NOT NULL,
  final_price decimal(15,4) NOT NULL,
  customers_wishlist_date_added char(8),
  PRIMARY KEY (customers_wishlist_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS customers_wishlist_attributes;
CREATE TABLE customers_wishlist_attributes (
  customers_wishlist_attributes_id int NOT NULL auto_increment,
  customers_id int NOT NULL,
  products_id tinytext,
  products_options_id int NOT NULL,
  products_options_value_id int NOT NULL,
  products_options_value_text text,
  PRIMARY KEY (customers_wishlist_attributes_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('SET_BOX_WISHLIST', 'true', '29', '29', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MAX_DISPLAY_WISHLIST', '50', 3, 29, 'NULL', '', NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('AJAX_WISHLIST', 'true', 1, 70, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

