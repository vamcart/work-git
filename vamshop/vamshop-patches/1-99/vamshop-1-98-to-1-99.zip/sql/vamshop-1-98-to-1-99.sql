SET SQL_MODE = "";

ALTER TABLE banners MODIFY banners_group VARCHAR(255) NOT NULL;
ALTER TABLE banners ADD banners_description TEXT NOT NULL after `banners_title`;

INSERT INTO `banners` (`banners_title`, `banners_description`, `banners_url`, `banners_image`, `banners_group`, `banners_html_text`, `expires_impressions`, `expires_date`, `date_scheduled`, `date_added`, `date_status_change`, `status`) VALUES
('Слайд 1', 'Описание слайда 1', 'https://vamshop.ru', 'slide1.jpg', 'slider_pop_slide', '', NULL, NULL, NULL, '2019-04-06 23:31:11', NULL, 1),
('Слайд 2', 'Описание слайда 2', 'https://vamshop.ru', 'slide2.jpg', 'slider_pop_slide', '', NULL, NULL, NULL, '2019-04-07 23:02:24', NULL, 1),
('Слайд 3', 'Описание слайда 3', 'https://vamshop.ru', 'slide3.jpg', 'slider_pop_slide', '', NULL, NULL, NULL, '2019-04-07 23:02:50', NULL, 1),
('Скидки', 'Все товары со скидкой', 'https://vamshop.ru', 'slide4.jpg', 'slider_pop_slide', '', NULL, NULL, NULL, '2019-04-07 23:03:55', NULL, 1),
('Популярные', 'Рекомендуемые товары', 'https://vamshop.ru', 'slide5.jpg', 'slider_pop_slide', '', NULL, NULL, NULL, '2019-04-07 23:04:12', NULL, 1),
('Скидки', 'Все товары со скидкой', 'https://vamshop.ru', '', 'slider_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-07 23:21:15', NULL, 1),
('Стоит приглядеться', 'Рекомендуемые товары', 'https://vamshop.ru', '', 'slider_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-07 23:32:44', NULL, 1),
('Новинки', 'Все самые интересные товары здесь!', 'https://vamshop.ru', '', 'slider_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-07 23:37:00', NULL, 1),
('Слайд 1', 'Описание слайда 1', 'https://vamshop.ru', 'model1.png', 'slider_modern_slide_in', '', NULL, NULL, NULL, '2019-04-08 09:51:15', NULL, 1),
('Слайд 2', 'Описание слайда 2', 'https://vamshop.ru', 'model2.png', 'slider_modern_slide_in', '', NULL, NULL, NULL, '2019-04-08 09:51:42', NULL, 1),
('Слайд 3', 'Описание слайда 3', 'https://vamshop.ru', 'model3.png', 'slider_modern_slide_in', '', NULL, NULL, NULL, '2019-04-08 09:51:59', NULL, 1),
('Слайд 1', 'Описание слайда 1', 'https://vamshop.ru', '', 'slider_parallax_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-08 10:35:46', NULL, 1),
('Слайд 2', 'Описание слайда 2', 'https://vamshop.ru', '', 'slider_parallax_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-08 10:36:02', NULL, 1),
('Слайд 3', 'Описание слайда 3', 'https://vamshop.ru', '', 'slider_parallax_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-08 10:36:20', NULL, 1),
('Слайд 1', 'Описание слайда 1', 'https://vamshop.ru', '', 'slider_starter_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-08 10:37:01', NULL, 1),
('Слайд 2', 'Описание слайда 2', 'https://vamshop.ru', '', 'slider_starter_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-08 10:37:20', NULL, 1),
('Слайд 3', 'Описание слайда 3', 'https://vamshop.ru', '', 'slider_starter_basic', 'Если не используется картинка, то данное поле надо обязательно заполнить, иначе баннер не сохранится.', NULL, NULL, NULL, '2019-04-08 10:37:35', NULL, 1);

update configuration set configuration_value = 10 where configuration_key = "MAX_DISPLAY_CATEGORIES_PER_ROW";

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DEFAULT_SLIDER', 'pop_slide', 1, 36, NULL, '', NULL, 'vam_cfg_select_option(array(\'pop_slide\', \'basic\', \'modern_slide_in\', \'parallax_basic\', \'starter_basic\'),');
