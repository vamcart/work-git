ALTER TABLE manufacturers ADD manufacturers_seo_url VARCHAR(255) NOT NULL;
ALTER TABLE manufacturers ADD sort_order int(3) NOT NULL;
