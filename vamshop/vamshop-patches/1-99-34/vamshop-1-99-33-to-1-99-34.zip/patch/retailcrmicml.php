<?php
require('includes/application_top.php');
//header ('Content-type: text/xml');
        $string = '<?xml version="1.0" encoding="UTF-8"?>
            <yml_catalog date="'.date('Y-m-d H:i:s').'">
                <shop>
                    <name>vamshop</name>
                    <categories/>
                    <offers/>
                </shop>
            </yml_catalog>
        ';

        $xml = new SimpleXMLElement(
            $string,
            LIBXML_NOENT |LIBXML_NOCDATA | LIBXML_COMPACT | LIBXML_PARSEHUGE
        );

        $dom = new DOMDocument();
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $dom->loadXML($xml->asXML());

        $eCategories = $dom->getElementsByTagName('categories')->item(0);
        $eOffers = $dom->getElementsByTagName('offers')->item(0);

        $categories_query = vam_db_query("select c.categories_id, cd.categories_name, c.parent_id from " . TABLE_CATEGORIES . " c, " . TABLE_CATEGORIES_DESCRIPTION . " cd where c.categories_status = 1 and c.categories_id = cd.categories_id ORDER BY c.categories_id");
		while($category = vam_db_fetch_array($categories_query)){
           
            $e = $eCategories->appendChild($dom->createElement('category', $category['categories_name']));

            $e->setAttribute('id', $category['categories_id']);

            if ($category['parent_id'] > 0) {
                $e->setAttribute('parentId', $category['parent_id']);
            }
        }
        
		
		
		
		
        $products_query = vam_db_query("SELECT c.products_id,
	cd.products_name,
	c.products_price,
	c.products_status,
	c.products_weight,
	c.products_page_url,
	c.products_image FROM " . TABLE_PRODUCTS . " c," . TABLE_PRODUCTS_DESCRIPTION . " cd WHERE c.products_status = 1 and cd.products_id = c.products_id");

		while($product = vam_db_fetch_array($products_query)){
          
           $offerId = array();

			$e = $eOffers->appendChild($dom->createElement('offer'));

			$e->setAttribute('id', $product['products_id']);
			$e->setAttribute('productId', $product['products_id']);
			$e->setAttribute('quantity', 100);
			
			/**
			 * Offer activity
			 */
			$activity = $product['products_status'] == 1 ? 'Y' : 'N';
			$e->appendChild(
				$dom->createElement('productActivity')
			)->appendChild(
				$dom->createTextNode($activity)
			);
			/**
			 * Offer categories
			 */
			$products_to_category_query = vam_db_query("SELECT categories_id FROM " . TABLE_PRODUCTS_TO_CATEGORIES . " WHERE products_id=".$product['products_id']);

			while($product_to_category = vam_db_fetch_array($products_to_category_query)){
				$e->appendChild($dom->createElement('categories_id'))
					->appendChild($dom->createTextNode($product_to_category['categories_id']));
			}
			
			/**
			 * Name & price
			 */
			$e->appendChild($dom->createElement('productName'))
				->appendChild($dom->createTextNode($product['products_name']));
				
			$e->appendChild($dom->createElement('name'))
				->appendChild($dom->createTextNode($product['products_name']));
				
			$e->appendChild($dom->createElement('price'))
				->appendChild($dom->createTextNode($product['products_price']));
		   
		   
			/**
			Вес и размеры
			**/
			$e->appendChild($dom->createElement('weight'))
				->appendChild($dom->createTextNode($product['products_weight']));

			$products_extra_fields_id_query = vam_db_query("SELECT products_extra_fields_value FROM products_to_products_extra_fields WHERE products_extra_fields_id=2 and products_id=".$product['products_id']);

			while($products_extra_field = vam_db_fetch_array($products_extra_fields_id_query)){
				$e->appendChild($dom->createElement('dimensions'))
					->appendChild($dom->createTextNode($products_extra_field['products_extra_fields_value']));
			}
			
			
			
			/**
			 * Image
			 */
			if ($product['products_image']) {
				$eimage = HTTP_SERVER."/images/product_images/thumbnail_images/".$product['products_image'];
				$e->appendChild($dom->createElement('picture'))
					->appendChild($dom->createTextNode($eimage));
				
			}
			
			/**
			 * Url
			 */
			
			$e->appendChild($dom->createElement('url'))
				->appendChild($dom->createTextNode(HTTP_SERVER.'/' . $product['products_page_url']));
		   
        }
		
		
		
		

        $dom->saveXML();

        $downloadPath = 'retailcrm/';

        if (!file_exists($downloadPath)) {
            mkdir($downloadPath, 0755);
        }

        $dom->save($downloadPath . 'icml.xml');

 


?>