<?php
// Get order id
$orders_query = vam_db_query("select orders_id from " . TABLE_ORDERS . " where customers_id = '" . (int)$_SESSION['customer_id'] . "' order by date_purchased desc limit 1");
$orders = vam_db_fetch_array($orders_query);
$order_id = $orders['orders_id'];
	
if ($order_id > 0) { 
	
$orders_query = vam_db_query("SELECT * FROM " . TABLE_ORDERS." where orders_id = ".$order_id." order by orders_id DESC ");

while($rorder = vam_db_fetch_array($orders_query)){

$order_shipping_query = vam_db_query("SELECT value FROM " . TABLE_ORDERS_TOTAL . " WHERE class='ot_shipping' and orders_id=".$rorder['orders_id']);
				
$order_shipping = vam_db_fetch_array($order_shipping_query);

	try {
		$rrshipping_method = 'courier';
		$rrshiping_cost = $order_shipping['value'];
		if (($rorder['shipping_class']) == 'selfpickup_selfpickup'){
				$rrshipping_method = 'self-delivery';
				$rrshiping_cost = 0;
		}
		if (($rorder['shipping_class']) =='flat_flat'){
				$rrshipping_method = 'courier';
				$rrshiping_cost = MODULE_SHIPPING_FLAT_COST;
		}
		
		$rrpayment_method = 'cash';
		if (($rorder['payment_method']) ==  'cash'){
				$rrpayment_method = 'cash';
		}
		if (($rorder['payment_method']) ==  'cod'){
				$rrpayment_method = 'cash';
		}
		if (($rorder['payment_method']) ==  'kvitancia'){
				$rrpayment_method = 'bank-transfer';
		}
		if (($rorder['payment_method']) ==  'nalojka'){
				$rrpayment_method = 'bank-transfer';
		}
		if (($rorder['payment_method']) ==  'schet'){
				$rrpayment_method = 'bank-transfer';
		}
		
		$zakaz_status =$rorder['orders_status'];
		$rr_status="new";
		if($zakaz_status == "1"){
			$rr_status="new";
		}
		if($zakaz_status == "2"){
			$rr_status="send-to-assembling";
		}
		if($zakaz_status == "3"){
			$rr_status="cancel-other";
		}
		if($zakaz_status == "4"){
			$rr_status="assembling";
		}
		if($zakaz_status == "5"){
			$rr_status="delivering";
		}
		if($zakaz_status == "6"){
			$rr_status="complete";
		}
		
		$zakaz_id = $rorder['orders_id'];
		
		$rrkvit = "";
		// if (isset($rorder['kvit_name'])) $rrkvit =$rrkvit."ФИО:". $rorder['kvit_name'];
		// if (isset($rorder['kvit_address'])) $rrkvit =$rrkvit." Адрес: ".$rorder['kvit_address'];
		// if (isset($rorder['s_name'])) $rrkvit =$rrkvit." Название организации: ".$rorder['s_name'];
		// if (isset($rorder['s_inn'])) $rrkvit =$rrkvit." ИНН: ".$rorder['s_inn'];
		// if (isset($rorder['s_telephone'])) $rrkvit =$rrkvit." Телефон: ".$rorder['s_telephone'];
			
		$retailcrmpayments = array();
	
		array_push($retailcrmpayments,array(
						'externalId' => $zakaz_id,
						'type' => $rrpayment_method,
						'amount' => $retailcrmsum+$rrshiping_cost,
						'status' => 'not-paid',
						'comment' => $rrkvit));
						
		array_push($retailcrmpayments,array(
						'externalId' => $zakaz_id,
						'type' => $rrpayment_method,
						'amount' => $retailcrmsum+$rrshiping_cost,
						'status' => 'not-paid',
						'comment' => $rrkvit));
		unset($retailcrmpayments[1]);
		
	
		$retailcrmitemid = array();
		$retailcrmsum = 0;
		
		$order_products_query = vam_db_query("SELECT products_id,products_name,products_price,final_price,products_quantity FROM " . TABLE_ORDERS_PRODUCTS . " WHERE orders_id=".$zakaz_id);
				
		while($order_product = vam_db_fetch_array($order_products_query)){
			array_push(
					$retailcrmitemid, 
					array(
						'offer' =>array(
							'externalId' =>$order_product['products_id']
							),
						'productName' =>$order_product['products_name'],
						'quantity' =>$order_product['products_quantity'],
						'initialPrice' =>$order_product['products_price']
						)
					);
			//$retailcrmsum =$retailcrmsum + $order_product['products_quantity']*$order_product['final_price'];
		};
		
		$crmDomain = RETAILCRM_DOMAIN;
		$crmKey = RETAILCRM_KEY;
		
		$zakaz_name=$rorder['customers_firstname'];
		if ($rorder['customers_firstname']=="")	{
			$zakaz_name=$rorder['customers_name'];
		}
			
		$postData = http_build_query(array(
			'site' => RETAILCRM_SITE,
			'order' => json_encode(
				array(
					'externalId' => $zakaz_id,
					'site' => RETAILCRM_SITE,
					'orderMethod' => "shopping-cart",
					'createdAt' => $rorder['date_purchased'],
					'status' => $rr_status,
					'firstName' => $zakaz_name,
					'lastName' => $rorder['customers_lastname'],
					'patronymic' => $rorder['customers_secondname'],
					'phone' => $rorder['customers_telephone'],
					'email' => $rorder['customers_email_address'],
					'customerComment' => $rorder['comments'],
					'items' => $retailcrmitemid,
					'payments' =>$retailcrmpayments,
					'delivery' => array(
						'code' => $rrshipping_method, 
						'cost' => $rrshiping_cost,
						'address' => array(
						'text' => $rorder['customers_postcode'].", ".$rorder['customers_city'].", ".$rorder['customers_street_address'],
						),
					),
				)
			),
			'apiKey' => $crmKey,
		));

		 $curl = curl_init();
		 curl_setopt_array($curl, array(
		            CURLOPT_URL => $crmDomain . '/api/v5/orders/create',
		            CURLOPT_RETURNTRANSFER => true,
		            CURLOPT_ENCODING => "",
		            CURLOPT_MAXREDIRS => 10,
		            CURLOPT_TIMEOUT => 30,
		            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		            CURLOPT_CUSTOMREQUEST => "POST",
		            CURLOPT_POSTFIELDS => $postData,
		            CURLOPT_HTTPHEADER => array(
		                "cache-control: no-cache",
		                "content-type: application/x-www-form-urlencoded"
		            ),
		        ));
		 $response = curl_exec($curl);
		 $err = curl_error($curl);

		 //echo var_dump($response);
		
		 curl_close($curl);
		
	} catch (Exception $e) {
		echo "Connection error: " . $e->getMessage();
	};

}

}

?>