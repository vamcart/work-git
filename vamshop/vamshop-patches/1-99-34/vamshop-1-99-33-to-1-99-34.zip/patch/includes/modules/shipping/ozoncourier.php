<?php
/* -----------------------------------------------------------------------------------------
   $Id: ozon.php 899 2020-02-06 21:19:57 VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   -----------------------------------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(ozon.php,v 1.40 2003/02/05); www.oscommerce.com 
   (c) 2003	 nextcommerce (ozon.php,v 1.7 2003/08/24); www.nextcommerce.org
   (c) 2004	 xt:Commerce (ozon.php,v 1.7 2003/08/24); xt-commerce.com

   Released under the GNU General Public License 
   ---------------------------------------------------------------------------------------*/


  class ozoncourier {
    var $code, $title, $description, $icon, $enabled;


    function __construct() {
      global $order;

      $this->code = 'ozoncourier';
      $this->title = MODULE_SHIPPING_OZONCOURIER_TEXT_TITLE;
      $this->description = MODULE_SHIPPING_OZONCOURIER_TEXT_DESCRIPTION;
      $this->sort_order = MODULE_SHIPPING_OZONCOURIER_SORT_ORDER;
      $this->icon = DIR_WS_ICONS . 'ozonrocket.png';
      $this->tax_class = MODULE_SHIPPING_OZONCOURIER_TAX_CLASS;
      $this->enabled = ((MODULE_SHIPPING_OZONCOURIER_STATUS == 'True') ? true : false);

      if ( ($this->enabled == true) && ((int)MODULE_SHIPPING_OZONCOURIER_ZONE > 0) ) {
        $check_flag = false;
        $check_query = vam_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_SHIPPING_OZONCOURIER_ZONE . "' and zone_country_id = '" . $order->delivery['country']['id'] . "' order by zone_id");
        while ($check = vam_db_fetch_array($check_query)) {
          if ($check['zone_id'] < 1) {
            $check_flag = true;
            break;
          } elseif ($check['zone_id'] == $order->delivery['zone_id']) {
            $check_flag = true;
            break;
          }
        }

        if ($check_flag == false) {
          $this->enabled = false;
        }
      }
    }


    function quote($method = '') {
      global $order, $shipping_weight, $total_count, $length, $width, $height, $volume;
        
	    $login = rawurlencode(MODULE_SHIPPING_OZONCOURIER_CLIENT_ID);
	    $pass = rawurlencode(MODULE_SHIPPING_OZONCOURIER_CLIENT_SECRET);
	    $cost = MODULE_SHIPPING_OZONCOURIER_COST;
	    $city_from = MODULE_SHIPPING_OZONCOURIER_CITY;
	    $shipping_cost = MODULE_SHIPPING_OZONCOURIER_COST;
	    $total_weight = $shipping_weight;      
       $to_zip = $order->delivery['postcode'];
       $total = $order->info['total'];      
       $ozon_city_id = rawurlencode($order->delivery['city']);
      		
		// узнаем id города
		if($order->delivery['city'] == "спб" || $order->delivery['city'] == "СПБ") $order->delivery['city'] = "Санкт-Петербург";
	    if($order->delivery['city'] == "Ростов" || $order->delivery['city'] == "ростов" || $order->delivery['city'] == "Ростов на дону" || $order->delivery['city'] == "ростов на дону") $order->delivery['city'] = "ростов-на-дону";
	
if ($order->delivery['city'] != '' && $login != '') {

//Авторизуемся в апи озона

		 $curl = curl_init();
		 curl_setopt_array($curl, array(
		            CURLOPT_URL => "https://xapi.ozon.ru/principal-auth-api/connect/token",
		            CURLOPT_RETURNTRANSFER => true,
		            CURLOPT_ENCODING => "",
		            CURLOPT_MAXREDIRS => 10,
		            CURLOPT_TIMEOUT => 30,
		            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		            CURLOPT_CUSTOMREQUEST => "POST",
		            CURLOPT_POSTFIELDS => "grant_type=client_credentials&client_id=".$login."&client_secret=".$pass."",
		            CURLOPT_HTTPHEADER => array(
		                "cache-control: no-cache",
		                "content-type: application/x-www-form-urlencoded"
		            ),
		        ));
		 $response = curl_exec($curl);
		 $err = curl_error($curl);
		
		 curl_close($curl);
		
		 if (!$err)
		 {
		      $data = json_decode($response);
		 }

//echo $data->access_token;

// Пункт забора товара г. Челябинск, ул. Сталеваров, д. 37 id 17389351618000
//fromPlaceID 16193325330000

$delivery_address = $order->delivery['state'] . ' ' . $order->delivery['city'] . ' ' . $order->delivery['street_address'];
//$delivery_address = rawurldecode($delivery_address);

$weight = $shipping_weight*1000;
$length = $length*10;
$height = $height*10;
$width = $width*10;

$shipping_info = '

{
"fromPlaceId": '.$city_from.',
"destinationAddress": "'.$delivery_address.'",
"packages": [
{
"count": 1,
"dimensions": {
"weight": '.$weight.',
"length": '.$length.',
"height": '.$height.',
"width": '.$width.'
},
"price": '.number_format($order->info['total'],0,'.','').'
}
]
}

';

//$shipping_info = json_encode($shipping_info);

//echo var_dump($shipping_info);
			
		$curl = curl_init();
		curl_setopt_array($curl, [
	      CURLOPT_URL => "https://xapi.ozon.ru/principal-integration-api/v1/delivery/calculate/information",
	      CURLOPT_RETURNTRANSFER => true,
	      CURLOPT_ENCODING => "",
	      CURLOPT_MAXREDIRS => 10,
	      CURLOPT_TIMEOUT => 30,
	      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	      CURLOPT_CUSTOMREQUEST => "POST",
	      CURLOPT_POSTFIELDS => $shipping_info,
	      CURLOPT_HTTPHEADER => array(
          "cache-control: no-cache",
		    "authorization: Bearer ".$data->access_token,
		    "content-type: application/json"
		  ),
		]);
		 $response_courier = curl_exec($curl);
		 $err = curl_error($curl);
		
		 curl_close($curl);
		 
		 if (!$err)
		 {
		      $data_courier = json_decode($response_courier, $assoc=true);
		 }

//echo var_dump($data_courier);
	    
	    $shipping_ozon_courier = $data_courier;
	    $shipping_cost_courier = 0;


		foreach($shipping_ozon_courier['deliveryInfos'] as $key => $value) {
		if($shipping_ozon_courier['deliveryInfos'][$key]['deliveryType'] == 'Courier') {
			$shipping_cost_courier = $shipping_ozon_courier['deliveryInfos'][$key]['price'];
			$shipping_time_courier = $shipping_ozon_courier['deliveryInfos'][$key]['deliveryTermInDays'];
		}
		}
	    
// Получаем время доставки

	    $vremya = $shipping_time_courier;

		//echo var_dump($shipping_cost);

}

        $this->quotes = array('id' => $this->code,
                            'module' => MODULE_SHIPPING_OZONCOURIER_TEXT_TITLE,
                            'description' => '',
                            'methods' => array(array('id' => $this->code,
                                                     'title' => ($vremya > 0 ? $vremya.vam_format_by_count($vremya, ' день', ' дня', ' дней'):null),
                                                     'cost' => $shipping_cost_courier)));
													 				
$weight = 0;
$length = 0;
$height = 0;
$width= 0;
				
	    //$this->quotes['info'] .= $shipping_txt_min . '<br />';		

	  if ($this->tax_class > 0) {
		$this->quotes['tax'] = vam_get_tax_rate($this->tax_class, $order->delivery['country']['id'], $order->delivery['zone_id']);
	  }

      if (vam_not_null($this->icon)) $this->quotes['icon'] = vam_image($this->icon, $this->title);
	  
	  if ($error == true) 
	  $this->quotes['error'] = $err_msg;


	    //if ($POST['pvz_ozon'])
	    //$this->quotes['error'] = 'Выберите пункт выдачи заказов для расчёта стоимости.';

	    if ($order->delivery['city'] == '')
	    $this->quotes['error'] = 'Курьерская доставка OZON Rocket в указанный город не осуществляется.';

	    if (!$shipping_cost_courier)
	    $this->quotes['error'] = 'Курьерская доставка OZON Rocket в указанный город не осуществляется.';
	      
     if ($order->delivery['city'] == '') $this->quotes['error'] = 'Курьерская доставка OZON Rocket в этом направлении не осуществляется.';
  
      // Если символов в индексе меньше 6, или не выбран регион, или стоимость доставки меньше указаной в переменной MODULE_SHIPPING_OZONCOURIER_COST, то:
	  
	  if ((strlen($order->delivery['city']) == '')) {

      $this->quotes['error'] = 'Курьерская доставка OZON Rocket. Для расчета стоимости доставки укажите <b>город</b>';	  
	  
	  } elseif ($_SESSION['cart']->show_total() < $min_sum) {
	
	  $this->quotes['error'] = 'Курьерская доставка OZON Rocket. Действует при сумме товаров <b>от ' . $min_sum . ' руб.</b>';
	  }

      if (!$order->delivery['city']) 
	    $this->quotes['error'] = 'Укажите город.';
		
      return $this->quotes;
    }

    function check() {
      if (!isset($this->_check)) {
        $check_query = vam_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_SHIPPING_OZONCOURIER_STATUS'");
        $this->_check = vam_db_num_rows($check_query);
      }
      return $this->_check;
    }

    function install() {
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, set_function, date_added) values ('MODULE_SHIPPING_OZONCOURIER_STATUS', 'True', '6', '0', 'vam_cfg_select_option(array(\'True\', \'False\'), ', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZONCOURIER_ALLOWED', '', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZONCOURIER_COST', '250', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZONCOURIER_CITY', '', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, use_function, set_function, date_added) values ('MODULE_SHIPPING_OZONCOURIER_TAX_CLASS', '0', '6', '0', 'vam_get_tax_class_title', 'vam_cfg_pull_down_tax_classes(', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, use_function, set_function, date_added) values ('MODULE_SHIPPING_OZONCOURIER_ZONE', '0', '6', '0', 'vam_get_zone_class_title', 'vam_cfg_pull_down_zone_classes(', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZONCOURIER_SORT_ORDER', '0', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZONCOURIER_CLIENT_ID', '', '7', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZONCOURIER_CLIENT_SECRET', '', '8', '0', now())");
    }

    function remove() {
      vam_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
      return array('MODULE_SHIPPING_OZONCOURIER_STATUS', 'MODULE_SHIPPING_OZONCOURIER_COST', 'MODULE_SHIPPING_OZONCOURIER_CITY', 'MODULE_SHIPPING_OZONCOURIER_ALLOWED', 'MODULE_SHIPPING_OZONCOURIER_TAX_CLASS', 'MODULE_SHIPPING_OZONCOURIER_ZONE', 'MODULE_SHIPPING_OZONCOURIER_SORT_ORDER', 'MODULE_SHIPPING_OZONCOURIER_CLIENT_ID', 'MODULE_SHIPPING_OZONCOURIER_CLIENT_SECRET');
    }
  }