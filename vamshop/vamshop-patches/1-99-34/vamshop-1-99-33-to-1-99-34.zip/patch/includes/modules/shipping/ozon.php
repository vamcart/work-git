<?php
/* -----------------------------------------------------------------------------------------
   $Id: ozon.php 899 2020-02-06 21:19:57 VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   -----------------------------------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(ozon.php,v 1.40 2003/02/05); www.oscommerce.com 
   (c) 2003	 nextcommerce (ozon.php,v 1.7 2003/08/24); www.nextcommerce.org
   (c) 2004	 xt:Commerce (ozon.php,v 1.7 2003/08/24); xt-commerce.com

   Released under the GNU General Public License 
   ---------------------------------------------------------------------------------------*/


  class ozon {
    var $code, $title, $description, $icon, $enabled;


    function __construct() {
      global $order;

      $this->code = 'ozon';
      $this->title = MODULE_SHIPPING_OZON_TEXT_TITLE;
      $this->description = MODULE_SHIPPING_OZON_TEXT_DESCRIPTION;
      $this->sort_order = MODULE_SHIPPING_OZON_SORT_ORDER;
      $this->icon = DIR_WS_ICONS . 'ozonrocket.png';
      $this->tax_class = MODULE_SHIPPING_OZON_TAX_CLASS;
      $this->enabled = ((MODULE_SHIPPING_OZON_STATUS == 'True') ? true : false);

      if ( ($this->enabled == true) && ((int)MODULE_SHIPPING_OZON_ZONE > 0) ) {
        $check_flag = false;
        $check_query = vam_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_SHIPPING_OZON_ZONE . "' and zone_country_id = '" . $order->delivery['country']['id'] . "' order by zone_id");
        while ($check = vam_db_fetch_array($check_query)) {
          if ($check['zone_id'] < 1) {
            $check_flag = true;
            break;
          } elseif ($check['zone_id'] == $order->delivery['zone_id']) {
            $check_flag = true;
            break;
          }
        }

        if ($check_flag == false) {
          $this->enabled = false;
        }
      }
    }


    function quote($method = '') {
      global $order, $shipping_weight;
        
	    $login = rawurlencode(MODULE_SHIPPING_OZON_CLIENT_ID);
	    $pass = rawurlencode(MODULE_SHIPPING_OZON_CLIENT_SECRET);
	    $cost = MODULE_SHIPPING_OZON_COST;
	    $city_from = MODULE_SHIPPING_OZON_CITY;
	    $shipping_cost = MODULE_SHIPPING_OZON_COST;
	    $total_weight = $shipping_weight;      
       $to_zip = $order->delivery['postcode'];
       $total = $order->info['total'];      
       $ozon_city_id = rawurlencode($order->delivery['city']);
      		
		// узнаем id города
		if($order->delivery['city'] == "спб" || $order->delivery['city'] == "СПБ") $order->delivery['city'] = "Санкт-Петербург";
	    if($order->delivery['city'] == "Ростов" || $order->delivery['city'] == "ростов" || $order->delivery['city'] == "Ростов на дону" || $order->delivery['city'] == "ростов на дону") $order->delivery['city'] = "ростов-на-дону";
	
if ($order->delivery['city'] != '' && $login != '') {

//Авторизуемся в апи озона

		 $curl = curl_init();
		 curl_setopt_array($curl, array(
		            CURLOPT_URL => "https://xapi.ozon.ru/principal-auth-api/connect/token",
		            CURLOPT_RETURNTRANSFER => true,
		            CURLOPT_ENCODING => "",
		            CURLOPT_MAXREDIRS => 10,
		            CURLOPT_TIMEOUT => 30,
		            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		            CURLOPT_CUSTOMREQUEST => "POST",
		            CURLOPT_POSTFIELDS => "grant_type=client_credentials&client_id=".$login."&client_secret=".$pass."",
		            CURLOPT_HTTPHEADER => array(
		                "cache-control: no-cache",
		                "content-type: application/x-www-form-urlencoded"
		            ),
		        ));
		 $response = curl_exec($curl);
		 $err = curl_error($curl);
		
		 curl_close($curl);
		
		 if (!$err)
		 {
		      $data = json_decode($response);
		 }

//echo $data->access_token;

	    //Получаем список ПВЗ для указанного города
		// cache File Name
		$file5=SQL_CACHEDIR.'ozonPVZ'.$ozon_city_id.'.vam';
	    //$gzfile=SQL_CACHEDIR.$id.'.gz';

		// file life time
		$expire = 240000; // 240 hours

		if (file_exists($file5) && filemtime($file5) > (time() - $expire)) {

		// get cached resulst
        $ozon_pvz_data = file_get_contents($file5);
		} 
		else {
		if (file_exists($file5)) @unlink($file5);

// Пункт забора товара г. Челябинск, ул. Сталеваров, д. 37 id 17389351618000
//fromPlaceID 16193325330000

		$curl = curl_init();
		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://xapi.ozon.ru/principal-integration-api/v1/delivery/variants/?cityName=".$ozon_city_id."",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => [
		    "authorization: Bearer ".$data->access_token,
		    "content-type: application/json"
		  ],
		]);
		 $response = curl_exec($curl);
		 $err = curl_error($curl);
		
		 curl_close($curl);
		
		 if (!$err)
		 {
		      $data = json_decode($response);
		 }

	$ozon_pvz_data = $response;
	    
	    curl_close($curl);
	    
		//$stream = $data;
		$fp2 = fopen($file5,"w");
        fwrite($fp2, $ozon_pvz_data);
        fclose($fp2);
		
	    }
	    $ret_pvz_ozon = json_decode($ozon_pvz_data, $assoc=true);
	    //echo var_dump($ret_pvz_ozon);
	    
}		

	 
		$count_pvz = count($ret_pvz_ozon);
		$company = 'OZON';			
							
		if(isset($_POST['pvz_ozon'])) {
			$_SESSION['pvz_ozon'] = $_POST['pvz_ozon'];
		} else {
			unset($_SESSION['pvz_ozon']);
		}
		
		//$check_city_pvz = vam_db_query("select distinct city, lat from markers_geocod where name = '" . $_SESSION['pvz_ozon'] . "' and company = '" . $company . "'");
		//$city_pvz = vam_db_fetch_array($check_city_pvz);
				
		
		// получение списка пвз, занесение в базу		
		$value = 0; 
		//echo var_dump($ret_pvz_ozon);
	
		if ($count_pvz < 10000) {  // чтобы вдруг какой нибудь весь огромный список всех городов не загрузился
		$name_pvz_ozon[] = array('id' => '', 'text' => 'Выберите пункт выдачи заказов');
		foreach($ret_pvz_ozon['data'] as $key => $value) {
		if($ret_pvz_ozon['data'][$key]['id'] != '') {
		$name_pvz_ozon1 = $ret_pvz_ozon['data'][$key]['placement'] .' ' . $ret_pvz_ozon['data'][$key]['id'];
		$name_pvz_ozon[] = array('id' => $ret_pvz_ozon['data'][$key]['id'], 'text' => $name_pvz_ozon1);
		$city = $ret_pvz_ozon['data'][$key]['settlement']; 		
		//$vremya = $ret_pvz_ozon[$key]['DeliveryPeriod'];
        				
		//$worktime = $ret_pvz_ozon[$key]['WorkShedule']; 
        		
		//if ($city_pvz == '' && $_POST['pvz_ozon'] != '') {
        //vam_db_query("insert into markers_geocod (name, address, city, company, worktime, telephon, lng, lat) values ('" . $name_pvz_ozon1 . "', '" . $ret_pvz_ozon[$key]['Address'] . "', '" . $city . "', '" . $company . "', '" . $worktime . "', '" . $ret_pvz_ozon[$key]['Phone'] . "', '" . $ret_pvz_ozon[$key]['attributes']['GPS'] . "', '" . $ret_pvz_ozon[$key]['GPS'] . "')");	
		//}		
        $value++;		
		}
		}
		}
		
		//echo var_dump($name_pvz_ozon);

        // добавление в файл результатов геокодирования
		
		//if (!$_GET['oID'])
        //require_once('includes/modules/yandex-map/geokoder_yandex_kart.php');
		
if ($order->delivery['city'] != '') {
        // список пвз, выпадающее меню
        $pvz_ozon = vam_draw_pull_down_menu('pvz_ozon', $name_pvz_ozon, $_POST['pvz_ozon'], 'id="pvz_ozon" class="form-control"');
}
		
		if($_POST['pvz_ozon'] != '') $pvz_ozon_title_ozon = ', ' . html_entity_decode($_POST['pvz_ozon']) . '';		


	    //Считаем стоимость доставки в выбранный ПВЗ
	    
	    if ($POST['pvz_ozon']) {
	    	$selected_pvz = $_POST['pvz_ozon'];
	    } else {
	    	$selected_pvz = '17389351618000';
	    }
	    //echo var_dump($selected_pvz);

// Пункт забора товара г. Челябинск, ул. Сталеваров, д. 37 id 17389351618000
//fromPlaceID 16193325330000

		$curl = curl_init();
		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://xapi.ozon.ru/principal-integration-api/v1/delivery/calculate/?weight=".$shipping_weight."&deliveryVariantId=".$_SESSION['pvz_ozon']."&fromPlaceId=".MODULE_SHIPPING_OZON_CITY."",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => [
		    "authorization: Bearer ".$data->access_token,
		    "content-type: application/json"
		  ],
		]);
		 $response = curl_exec($curl);
		 $err = curl_error($curl);
		
		 curl_close($curl);
		 
		 if (!$err)
		 {
		      $data = json_decode($response, $assoc=true);
		 }

//echo var_dump($data);
	    
	    $shipping = $data;
	    
	    //echo var_dump($shipping['amount']);
	    	    
		if ($shipping['amount'] > 0) {
		$shipping_cost = $shipping['amount'];
		}

// Получаем время доставки

	    $vremya = date('d',strtotime($shipping['DeliveryDate']))-date("d");

		//echo var_dump($shipping_cost);

        $this->quotes = array('id' => $this->code,
                            'module' => MODULE_SHIPPING_OZON_TEXT_TITLE,
                            'description' => MODULE_SHIPPING_OZON_JS,
                            'methods' => array(array('id' => $this->code,
                                                     'title' => MODULE_SHIPPING_OZON_TEXT_TITLE_2 . html_entity_decode($pvz_ozon_title_ozon) . ($vremya > 0 ? ' - ' . $vremya.vam_format_by_count($vremya, ' день', ' дня', ' дней'):null) . '' . $skidka_text,
                                                     'cost' => $shipping_cost)));
													 				
				
	    //$this->quotes['info'] .= $shipping_txt_min . '<br />';		

        $this->quotes['info'] .= $pvz_ozon;		

	  if ($this->tax_class > 0) {
		$this->quotes['tax'] = vam_get_tax_rate($this->tax_class, $order->delivery['country']['id'], $order->delivery['zone_id']);
	  }

      if (vam_not_null($this->icon)) $this->quotes['icon'] = vam_image($this->icon, $this->title);
	  
	  if ($error == true) 
	  $this->quotes['error'] = $err_msg;


	    //if ($POST['pvz_ozon'])
	    //$this->quotes['error'] = 'Выберите пункт выдачи заказов для расчёта стоимости.';

	    if ($order->delivery['city'] == '')
	    $this->quotes['error'] = 'Доставка OZON Rocket в указанный город не осуществляется.';

  
     if ($order->delivery['city'] == '') $this->quotes['error'] = 'Доставка в этом направлении не осуществляется.';
  
      // Если символов в индексе меньше 6, или не выбран регион, или стоимость доставки меньше указаной в переменной MODULE_SHIPPING_OZON_COST, то:
	  
	  if ((strlen($order->delivery['city']) == '')) {

      $this->quotes['error'] = 'До пункта выдачи. Для расчета стоимости доставки укажите <b>город</b>';	  
	  
	  } elseif ($_SESSION['cart']->show_total() < $min_sum) {
	
	  $this->quotes['error'] = 'До пункта выдачи. Действует при сумме товаров <b>от ' . $min_sum . ' руб.</b>';
	  } elseif (isset($ret['error'][0]['code']) || $shipping_cost <= MODULE_SHIPPING_OZON_COST) {
		  
	  //$this->quotes['error'] = 'Пункты выдачи. Доставка в этом направлении не осуществляется.'; 
	  } 

      //if (!$shipping['price'] && !$_POST['pvz_ozon']) 
	    //$this->quotes['error'] = 'Выберите пункт выдачи заказов.';

      if (!$order->delivery['city']) 
	    $this->quotes['error'] = 'Укажите город.';
		
      return $this->quotes;
    }

    function check() {
      if (!isset($this->_check)) {
        $check_query = vam_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_SHIPPING_OZON_STATUS'");
        $this->_check = vam_db_num_rows($check_query);
      }
      return $this->_check;
    }

    function install() {
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, set_function, date_added) values ('MODULE_SHIPPING_OZON_STATUS', 'True', '6', '0', 'vam_cfg_select_option(array(\'True\', \'False\'), ', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZON_ALLOWED', '', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZON_COST', '250', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZON_CITY', '', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, use_function, set_function, date_added) values ('MODULE_SHIPPING_OZON_TAX_CLASS', '0', '6', '0', 'vam_get_tax_class_title', 'vam_cfg_pull_down_tax_classes(', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, use_function, set_function, date_added) values ('MODULE_SHIPPING_OZON_ZONE', '0', '6', '0', 'vam_get_zone_class_title', 'vam_cfg_pull_down_zone_classes(', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZON_SORT_ORDER', '0', '6', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZON_CLIENT_ID', '', '7', '0', now())");
      vam_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, date_added) values ('MODULE_SHIPPING_OZON_CLIENT_SECRET', '', '8', '0', now())");
    }

    function remove() {
      vam_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
      return array('MODULE_SHIPPING_OZON_STATUS', 'MODULE_SHIPPING_OZON_COST', 'MODULE_SHIPPING_OZON_CITY', 'MODULE_SHIPPING_OZON_ALLOWED', 'MODULE_SHIPPING_OZON_TAX_CLASS', 'MODULE_SHIPPING_OZON_ZONE', 'MODULE_SHIPPING_OZON_SORT_ORDER', 'MODULE_SHIPPING_OZON_CLIENT_ID', 'MODULE_SHIPPING_OZON_CLIENT_SECRET');
    }
  }