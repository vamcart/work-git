<?php
/*------------------------------------------------------------------------------
  $Id: webmoney.php 1310 2009-02-06 19:20:03 VaM $

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
  -----------------------------------------------------------------------------
   based on:
   (c) 2005 Vetal (robox.php,v 1.48 2003/05/27); metashop.ru

  Released under the GNU General Public License
------------------------------------------------------------------------------*/

function get_var($name, $default = 'none') {
  return (isset($_GET[$name])) ? $_GET[$name] : ((isset($_POST[$name])) ? $_POST[$name] : $default);
}

require('includes/application_top.php');
require (DIR_WS_CLASSES.'order.php');
require_once (DIR_FS_INC.'vam_send_answer_template.inc.php');

// logging
//$fp = fopen('1.log', 'a+');
//$str=date('Y-m-d H:i:s').' - ';
//foreach ($_GET as $vn=>$vv) {
  //$str.=$vn.'='.$vv.';';
//}

//fwrite($fp, $str."\n");
//fclose($fp);

//$vn = 'orderId/externalId/status/status_code';
//$vv = '254/3/Доставляется/availability-confirmed';
//$params = explode('/',$vn);
//$values = explode('/',$vv);

//echo var_dump($params);
//echo var_dump($values);

foreach ($_GET as $vn=>$vv) {
$params = explode('/',$vn);
$values = explode('/',$vv);
}

// Find order status
$orders_status_query = vam_db_query("select orders_status_id from " . TABLE_ORDERS_STATUS . " where orders_status_name = '" . vam_db_input($values[2]) . "' order by orders_status_id desc limit 1");
$orders_status = vam_db_fetch_array($orders_status_query);
$status = $orders_status['orders_status_id'];

if ($status > 0) {

  $sql_data_array = array('orders_status' => $status);
  vam_db_perform('orders', $sql_data_array, 'update', "orders_id='".$values[1]."'");

  $sql_data_arrax = array('orders_id' => $values[1],
                          'orders_status_id' => $status,
                          'date_added' => 'now()',
                          'customer_notified' => '0',
                          'comments' => 'RetailCRM Order Status');
  vam_db_perform('orders_status_history', $sql_data_arrax);

  echo 'OK'.$inv_id;

	//Send answer template
	vam_send_answer_template($values[1],'on','on');

}

?>