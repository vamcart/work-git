SET SQL_MODE = "";

INSERT INTO configuration_group VALUES ('101', 'CG_RETAILCRM_EXCHANGE', 'RetailCRM', 'Интеграция с RetailCRM.', '1', '1');

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('RETAILCRM_DOMAIN', '', '101', '1', NULL , '0000-00-00 00:00:00', NULL , NULL);

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('RETAILCRM_KEY', '', '101', '1', NULL , '0000-00-00 00:00:00', NULL , NULL);

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('RETAILCRM_SITE', '', '101', '1', NULL , '0000-00-00 00:00:00', NULL , NULL);
