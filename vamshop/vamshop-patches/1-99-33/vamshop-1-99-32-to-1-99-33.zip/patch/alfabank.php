<?php
/*------------------------------------------------------------------------------
  $Id: webmoney.php 1310 2009-02-06 19:20:03 VaM $

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
  -----------------------------------------------------------------------------
   based on:
   (c) 2005 Vetal (robox.php,v 1.48 2003/05/27); metashop.ru

  Released under the GNU General Public License
------------------------------------------------------------------------------*/

function get_var($name, $default = 'none') {
  return (isset($_GET[$name])) ? $_GET[$name] : ((isset($_POST[$name])) ? $_POST[$name] : $default);
}

require('includes/application_top.php');
require (DIR_WS_CLASSES.'order.php');
require_once (DIR_FS_INC.'vam_send_answer_template.inc.php');

//header('Content-type: text/xml; charset=utf-8');

// logging
//$fp = fopen('yandex.log', 'a+');
//$str=date('Y-m-d H:i:s').' - ';
//foreach ($_POST as $vn=>$vv) {
  //$str.=$vn.'='.$vv.';';
//}

//fwrite($fp, $str."\n");
//fclose($fp);

        if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['orderId'])){
        
            $_sgateway = ((MODULE_PAYMENT_ALFABANK_TEST == 'test') ? 'https://web.rbsuat.com/ab/rest/' : 'https://pay.alfabank.ru/payment/rest/');
            $_slogin = MODULE_PAYMENT_ALFABANK_API_LOGIN;
            $_spassword = MODULE_PAYMENT_ALFABANK_API_PASS;
            $_qdata = array(
                'userName' => $_slogin,
                'password' => $_spassword,
                'orderId' => $_GET['orderId']
            );
            
            $response = gateway('getOrderStatus.do', $_qdata, $_sgateway, false);
            $order_id = (isset($response['OrderNumber']))?$response['OrderNumber']:0;
            if (($response['OrderStatus'] == 1 || $response['OrderStatus'] == 2) && $response['ErrorCode'] == 0) {


  $sql_data_array = array('orders_status' => MODULE_PAYMENT_ALFABANK_ORDER_STATUS_ID);
  vam_db_perform('orders', $sql_data_array, 'update', "orders_id='".$order_id."'");

  $sql_data_arrax = array('orders_id' => $order_id,
                          'orders_status_id' => MODULE_PAYMENT_ALFABANK_ORDER_STATUS_ID,
                          'date_added' => 'now()',
                          'customer_notified' => '0',
                          'comments' => 'Alfabank accepted this order payment');
  vam_db_perform('orders_status_history', $sql_data_arrax);
  
  //echo 'OK'.$inv_id;
  $inv_id = $order_id;
  $order = new order($inv_id);
  $order_sum = $order->info['total'];

	//Send answer template
	vam_send_answer_template($inv_id,MODULE_PAYMENT_YANDEX_FIZLICO_ORDER_STATUS_ID,'on','on');

// initialize templates
$vamTemplate = new vamTemplate;

	$vamTemplate->assign('address_label_customer', vam_address_format($order->customer['format_id'], $order->customer, 1, '', '<br />'));
	$vamTemplate->assign('address_label_shipping', vam_address_format($order->delivery['format_id'], $order->delivery, 1, '', '<br />'));
	if ($_SESSION['credit_covers'] != '1') {
		$vamTemplate->assign('address_label_payment', vam_address_format($order->billing['format_id'], $order->billing, 1, '', '<br />'));
	}
	$vamTemplate->assign('csID', $order->customer['csID']);

  $it=0;
	$semextrfields = vamDBquery("select * from " . TABLE_EXTRA_FIELDS . " where fields_required_email = '1'");
	while($dataexfes = vam_db_fetch_array($semextrfields,true)) {
	$cusextrfields = vamDBquery("select * from " . TABLE_CUSTOMERS_TO_EXTRA_FIELDS . " where customers_id = '" . (int)$_SESSION['customer_id'] . "' and fields_id = '" . $dataexfes['fields_id'] . "'");
	$rescusextrfields = vam_db_fetch_array($cusextrfields,true);

	$extrfieldsinf = vamDBquery("select fields_name from " . TABLE_EXTRA_FIELDS_INFO . " where fields_id = '" . $dataexfes['fields_id'] . "' and languages_id = '" . $_SESSION['languages_id'] . "'");

	$extrfieldsres = vam_db_fetch_array($extrfieldsinf,true);
	$extra_fields .= $extrfieldsres['fields_name'] . ' : ' .
	$rescusextrfields['value'] . "\n";
	$vamTemplate->assign('customer_extra_fields', $extra_fields);
  }
	
	$order_total = $order->getTotalData($inv_id);
		$vamTemplate->assign('order_data', $order->getOrderData($inv_id));
		$vamTemplate->assign('order_total', $order_total['data']);

	// assign language to template for caching
	$vamTemplate->assign('language', $_SESSION['language']);
	$vamTemplate->assign('tpl_path', 'templates/'.CURRENT_TEMPLATE.'/');
	$vamTemplate->assign('logo_path', HTTP_SERVER.DIR_WS_CATALOG.'templates/'.CURRENT_TEMPLATE.'/img/');
	$vamTemplate->assign('oID', $inv_id);
	if ($order->info['payment_method'] != '' && $order->info['payment_method'] != 'no_payment') {
		include (DIR_WS_LANGUAGES.$_SESSION['language'].'/modules/payment/'.$order->info['payment_method'].'.php');
		$payment_method = constant(strtoupper('MODULE_PAYMENT_'.$order->info['payment_method'].'_TEXT_TITLE'));
	}
	$vamTemplate->assign('PAYMENT_METHOD', $payment_method);
	if ($order->info['shipping_method'] != '') {
		$shipping_method = $order->info['shipping_method'];
	}
	$vamTemplate->assign('SHIPPING_METHOD', $shipping_method);
	$vamTemplate->assign('DATE', vam_date_long($order->info['date_purchased']));

	$vamTemplate->assign('NAME', $order->customer['firstname'] . ' ' . $order->customer['lastname']);
	$vamTemplate->assign('COMMENTS', $order->info['comments']);
	$vamTemplate->assign('EMAIL', $order->customer['email_address']);
	$vamTemplate->assign('PHONE',$order->customer['telephone']);

	// dont allow cache
	$vamTemplate->caching = false;

	$html_mail = $vamTemplate->fetch(CURRENT_TEMPLATE.'/mail/'.$_SESSION['language'].'/order_mail.html');
	$txt_mail = $vamTemplate->fetch(CURRENT_TEMPLATE.'/mail/'.$_SESSION['language'].'/order_mail.txt');

	// create subject
	$order_subject = str_replace('{$nr}', $inv_id, EMAIL_BILLING_SUBJECT_ORDER);
	$order_subject = str_replace('{$date}', strftime(DATE_FORMAT_LONG), $order_subject);
	$order_subject = str_replace('{$lastname}', $order->customer['lastname'], $order_subject);
	$order_subject = str_replace('{$firstname}', $order->customer['firstname'], $order_subject);

	// send mail to admin
	vam_php_mail(EMAIL_BILLING_ADDRESS, EMAIL_BILLING_NAME, EMAIL_BILLING_ADDRESS, STORE_NAME, EMAIL_BILLING_FORWARDING_STRING, $order->customer['email_address'], $order->customer['firstname'], '', '', $order_subject, $html_mail, $txt_mail);

	// send mail to customer
	vam_php_mail(EMAIL_BILLING_ADDRESS, EMAIL_BILLING_NAME, $order->customer['email_address'], $order->customer['firstname'].' '.$order->customer['lastname'], '', EMAIL_BILLING_REPLY_ADDRESS, EMAIL_BILLING_REPLY_ADDRESS_NAME, '', '', $order_subject, $html_mail, $txt_mail);

  

	$_SESSION['cart']->reset(true);

	// unregister session variables used during checkout
	unset ($_SESSION['sendto']);
	unset ($_SESSION['billto']);
	unset ($_SESSION['shipping']);
	unset ($_SESSION['payment']);
	unset ($_SESSION['comments']);
	unset ($_SESSION['last_order']);
	unset ($_SESSION['tmp_oID']);
	unset ($_SESSION['cc']);

                vam_redirect(vam_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL'));

            }else{
                unset($_SESSION['cart_alfabank_id']);
                $error_text = 'Ошибка проведения платежа #'.$response['ErrorCode'].', Статус операции #'.$response['OrderStatus'];
                vam_redirect(vam_href_link(FILENAME_CHECKOUT, 'payment_error='.$error_text, 'SSL'));
            }
        }else{
                unset($_SESSION['cart_alfabank_id']);
            $error_text = 'Сервер получил неверные данные. Попробуйте повторить ваш запрос немного позже.';
                vam_redirect(vam_href_link(FILENAME_DEFAULT, 'payment_error='.$error_text, 'SSL'));
        }


function gateway($method, $data, $url, $log = false) {
	$curl = curl_init();
	curl_setopt_array($curl, array(
	    CURLOPT_URL => $url.$method,
	    CURLOPT_RETURNTRANSFER => true,
	    CURLOPT_POST => true,
	    CURLOPT_POSTFIELDS => http_build_query($data)
	));
	$response = curl_exec($curl);
	$response = json_decode($response, true);
	if ($log == true) {
		logger('Request: ' . $url . $method . ': ' . print_r($data, true).'Response: ' . $response);
	}
	curl_close($curl);
	return $response;
}

function logger($var) {
    $date = '====== '.date('Y-m-d H:i:s')." =====\n";
    $result = $var;
    if (is_array($var) || is_object($var)) {
        $result = print_r($var, true);
    }
    $result .= "\n";
    return error_log($date.$result, 0);
}        


?>