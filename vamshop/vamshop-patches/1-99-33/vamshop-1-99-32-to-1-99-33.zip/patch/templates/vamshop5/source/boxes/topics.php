<?php
/* -----------------------------------------------------------------------------------------
   categories2.php 2013-04-07

   VaM Shop
   Author: Mironov Andrey (Skype: xenlil)
   
   Version: 1

   -----------------------------------------------------------------------------------------

   Бокс со списком категорий с использованием всплывающего CSS-меню

   ---------------------------------------------------------------------------------------*/

require_once (DIR_FS_INC.'vam_has_topics_subcategories.inc.php');

$box = new vamTemplate;
global $cPath;
$split_cPath_array = array();
if ( $cPath ) $split_cPath_array = preg_split( '/_/', $cPath );
$categories_string2 = '';


function vam_category_get_topic_articles( $cat_id )
{

    global $categories_string2;

    $products_query = "select a.articles_id, ad.articles_name from ".TABLE_ARTICLES." as a "
    . "left join ".TABLE_ARTICLES_DESCRIPTION." as ad on (a.articles_id = ad.articles_id) "
    . "left join ".TABLE_ARTICLES_TO_TOPICS." as att on (a.articles_id = att.articles_id) "
    . "where att.topics_id = '".$cat_id."' and a.articles_status = '1' and ad.language_id='" . (int)$_SESSION[ 'languages_id' ] . "' "
    . "order by a.sort_order";

    $products_query = vamDBquery( $products_query );

    while ( $products = vam_db_fetch_array( $products_query, true ) )
    {
        $p_url = vam_product_link( $products[ 'articles_id' ], $products[ 'articles_name' ] );
        $p_url = vam_href_link( FILENAME_ARTICLE_INFO, $p_url );

        $categories_string2 .= '<li class="categorie_product"><a href="' . $p_url . '">' . $products[ 'articles_name' ] . '</a></li>';

    };  // while ( $products = vam_db_fetch_array( $products_query, true ) )

    
}  // function vam_category_get_topic_articles( $cat_id )


function vam_get_topics_subcategories( $owner_cat_id, $owner_cat_name = '', $owner_cat_image = '', $current_cPath = '', $level = 0 )
{

    global $categories_string2;
    
		$SEF_parameter = '';
		if (SEARCH_ENGINE_FRIENDLY_URLS == 'true')
			$SEF_parameter = '&article='.vam_cleanName($articles['articles_name']);

		$SEF_parameter_author = '';
		if (SEARCH_ENGINE_FRIENDLY_URLS == 'true')
			$SEF_parameter_author = '&author='.vam_cleanName($articles['authors_name']);

		$SEF_parameter_category = '';
		if (SEARCH_ENGINE_FRIENDLY_URLS == 'true')
			$SEF_parameter_category = '&category='.vam_cleanName($articles['topics_name']);

    
    $cPath_new = vam_category_link( $owner_cat_id, $owner_cat_name );
    $cPath_new_url = vam_href_link(FILENAME_ARTICLES, 'tPath=' . $owner_cat_id . $SEF_parameter_category);
    

    if ( $owner_cat_id )
    {
        $products_count_string = '';
        if (SHOW_COUNTS == 'true')
        {
            $products_in_category = vam_count_articles_in_topic( $owner_cat_id );
            if ( $products_in_category > 0 )
            {
                $products_count_string .= '&nbsp;(' . $products_in_category . ')';
            };
        };

        $categories_string2 .= '<li'.((vam_has_topics_subcategories($owner_cat_id)) ? " class=\"dropdown\" " : "").'><a'.((vam_has_topics_subcategories($owner_cat_id)) ? " class=\"dropdown-item dropdown-toggle\" data-bs-toggle=\"dropdown\" " : " class=\"dropdown-item\" ").'href="' . ((vam_has_topics_subcategories($owner_cat_id)) ? "#" : $cPath_new_url) . '">' . $owner_cat_name . $products_count_string . '</a>'."\n";

    };  // if ( $owner_cat_id )

    $group_check = '';
    //if ( GROUP_CHECK == 'true' )
    //{
        //$group_check = "and c.group_permission_" . $_SESSION[ 'customers_status' ][ 'customers_status_id' ] . "=1 "; 
    //};

    $categories_query = "select t.*, td.* from " . TABLE_TOPICS . " t, " . TABLE_TOPICS_DESCRIPTION . " td
                       where t.parent_id = '" . (int)$owner_cat_id . "'
                       " . $group_check . "
                       and t.topics_id = td.topics_id
                       and td.language_id='" . (int)$_SESSION[ 'languages_id' ] . "'
                       order by sort_order, td.topics_name";

    $categories_query = vamDBquery( $categories_query );
    
    $categories_current_level = array();

    while ( $categories = vam_db_fetch_array( $categories_query, true ) )
    {
        $categories_current_level[ $categories[ 'topics_id' ] ] = array (
            'id' => $categories[ 'topics_id' ],
            'name' => $categories[ 'topics_name' ],
            'parent' => $categories[ 'parent_id' ],
            'path' => ( $current_cPath ? $current_cPath . '_' . $categories[ 'topics_id' ] : $categories[ 'topics_id' ] ),
            'level' => substr_count($current_cPath,'_')
        );

    };  // while ( $categories = vam_db_fetch_array( $categories_query, true ) )

    if ( $categories_current_level )
    {
        if ( $owner_cat_id ) $categories_string2 .= '<ul class="dropdown-menu">';
        
        $level = 0;

        foreach ( $categories_current_level as $v )
        {
        	$level++;
            vam_get_topics_subcategories(
                $v[ 'id' ],
                $v[ 'name' ],
                $v[ 'image' ],
                $v[ 'path' ],
                substr_count($current_cPath,'_')
            );
            
        };

// Uncomment this for output products in CSS menu
//        vam_category_get_topic_articles( $owner_cat_id );

        if ( $owner_cat_id ) $categories_string2 .= '</ul>';

    }  // if ( $categories_current_level )

// Uncomment this for output products in CSS menu
//    else {
//        if ( $owner_cat_id ) $categories_string2 .= '<ul>';
//        vam_category_get_topic_articles( $owner_cat_id );
//        if ( $owner_cat_id ) $categories_string2 .= '</ul>';
//    }  // if ( $categories_current_level )
    ;
    

    if ( $owner_cat_id ) $categories_string2 .= '</li>';
    
}  // function vam_get_topics_subcategories( ... )



$box->assign( 'language', $_SESSION[ 'language' ] );

// set cache ID
if ( !CacheCheck() )
{
	$cache = false;
	$box->caching = 0;
} else {
	$cache = true;
	$box->caching = 1;
	$box->cache_lifetime = CACHE_LIFETIME;
	$box->cache_modified_check = CACHE_CHECK;
	$cache_id = $_SESSION[ 'language' ] . $_SESSION[ 'customers_status' ][ 'customers_status_id' ] . $current_category_id;
};

if( !$box->isCached( CURRENT_TEMPLATE . '/boxes/box_topics.html', $cache_id ) || !$cache )
{

  $box->assign('tpl_path', 'templates/' . CURRENT_TEMPLATE . '/');

  // include needed functions
//  require_once ( DIR_FS_INC . 'vam_has_topics_subcategories.inc.php' );

  vam_get_topics_subcategories( 0 );
  
  //echo var_dump($categories_string2); 


$box->assign( 'BOX_CONTENT', '<ul class="dropdown-menu">' . $categories_string2 . '</ul>' );

};  // if( !$box->isCached( CURRENT_TEMPLATE . '/boxes/box_topics.html', $cache_id ) || !$cache )

// set cache ID
if ( !$cache )
{
	$box_topics = $box->fetch( CURRENT_TEMPLATE . '/boxes/box_topics.html' );
} else {
	$box_topics = $box->fetch( CURRENT_TEMPLATE . '/boxes/box_topics.html', $cache_id );
};

$vamTemplate->assign('box_TOPICS', $box_topics );
?>