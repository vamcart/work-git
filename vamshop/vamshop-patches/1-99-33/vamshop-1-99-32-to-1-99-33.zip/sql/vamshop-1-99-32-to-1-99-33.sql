SET SQL_MODE = "";

CREATE FULLTEXT INDEX full_index
ON products_description(products_name, products_description, products_keywords);

CREATE FULLTEXT INDEX products_name_full
ON products_description(products_name);

CREATE FULLTEXT INDEX products_description_full
ON products_description(products_description);

CREATE FULLTEXT INDEX products_keywords_full
ON products_description(products_keywords);