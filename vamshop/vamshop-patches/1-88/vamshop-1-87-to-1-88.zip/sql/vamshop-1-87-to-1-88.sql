ALTER TABLE `products` ADD `products_length` double;
ALTER TABLE `products` ADD `products_width` double;
ALTER TABLE `products` ADD `products_height` double;
ALTER TABLE `products` ADD `products_volume` double;
