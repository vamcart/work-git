SET SQL_MODE = "";
ALTER TABLE products ADD products_bundle VARCHAR(255) NOT NULL default "no";
ALTER TABLE products ADD sold_in_bundle_only VARCHAR(255) NOT NULL default "no";

DROP TABLE IF EXISTS products_bundles;
CREATE TABLE `products_bundles` (
  `bundle_id` int(11) NOT NULL,
  `subproduct_id` int(11) NOT NULL,
  `subproduct_qty` tinyint(4) NOT NULL,
  PRIMARY KEY (bundle_id, subproduct_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `latest_news` ADD `news_head_title` TEXT;
ALTER TABLE `latest_news` ADD `news_head_desc` TEXT;
ALTER TABLE `latest_news` ADD `news_head_keys` TEXT;
