ALTER TABLE `companies` ADD `customers_id` INT(11) NOT NULL AFTER `orders_id`;
ALTER TABLE `persons` ADD `customers_id` INT(11) NOT NULL AFTER `orders_id`;

ALTER TABLE admin_access ADD customer_export INT( 1 ) NOT NULL;
UPDATE admin_access SET customer_export = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD exportorders INT( 1 ) NOT NULL;
UPDATE admin_access SET exportorders = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD pin_loader INT( 1 ) NOT NULL;
UPDATE admin_access SET pin_loader = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE `products_attributes_download` ADD `products_attributes_is_pin` TINYINT( 1 ) NULL DEFAULT '0';
ALTER TABLE `orders_products_download` ADD `download_is_pin` TINYINT( 1 ) NULL DEFAULT '0';
ALTER TABLE `orders_products_download` ADD `download_pin_code` VARCHAR( 255 ) NULL DEFAULT '0';

DROP TABLE IF EXISTS products_pins;
CREATE TABLE products_pins (
  products_pin_id int(11) NOT NULL auto_increment,
  products_id int(11) NOT NULL,
  products_pin_code char(250) NOT NULL,
  products_pin_used tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (products_pin_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;
