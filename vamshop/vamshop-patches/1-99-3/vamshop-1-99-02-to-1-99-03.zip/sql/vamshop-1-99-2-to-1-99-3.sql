INSERT INTO configuration_group VALUES ('90', 'CG_SOCIAL_NETWORKS', 'Social Networks', 'Social Networks Options', '1', '1');

INSERT INTO `configuration` (`configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES
('GOOGLE_OAUTH_CLIENT_ID', '', '90', '1', NULL, now(), NULL, NULL),
('GOOGLE_OAUTH_SECRET_KEY', '', '90', '2', NULL, now(), NULL, NULL),
('VK_OAUTH_CLIENT_ID', '', '90', '3', NULL, now(), NULL, NULL),
('VK_OAUTH_SECRET_KEY', '', '90', '4', NULL, now(), NULL, NULL),
('VK_OAUTH_SERVICE_KEY', '', '90', '5', NULL, now(), NULL, NULL),
('FACEBOOK_OAUTH_CLIENT_ID', '', '90', '6', NULL, now(), NULL, NULL),
('FACEBOOK_OAUTH_SECRET_KEY', '', '90', '7', NULL, now(), NULL, NULL);
