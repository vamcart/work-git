SET SQL_MODE = "";

DROP TABLE IF EXISTS orders_log;
CREATE TABLE orders_log (
  id int NOT NULL AUTO_INCREMENT,
  orders_id int NOT NULL,
  customers_id int NOT NULL,
  field text,
  value text,
  date_added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  last_modified datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY (id,orders_id,customers_id),
  KEY idx_orders_id (orders_id),
  KEY idx_customers_id (customers_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

ALTER TABLE admin_access ADD order_functions INT( 1 ) NOT NULL;
UPDATE admin_access SET order_functions = 1 WHERE customers_id = 1 LIMIT 1;