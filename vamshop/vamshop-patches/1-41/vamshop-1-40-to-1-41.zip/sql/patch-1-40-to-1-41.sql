
ALTER TABLE customers ADD customers_username VARCHAR(40) DEFAULT NULL;
ALTER TABLE customers ADD customers_fid INT(5) DEFAULT NULL;
ALTER TABLE customers ADD customers_sid INT(5) DEFAULT NULL;

DELETE FROM configuration WHERE configuration_key = 'STAY_PAGE_EDIT';