ALTER TABLE admin_access ADD answer_templates INT( 1 ) NOT NULL;
UPDATE admin_access SET answer_templates = 1 WHERE customers_id = 1 LIMIT 1;

DROP TABLE IF EXISTS answer_templates;
CREATE TABLE answer_templates (
   id int(11) NOT NULL AUTO_INCREMENT,
   name varchar(255) NOT NULL,
   content text,
   date_added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   language int(11) NOT NULL default '1',
   status tinyint(1) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

ALTER TABLE products_images ADD image_description TEXT NULL AFTER image_name;
ALTER TABLE products ADD products_image_description TEXT NULL AFTER products_image;