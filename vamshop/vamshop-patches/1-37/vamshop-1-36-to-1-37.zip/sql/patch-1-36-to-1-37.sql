ALTER TABLE admin_access ADD stats_sales_report2 INT( 1 ) NOT NULL;
UPDATE admin_access SET stats_sales_report2 = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD chart_data INT( 1 ) NOT NULL;
UPDATE admin_access SET chart_data = 1 WHERE customers_id = 1 LIMIT 1;

