SET SQL_MODE = "";

DROP TABLE IF EXISTS specification_url;
CREATE TABLE IF NOT EXISTS specification_url (
  `id` INT(11) NOT NULL auto_increment,
  `uri` TEXT NOT NULL,
  `query` TEXT NOT NULL,
  `date_added` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current_id` INT(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY idx_current_id (`current_id`),
  KEY idx_uri (`uri`(128)),
  KEY idx_query (`query`(128))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;


ALTER TABLE specification_description ADD `specification_seo_name` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE specifications ADD `specification_seo_active` TINYINT(1) NOT NULL DEFAULT '1';


INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, date_added, use_function, set_function) VALUES ('SPECIFICATIONS_FILTERS_SEO_MAX_FILTER_IDS', '1', 1610, 131, NOW(), NULL, NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, date_added, use_function, set_function) VALUES ('SPECIFICATIONS_FILTERS_SEO_MAX_FILTER_VALUES', '1', 1610, 132, NOW(), NULL, NULL);
