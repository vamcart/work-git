SET SQL_MODE = "";

DROP TABLE IF EXISTS `customers_status_to_categories_discount`;
CREATE TABLE `customers_status_to_categories_discount` (
  `discount_id` int(11) NOT NULL auto_increment,
  `customers_status_id` int(11) DEFAULT NULL,
  `categories_id` int(11) DEFAULT NULL,
  `discount` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (discount_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `customers_status_to_manufacturers_discount`;
CREATE TABLE `customers_status_to_manufacturers_discount` (
  `discount_id` int(11) NOT NULL auto_increment,
  `customers_status_id` int(11) DEFAULT NULL,
  `manufacturers_id` int(11) DEFAULT NULL,
  `discount` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (discount_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE customers_status ADD customers_status_discount_by_category varchar(255) default '0';
ALTER TABLE customers_status ADD customers_status_discount_by_brand varchar(255) default '0';