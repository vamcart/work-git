! function() {
    function n(n, l) {
        var t = n.split("."),
            e = P;
        t[0] in e || !e.execScript || e.execScript("var " + t[0]);
        for (var r; t.length && (r = t.shift());) t.length || void 0 === l ? e = e[r] ? e[r] : e[r] = {} : e[r] = l
    }

    function l(n, l) {
        function t() {}
        t.prototype = l.prototype, n.M = l.prototype, n.prototype = new t, n.prototype.constructor = n, n.N = function(n, t, e) {
            for (var r = Array(arguments.length - 2), u = 2; u < arguments.length; u++) r[u - 2] = arguments[u];
            return l.prototype[t].apply(n, r)
        }
    }

    function t(n, l) {
        null != n && this.a.apply(this, arguments)
    }

    function e(n) {
        n.b = ""
    }

    function r(n, l) {
        n.sort(l || u)
    }

    function u(n, l) {
        return n > l ? 1 : n < l ? -1 : 0
    }

    function i(n) {
        var l, t = [],
            e = 0;
        for (l in n) t[e++] = n[l];
        return t
    }

    function a(n, l) {
        this.b = n, this.a = {};
        for (var t = 0; t < l.length; t++) {
            var e = l[t];
            this.a[e.b] = e
        }
    }

    function o(n) {
        return n = i(n.a), r(n, function(n, l) {
            return n.b - l.b
        }), n
    }

    function s(n, l) {
        switch (this.b = n, this.g = !!l.v, this.a = l.c, this.i = l.type, this.h = !1, this.a) {
            case Y:
            case k:
            case J:
            case L:
            case O:
            case T:
            case q:
                this.h = !0
        }
        this.f = l.defaultValue
    }

    function f() {
        this.a = {}, this.f = this.j().a, this.b = this.g = null
    }

    function p(n, l) {
        for (var t = o(n.j()), e = 0; e < t.length; e++) {
            var r = t[e],
                u = r.b;
            if (null != l.a[u]) {
                n.b && delete n.b[r.b];
                var i = 11 == r.a || 10 == r.a;
                if (r.g)
                    for (var r = c(l, u) || [], a = 0; a < r.length; a++) {
                        var s = n,
                            f = u,
                            h = i ? r[a].clone() : r[a];
                        s.a[f] || (s.a[f] = []), s.a[f].push(h), s.b && delete s.b[f]
                    } else r = c(l, u), i ? (i = c(n, u)) ? p(i, r) : b(n, u, r.clone()) : b(n, u, r)
            }
        }
    }

    function c(n, l) {
        var t = n.a[l];
        if (null == t) return null;
        if (n.g) {
            if (!(l in n.b)) {
                var e = n.g,
                    r = n.f[l];
                if (null != t)
                    if (r.g) {
                        for (var u = [], i = 0; i < t.length; i++) u[i] = e.b(r, t[i]);
                        t = u
                    } else t = e.b(r, t);
                return n.b[l] = t
            }
            return n.b[l]
        }
        return t
    }

    function h(n, l, t) {
        var e = c(n, l);
        return n.f[l].g ? e[t || 0] : e
    }

    function g(n, l) {
        var t;
        if (null != n.a[l]) t = h(n, l, void 0);
        else n: {
            if (t = n.f[l], void 0 === t.f) {
                var e = t.i;
                if (e === Boolean) t.f = !1;
                else if (e === Number) t.f = 0;
                else {
                    if (e !== String) {
                        t = new e;
                        break n
                    }
                    t.f = t.h ? "0" : ""
                }
            }
            t = t.f
        }
        return t
    }

    function m(n, l) {
        return n.f[l].g ? null != n.a[l] ? n.a[l].length : 0 : null != n.a[l] ? 1 : 0
    }

    function b(n, l, t) {
        n.a[l] = t, n.b && (n.b[l] = t)
    }

    function d(n, l) {
        var t, e = [];
        for (t in l) 0 != t && e.push(new s(t, l[t]));
        return new a(n, e)
    }
    /*

     Protocol Buffer 2 Copyright 2008 Google Inc.
     All other code copyright its respective owners.
     Copyright (C) 2010 The Libphonenumber Authors

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    function y() {
        f.call(this)
    }

    function v() {
        f.call(this)
    }

    function _() {
        f.call(this)
    }

    function S() {}

    function w() {}

    function x() {}
    /*

     Copyright (C) 2010 The Libphonenumber Authors.

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    function $() {
        this.a = {}
    }

    function A(n) {
        return 0 == n.length || un.test(n)
    }

    function N(n, l) {
        if (null == l) return null;
        l = l.toUpperCase();
        var t = n.a[l];
        if (null == t) {
            if (t = ln[l], null == t) return null;
            t = (new x).a(_.j(), t), n.a[l] = t
        }
        return t
    }

    function j(n) {
        return n = nn[n], null == n ? "ZZ" : n[0]
    }

    function R(n) {
        this.H = RegExp(" "), this.C = "", this.m = new t, this.w = "", this.i = new t, this.u = new t, this.l = !0, this.A = this.o = this.F = !1, this.G = $.b(), this.s = 0, this.b = new t, this.B = !1, this.h = "", this.a = new t, this.f = [], this.D = n, this.J = this.g = E(this, this.D)
    }

    function E(n, l) {
        var t;
        if (null != l && isNaN(l) && l.toUpperCase() in ln) {
            if (t = N(n.G, l), null == t) throw Error("Invalid region code: " + l);
            t = g(t, 10)
        } else t = 0;
        return t = N(n.G, j(t)), null != t ? t : an
    }

    function B(n) {
        for (var l = n.f.length, t = 0; t < l; ++t) {
            var r = n.f[t],
                u = g(r, 1);
            if (n.w == u) return !1;
            var i;
            i = n;
            var a = r,
                o = g(a, 1);
            if (-1 != o.indexOf("|")) i = !1;
            else {
                o = o.replace(on, "\\d"), o = o.replace(sn, "\\d"), e(i.m);
                var s;
                s = i;
                var a = g(a, 2),
                    f = "999999999999999".match(o)[0];
                f.length < s.a.b.length ? s = "" : (s = f.replace(new RegExp(o, "g"), a), s = s.replace(RegExp("9", "g"), " ")), 0 < s.length ? (i.m.a(s), i = !0) : i = !1
            }
            if (i) return n.w = u, n.B = pn.test(h(r, 4)), n.s = 0, !0
        }
        return n.l = !1
    }

    function F(n, l) {
        for (var t = [], e = l.length - 3, r = n.f.length, u = 0; u < r; ++u) {
            var i = n.f[u];
            0 == m(i, 3) ? t.push(n.f[u]) : (i = h(i, 3, Math.min(e, m(i, 3) - 1)), 0 == l.search(i) && t.push(n.f[u]))
        }
        n.f = t
    }

    function C(n, l) {
        n.i.a(l);
        var t = l;
        if (rn.test(t) || 1 == n.i.b.length && en.test(t)) {
            var r, t = l;
            "+" == t ? (r = t, n.u.a(t)) : (r = tn[t], n.u.a(r), n.a.a(r)), l = r
        } else n.l = !1, n.F = !0;
        if (!n.l) {
            if (!n.F)
                if (Z(n)) {
                    if (G(n)) return I(n)
                } else if (0 < n.h.length && (t = n.a.toString(), e(n.a), n.a.a(n.h), n.a.a(t), t = n.b.toString(), r = t.lastIndexOf(n.h), e(n.b), n.b.a(t.substring(0, r))), n.h != V(n)) return n.b.a(" "), I(n);
            return n.i.toString()
        }
        switch (n.u.b.length) {
            case 0:
            case 1:
            case 2:
                return n.i.toString();
            case 3:
                if (!Z(n)) return n.h = V(n), K(n);
                n.A = !0;
            default:
                return n.A ? (G(n) && (n.A = !1), n.b.toString() + n.a.toString()) : 0 < n.f.length ? (t = H(n, l), r = D(n), 0 < r.length ? r : (F(n, n.a.toString()), B(n) ? M(n) : n.l ? U(n, t) : n.i.toString())) : K(n)
        }
    }

    function I(n) {
        return n.l = !0, n.A = !1, n.f = [], n.s = 0, e(n.m), n.w = "", K(n)
    }

    function D(n) {
        for (var l = n.a.toString(), t = n.f.length, e = 0; e < t; ++e) {
            var r = n.f[e],
                u = g(r, 1);
            if (new RegExp("^(?:" + u + ")$").test(l)) return n.B = pn.test(h(r, 4)), l = l.replace(new RegExp(u, "g"), h(r, 2)), U(n, l)
        }
        return ""
    }

    function U(n, l) {
        var t = n.b.b.length;
        return n.B && 0 < t && " " != n.b.toString().charAt(t - 1) ? n.b + " " + l : n.b + l
    }

    function K(n) {
        var l = n.a.toString();
        if (3 <= l.length) {
            for (var t = n.o && 0 == n.h.length && 0 < m(n.g, 20) ? c(n.g, 20) || [] : c(n.g, 19) || [], e = t.length, r = 0; r < e; ++r) {
                var u = t[r];
                0 < n.h.length && A(g(u, 4)) && !h(u, 6) && null == u.a[5] || (0 != n.h.length || n.o || A(g(u, 4)) || h(u, 6)) && fn.test(g(u, 2)) && n.f.push(u)
            }
            return F(n, l), l = D(n), 0 < l.length ? l : B(n) ? M(n) : n.i.toString()
        }
        return U(n, l)
    }

    function M(n) {
        var l = n.a.toString(),
            t = l.length;
        if (0 < t) {
            for (var e = "", r = 0; r < t; r++) e = H(n, l.charAt(r));
            return n.l ? U(n, e) : n.i.toString()
        }
        return n.b.toString()
    }

    function V(n) {
        var l, t = n.a.toString(),
            r = 0;
        return 1 != h(n.g, 10) ? l = !1 : (l = n.a.toString(), l = "1" == l.charAt(0) && "0" != l.charAt(1) && "1" != l.charAt(1)), l ? (r = 1, n.b.a("1").a(" "), n.o = !0) : null != n.g.a[15] && (l = new RegExp("^(?:" + h(n.g, 15) + ")"), l = t.match(l), null != l && null != l[0] && 0 < l[0].length && (n.o = !0, r = l[0].length, n.b.a(t.substring(0, r)))), e(n.a), n.a.a(t.substring(r)), t.substring(0, r)
    }

    function Z(n) {
        var l = n.u.toString(),
            t = new RegExp("^(?:\\+|" + h(n.g, 11) + ")"),
            t = l.match(t);
        return null != t && null != t[0] && 0 < t[0].length && (n.o = !0, t = t[0].length, e(n.a), n.a.a(l.substring(t)), e(n.b), n.b.a(l.substring(0, t)), "+" != l.charAt(0) && n.b.a(" "), !0)
    }

    function G(n) {
        if (0 == n.a.b.length) return !1;
        var l, r = new t;
        n: {
            if (l = n.a.toString(), 0 != l.length && "0" != l.charAt(0))
                for (var u, i = l.length, a = 1; 3 >= a && a <= i; ++a)
                    if (u = parseInt(l.substring(0, a), 10), u in nn) {
                        r.a(l.substring(a)), l = u;
                        break n
                    } l = 0
        }
        return 0 != l && (e(n.a), n.a.a(r.toString()), r = j(l), "001" == r ? n.g = N(n.G, "" + l) : r != n.D && (n.g = E(n, r)), n.b.a("" + l).a(" "), n.h = "", !0)
    }

    function H(n, l) {
        var t = n.m.toString();
        if (0 <= t.substring(n.s).search(n.H)) {
            var r = t.search(n.H),
                t = t.replace(n.H, l);
            return e(n.m), n.m.a(t), n.s = r, t.substring(0, n.s + 1)
        }
        return 1 == n.f.length && (n.l = !1), n.w = "", n.i.toString()
    }
    var P = this;
    t.prototype.b = "", t.prototype.set = function(n) {
        this.b = "" + n
    }, t.prototype.a = function(n, l, t) {
        if (this.b += String(n), null != l)
            for (var e = 1; e < arguments.length; e++) this.b += arguments[e];
        return this
    }, t.prototype.toString = function() {
        return this.b
    };
    var q = 1,
        T = 2,
        Y = 3,
        k = 4,
        J = 6,
        L = 16,
        O = 18;
    f.prototype.set = function(n, l) {
        b(this, n.b, l)
    }, f.prototype.clone = function() {
        var n = new this.constructor;
        return n != this && (n.a = {}, n.b && (n.b = {}), p(n, this)), n
    }, l(y, f);
    var z = null;
    l(v, f);
    var Q = null;
    l(_, f);
    var W = null;
    y.prototype.j = function() {
        var n = z;
        return n || (z = n = d(y, {
            0: {
                name: "NumberFormat",
                I: "i18n.phonenumbers.NumberFormat"
            },
            1: {
                name: "pattern",
                required: !0,
                c: 9,
                type: String
            },
            2: {
                name: "format",
                required: !0,
                c: 9,
                type: String
            },
            3: {
                name: "leading_digits_pattern",
                v: !0,
                c: 9,
                type: String
            },
            4: {
                name: "national_prefix_formatting_rule",
                c: 9,
                type: String
            },
            6: {
                name: "national_prefix_optional_when_formatting",
                c: 8,
                defaultValue: !1,
                type: Boolean
            },
            5: {
                name: "domestic_carrier_code_formatting_rule",
                c: 9,
                type: String
            }
        })), n
    }, y.j = y.prototype.j, v.prototype.j = function() {
        var n = Q;
        return n || (Q = n = d(v, {
            0: {
                name: "PhoneNumberDesc",
                I: "i18n.phonenumbers.PhoneNumberDesc"
            },
            2: {
                name: "national_number_pattern",
                c: 9,
                type: String
            },
            9: {
                name: "possible_length",
                v: !0,
                c: 5,
                type: Number
            },
            10: {
                name: "possible_length_local_only",
                v: !0,
                c: 5,
                type: Number
            },
            6: {
                name: "example_number",
                c: 9,
                type: String
            }
        })), n
    }, v.j = v.prototype.j, _.prototype.j = function() {
        var n = W;
        return n || (W = n = d(_, {
            0: {
                name: "PhoneMetadata",
                I: "i18n.phonenumbers.PhoneMetadata"
            },
            1: {
                name: "general_desc",
                c: 11,
                type: v
            },
            2: {
                name: "fixed_line",
                c: 11,
                type: v
            },
            3: {
                name: "mobile",
                c: 11,
                type: v
            },
            4: {
                name: "toll_free",
                c: 11,
                type: v
            },
            5: {
                name: "premium_rate",
                c: 11,
                type: v
            },
            6: {
                name: "shared_cost",
                c: 11,
                type: v
            },
            7: {
                name: "personal_number",
                c: 11,
                type: v
            },
            8: {
                name: "voip",
                c: 11,
                type: v
            },
            21: {
                name: "pager",
                c: 11,
                type: v
            },
            25: {
                name: "uan",
                c: 11,
                type: v
            },
            27: {
                name: "emergency",
                c: 11,
                type: v
            },
            28: {
                name: "voicemail",
                c: 11,
                type: v
            },
            29: {
                name: "short_code",
                c: 11,
                type: v
            },
            30: {
                name: "standard_rate",
                c: 11,
                type: v
            },
            31: {
                name: "carrier_specific",
                c: 11,
                type: v
            },
            33: {
                name: "sms_services",
                c: 11,
                type: v
            },
            24: {
                name: "no_international_dialling",
                c: 11,
                type: v
            },
            9: {
                name: "id",
                required: !0,
                c: 9,
                type: String
            },
            10: {
                name: "country_code",
                c: 5,
                type: Number
            },
            11: {
                name: "international_prefix",
                c: 9,
                type: String
            },
            17: {
                name: "preferred_international_prefix",
                c: 9,
                type: String
            },
            12: {
                name: "national_prefix",
                c: 9,
                type: String
            },
            13: {
                name: "preferred_extn_prefix",
                c: 9,
                type: String
            },
            15: {
                name: "national_prefix_for_parsing",
                c: 9,
                type: String
            },
            16: {
                name: "national_prefix_transform_rule",
                c: 9,
                type: String
            },
            18: {
                name: "same_mobile_and_fixed_line_pattern",
                c: 8,
                defaultValue: !1,
                type: Boolean
            },
            19: {
                name: "number_format",
                v: !0,
                c: 11,
                type: y
            },
            20: {
                name: "intl_number_format",
                v: !0,
                c: 11,
                type: y
            },
            22: {
                name: "main_country_for_code",
                c: 8,
                defaultValue: !1,
                type: Boolean
            },
            23: {
                name: "leading_digits",
                c: 9,
                type: String
            },
            26: {
                name: "leading_zero_possible",
                c: 8,
                defaultValue: !1,
                type: Boolean
            }
        })), n
    }, _.j = _.prototype.j, S.prototype.a = function(n) {
        throw new n.b, Error("Unimplemented")
    }, S.prototype.b = function(n, l) {
        if (11 == n.a || 10 == n.a) return l instanceof f ? l : this.a(n.i.prototype.j(), l);
        if (14 == n.a) {
            if ("string" == typeof l && X.test(l)) {
                var t = Number(l);
                if (0 < t) return t
            }
            return l
        }
        if (!n.h) return l;
        if (t = n.i, t === String) {
            if ("number" == typeof l) return String(l)
        } else if (t === Number && "string" == typeof l && ("Infinity" === l || "-Infinity" === l || "NaN" === l || X.test(l))) return Number(l);
        return l
    };
    var X = /^-?[0-9]+$/;
    l(w, S), w.prototype.a = function(n, l) {
        var t = new n.b;
        return t.g = this, t.a = l, t.b = {}, t
    }, l(x, w), x.prototype.b = function(n, l) {
        return 8 == n.a ? !!l : S.prototype.b.apply(this, arguments)
    }, x.prototype.a = function(n, l) {
        return x.M.a.call(this, n, l)
    };
    /*

     Copyright (C) 2010 The Libphonenumber Authors

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var nn = {
            7: ["RU", "KZ"]
        },
        ln = {
            KZ: [null, [null, null, "(?:33622|(?:7\\d|80)\\d{3})\\d{5}", null, null, null, null, null, null, [10]],
                [null, null, "(?:33622|7(?:1(?:0(?:[23]\\d|4[0-3]|59|63)|1(?:[23]\\d|4[0-79]|59)|2(?:[23]\\d|59)|3(?:2\\d|3[0-79]|4[0-35-9]|59)|4(?:[24]\\d|3[013-9]|5[1-9])|5(?:2\\d|3[1-9]|4[0-7]|59)|6(?:[2-4]\\d|5[19]|61)|72\\d|8(?:[27]\\d|3[1-46-9]|4[0-5]))|2(?:1(?:[23]\\d|4[46-9]|5[3469])|2(?:2\\d|3[0679]|46|5[12679])|3(?:[2-4]\\d|5[139])|4(?:2\\d|3[1-35-9]|59)|5(?:[23]\\d|4[0-246-8]|59|61)|6(?:2\\d|3[1-9]|4[0-4]|59)|7(?:[2379]\\d|40|5[279])|8(?:[23]\\d|4[0-3]|59)|9(?:2\\d|3[124578]|59))))\\d{5}", null, null, null, "7123456789"],
                [null, null, "7(?:0[0-2578]|47|6[02-4]|7[15-8]|85)\\d{7}", null, null, null, "7710009998"],
                [null, null, "800\\d{7}", null, null, null, "8001234567"],
                [null, null, "809\\d{7}", null, null, null, "8091234567"],
                [null, null, null, null, null, null, null, null, null, [-1]],
                [null, null, "808\\d{7}", null, null, null, "8081234567"],
                [null, null, "751\\d{7}", null, null, null, "7511234567"], "KZ", 7, "810", "8", null, null, "8", null, "8~10", null, null, null, [null, null, null, null, null, null, null, null, null, [-1]], null, "33|7", [null, null, "751\\d{7}"],
                [null, null, null, null, null, null, null, null, null, [-1]], null, null, [null, null, null, null, null, null, null, null, null, [-1]]
            ],
            RU: [null, [null, null, "[347-9]\\d{9}", null, null, null, null, null, null, [10],
                    [7]
                ],
                [null, null, "(?:3(?:0[12]|4[1-35-79]|5[1-3]|65|8[1-58]|9[0145])|4(?:01|1[1356]|2[13467]|7[1-5]|8[1-7]|9[1-689])|8(?:1[1-8]|2[01]|3[13-6]|4[0-8]|5[15]|6[1-35-79]|7[1-37-9]))\\d{7}", null, null, null, "3011234567", null, null, null, [7]],
                [null, null, "9\\d{9}", null, null, null, "9123456789"],
                [null, null, "80[04]\\d{7}", null, null, null, "8001234567"],
                [null, null, "80[39]\\d{7}", null, null, null, "8091234567"],
                [null, null, null, null, null, null, null, null, null, [-1]],
                [null, null, "808\\d{7}", null, null, null, "8081234567"],
                [null, null, null, null, null, null, null, null, null, [-1]], "RU", 7, "810", "8", null, null, "8", null, "8~10", null, [
                    [null, "(\\d{3})(\\d{2})(\\d{2})", "$1-$2-$3"],
                    [null, "(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "8 ($1)", null, 1],
                    [null, "(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[3489]"], "8 ($1)", null, 1]
                ],
                [
                    [null, "(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "8 ($1)", null, 1],
                    [null, "(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[3489]"], "8 ($1)", null, 1]
                ],
                [null, null, null, null, null, null, null, null, null, [-1]], 1, "3[04-689]|[489]", [null, null, null, null, null, null, null, null, null, [-1]],
                [null, null, null, null, null, null, null, null, null, [-1]], null, null, [null, null, null, null, null, null, null, null, null, [-1]]
            ]
        };
    $.b = function() {
        return $.a ? $.a : $.a = new $
    };
    var tn = {
            0: "0",
            1: "1",
            2: "2",
            3: "3",
            4: "4",
            5: "5",
            6: "6",
            7: "7",
            8: "8",
            9: "9",
            "０": "0",
            "１": "1",
            "２": "2",
            "３": "3",
            "４": "4",
            "５": "5",
            "６": "6",
            "７": "7",
            "８": "8",
            "９": "9",
            "٠": "0",
            "١": "1",
            "٢": "2",
            "٣": "3",
            "٤": "4",
            "٥": "5",
            "٦": "6",
            "٧": "7",
            "٨": "8",
            "٩": "9",
            "۰": "0",
            "۱": "1",
            "۲": "2",
            "۳": "3",
            "۴": "4",
            "۵": "5",
            "۶": "6",
            "۷": "7",
            "۸": "8",
            "۹": "9"
        },
        en = RegExp("[+＋]+"),
        rn = RegExp("([0-9０-９٠-٩۰-۹])"),
        un = /^\(?\$1\)?$/,
        an = new _;
    b(an, 11, "NA");
    var on = /\[([^\[\]])*\]/g,
        sn = /\d(?=[^,}][^,}])/g,
        fn = RegExp("^[-x‐-―−ー－-／  ­​⁠　()（）［］.\\[\\]/~⁓∼～]*(\\$\\d[-x‐-―−ー－-／  ­​⁠　()（）［］.\\[\\]/~⁓∼～]*)+$"),
        pn = /[- ]/;
    R.prototype.K = function() {
        this.C = "", e(this.i), e(this.u), e(this.m), this.s = 0, this.w = "", e(this.b), this.h = "", e(this.a), this.l = !0, this.A = this.o = this.F = !1, this.f = [], this.B = !1, this.g != this.J && (this.g = E(this, this.D))
    }, R.prototype.L = function(n) {
        return this.C = C(this, n)
    }, n("Cleave.AsYouTypeFormatter", R), n("Cleave.AsYouTypeFormatter.prototype.inputDigit", R.prototype.L), n("Cleave.AsYouTypeFormatter.prototype.clear", R.prototype.K)
}.call("object" == typeof global && global ? global : window);