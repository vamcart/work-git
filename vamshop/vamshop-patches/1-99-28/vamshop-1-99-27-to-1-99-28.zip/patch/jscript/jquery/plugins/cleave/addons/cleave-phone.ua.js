! function() {
    function n(n, t) {
        var e = n.split("."),
            r = U;
        e[0] in r || !r.execScript || r.execScript("var " + e[0]);
        for (var l; e.length && (l = e.shift());) e.length || void 0 === t ? r = r[l] ? r[l] : r[l] = {} : r[l] = t
    }

    function t(n, t) {
        function e() {}
        e.prototype = t.prototype, n.M = t.prototype, n.prototype = new e, n.prototype.constructor = n, n.N = function(n, e, r) {
            for (var l = Array(arguments.length - 2), i = 2; i < arguments.length; i++) l[i - 2] = arguments[i];
            return t.prototype[e].apply(n, l)
        }
    }

    function e(n, t) {
        null != n && this.a.apply(this, arguments)
    }

    function r(n) {
        n.b = ""
    }

    function l(n, t) {
        n.sort(t || i)
    }

    function i(n, t) {
        return n > t ? 1 : n < t ? -1 : 0
    }

    function a(n) {
        var t, e = [],
            r = 0;
        for (t in n) e[r++] = n[t];
        return e
    }

    function u(n, t) {
        this.b = n, this.a = {};
        for (var e = 0; e < t.length; e++) {
            var r = t[e];
            this.a[r.b] = r
        }
    }

    function o(n) {
        return n = a(n.a), l(n, function(n, t) {
            return n.b - t.b
        }), n
    }

    function s(n, t) {
        switch (this.b = n, this.g = !!t.v, this.a = t.c, this.i = t.type, this.h = !1, this.a) {
            case J:
            case K:
            case L:
            case O:
            case Z:
            case k:
            case Y:
                this.h = !0
        }
        this.f = t.defaultValue
    }

    function f() {
        this.a = {}, this.f = this.j().a, this.b = this.g = null
    }

    function p(n, t) {
        for (var e = o(n.j()), r = 0; r < e.length; r++) {
            var l = e[r],
                i = l.b;
            if (null != t.a[i]) {
                n.b && delete n.b[l.b];
                var a = 11 == l.a || 10 == l.a;
                if (l.g)
                    for (var l = c(t, i) || [], u = 0; u < l.length; u++) {
                        var s = n,
                            f = i,
                            h = a ? l[u].clone() : l[u];
                        s.a[f] || (s.a[f] = []), s.a[f].push(h), s.b && delete s.b[f]
                    } else l = c(t, i), a ? (a = c(n, i)) ? p(a, l) : b(n, i, l.clone()) : b(n, i, l)
            }
        }
    }

    function c(n, t) {
        var e = n.a[t];
        if (null == e) return null;
        if (n.g) {
            if (!(t in n.b)) {
                var r = n.g,
                    l = n.f[t];
                if (null != e)
                    if (l.g) {
                        for (var i = [], a = 0; a < e.length; a++) i[a] = r.b(l, e[a]);
                        e = i
                    } else e = r.b(l, e);
                return n.b[t] = e
            }
            return n.b[t]
        }
        return e
    }

    function h(n, t, e) {
        var r = c(n, t);
        return n.f[t].g ? r[e || 0] : r
    }

    function g(n, t) {
        var e;
        if (null != n.a[t]) e = h(n, t, void 0);
        else n: {
            if (e = n.f[t], void 0 === e.f) {
                var r = e.i;
                if (r === Boolean) e.f = !1;
                else if (r === Number) e.f = 0;
                else {
                    if (r !== String) {
                        e = new r;
                        break n
                    }
                    e.f = e.h ? "0" : ""
                }
            }
            e = e.f
        }
        return e
    }

    function m(n, t) {
        return n.f[t].g ? null != n.a[t] ? n.a[t].length : 0 : null != n.a[t] ? 1 : 0
    }

    function b(n, t, e) {
        n.a[t] = e, n.b && (n.b[t] = e)
    }

    function y(n, t) {
        var e, r = [];
        for (e in t) 0 != e && r.push(new s(e, t[e]));
        return new u(n, r)
    }
    /*

     Protocol Buffer 2 Copyright 2008 Google Inc.
     All other code copyright its respective owners.
     Copyright (C) 2010 The Libphonenumber Authors

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    function v() {
        f.call(this)
    }

    function d() {
        f.call(this)
    }

    function _() {
        f.call(this)
    }

    function S() {}

    function w() {}

    function x() {}
    /*

     Copyright (C) 2010 The Libphonenumber Authors.

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    function A() {
        this.a = {}
    }

    function N(n) {
        return 0 == n.length || an.test(n)
    }

    function $(n, t) {
        if (null == t) return null;
        t = t.toUpperCase();
        var e = n.a[t];
        if (null == e) {
            if (e = tn[t], null == e) return null;
            e = (new x).a(_.j(), e), n.a[t] = e
        }
        return e
    }

    function j(n) {
        return n = nn[n], null == n ? "ZZ" : n[0]
    }

    function E(n) {
        this.H = RegExp(" "), this.C = "", this.m = new e, this.w = "", this.i = new e, this.u = new e, this.l = !0, this.A = this.o = this.F = !1, this.G = A.b(), this.s = 0, this.b = new e, this.B = !1, this.h = "", this.a = new e, this.f = [], this.D = n, this.J = this.g = B(this, this.D)
    }

    function B(n, t) {
        var e;
        if (null != t && isNaN(t) && t.toUpperCase() in tn) {
            if (e = $(n.G, t), null == e) throw Error("Invalid region code: " + t);
            e = g(e, 10)
        } else e = 0;
        return e = $(n.G, j(e)), null != e ? e : un
    }

    function D(n) {
        for (var t = n.f.length, e = 0; e < t; ++e) {
            var l = n.f[e],
                i = g(l, 1);
            if (n.w == i) return !1;
            var a;
            a = n;
            var u = l,
                o = g(u, 1);
            if (-1 != o.indexOf("|")) a = !1;
            else {
                o = o.replace(on, "\\d"), o = o.replace(sn, "\\d"), r(a.m);
                var s;
                s = a;
                var u = g(u, 2),
                    f = "999999999999999".match(o)[0];
                f.length < s.a.b.length ? s = "" : (s = f.replace(new RegExp(o, "g"), u), s = s.replace(RegExp("9", "g"), " ")), 0 < s.length ? (a.m.a(s), a = !0) : a = !1
            }
            if (a) return n.w = i, n.B = pn.test(h(l, 4)), n.s = 0, !0
        }
        return n.l = !1
    }

    function R(n, t) {
        for (var e = [], r = t.length - 3, l = n.f.length, i = 0; i < l; ++i) {
            var a = n.f[i];
            0 == m(a, 3) ? e.push(n.f[i]) : (a = h(a, 3, Math.min(r, m(a, 3) - 1)), 0 == t.search(a) && e.push(n.f[i]))
        }
        n.f = e
    }

    function F(n, t) {
        n.i.a(t);
        var e = t;
        if (ln.test(e) || 1 == n.i.b.length && rn.test(e)) {
            var l, e = t;
            "+" == e ? (l = e, n.u.a(e)) : (l = en[e], n.u.a(l), n.a.a(l)), t = l
        } else n.l = !1, n.F = !0;
        if (!n.l) {
            if (!n.F)
                if (P(n)) {
                    if (q(n)) return C(n)
                } else if (0 < n.h.length && (e = n.a.toString(), r(n.a), n.a.a(n.h), n.a.a(e), e = n.b.toString(), l = e.lastIndexOf(n.h), r(n.b), n.b.a(e.substring(0, l))), n.h != H(n)) return n.b.a(" "), C(n);
            return n.i.toString()
        }
        switch (n.u.b.length) {
            case 0:
            case 1:
            case 2:
                return n.i.toString();
            case 3:
                if (!P(n)) return n.h = H(n), V(n);
                n.A = !0;
            default:
                return n.A ? (q(n) && (n.A = !1), n.b.toString() + n.a.toString()) : 0 < n.f.length ? (e = T(n, t), l = I(n), 0 < l.length ? l : (R(n, n.a.toString()), D(n) ? G(n) : n.l ? M(n, e) : n.i.toString())) : V(n)
        }
    }

    function C(n) {
        return n.l = !0, n.A = !1, n.f = [], n.s = 0, r(n.m), n.w = "", V(n)
    }

    function I(n) {
        for (var t = n.a.toString(), e = n.f.length, r = 0; r < e; ++r) {
            var l = n.f[r],
                i = g(l, 1);
            if (new RegExp("^(?:" + i + ")$").test(t)) return n.B = pn.test(h(l, 4)), t = t.replace(new RegExp(i, "g"), h(l, 2)), M(n, t)
        }
        return ""
    }

    function M(n, t) {
        var e = n.b.b.length;
        return n.B && 0 < e && " " != n.b.toString().charAt(e - 1) ? n.b + " " + t : n.b + t
    }

    function V(n) {
        var t = n.a.toString();
        if (3 <= t.length) {
            for (var e = n.o && 0 == n.h.length && 0 < m(n.g, 20) ? c(n.g, 20) || [] : c(n.g, 19) || [], r = e.length, l = 0; l < r; ++l) {
                var i = e[l];
                0 < n.h.length && N(g(i, 4)) && !h(i, 6) && null == i.a[5] || (0 != n.h.length || n.o || N(g(i, 4)) || h(i, 6)) && fn.test(g(i, 2)) && n.f.push(i)
            }
            return R(n, t), t = I(n), 0 < t.length ? t : D(n) ? G(n) : n.i.toString()
        }
        return M(n, t)
    }

    function G(n) {
        var t = n.a.toString(),
            e = t.length;
        if (0 < e) {
            for (var r = "", l = 0; l < e; l++) r = T(n, t.charAt(l));
            return n.l ? M(n, r) : n.i.toString()
        }
        return n.b.toString()
    }

    function H(n) {
        var t, e = n.a.toString(),
            l = 0;
        return 1 != h(n.g, 10) ? t = !1 : (t = n.a.toString(), t = "1" == t.charAt(0) && "0" != t.charAt(1) && "1" != t.charAt(1)), t ? (l = 1, n.b.a("1").a(" "), n.o = !0) : null != n.g.a[15] && (t = new RegExp("^(?:" + h(n.g, 15) + ")"), t = e.match(t), null != t && null != t[0] && 0 < t[0].length && (n.o = !0, l = t[0].length, n.b.a(e.substring(0, l)))), r(n.a), n.a.a(e.substring(l)), e.substring(0, l)
    }

    function P(n) {
        var t = n.u.toString(),
            e = new RegExp("^(?:\\+|" + h(n.g, 11) + ")"),
            e = t.match(e);
        return null != e && null != e[0] && 0 < e[0].length && (n.o = !0, e = e[0].length, r(n.a), n.a.a(t.substring(e)), r(n.b), n.b.a(t.substring(0, e)), "+" != t.charAt(0) && n.b.a(" "), !0)
    }

    function q(n) {
        if (0 == n.a.b.length) return !1;
        var t, l = new e;
        n: {
            if (t = n.a.toString(), 0 != t.length && "0" != t.charAt(0))
                for (var i, a = t.length, u = 1; 3 >= u && u <= a; ++u)
                    if (i = parseInt(t.substring(0, u), 10), i in nn) {
                        l.a(t.substring(u)), t = i;
                        break n
                    } t = 0
        }
        return 0 != t && (r(n.a), n.a.a(l.toString()), l = j(t), "001" == l ? n.g = $(n.G, "" + t) : l != n.D && (n.g = B(n, l)), n.b.a("" + t).a(" "), n.h = "", !0)
    }

    function T(n, t) {
        var e = n.m.toString();
        if (0 <= e.substring(n.s).search(n.H)) {
            var l = e.search(n.H),
                e = e.replace(n.H, t);
            return r(n.m), n.m.a(e), n.s = l, e.substring(0, n.s + 1)
        }
        return 1 == n.f.length && (n.l = !1), n.w = "", n.i.toString()
    }
    var U = this;
    e.prototype.b = "", e.prototype.set = function(n) {
        this.b = "" + n
    }, e.prototype.a = function(n, t, e) {
        if (this.b += String(n), null != t)
            for (var r = 1; r < arguments.length; r++) this.b += arguments[r];
        return this
    }, e.prototype.toString = function() {
        return this.b
    };
    var Y = 1,
        k = 2,
        J = 3,
        K = 4,
        L = 6,
        O = 16,
        Z = 18;
    f.prototype.set = function(n, t) {
        b(this, n.b, t)
    }, f.prototype.clone = function() {
        var n = new this.constructor;
        return n != this && (n.a = {}, n.b && (n.b = {}), p(n, this)), n
    }, t(v, f);
    var z = null;
    t(d, f);
    var Q = null;
    t(_, f);
    var W = null;
    v.prototype.j = function() {
        var n = z;
        return n || (z = n = y(v, {
            0: {
                name: "NumberFormat",
                I: "i18n.phonenumbers.NumberFormat"
            },
            1: {
                name: "pattern",
                required: !0,
                c: 9,
                type: String
            },
            2: {
                name: "format",
                required: !0,
                c: 9,
                type: String
            },
            3: {
                name: "leading_digits_pattern",
                v: !0,
                c: 9,
                type: String
            },
            4: {
                name: "national_prefix_formatting_rule",
                c: 9,
                type: String
            },
            6: {
                name: "national_prefix_optional_when_formatting",
                c: 8,
                defaultValue: !1,
                type: Boolean
            },
            5: {
                name: "domestic_carrier_code_formatting_rule",
                c: 9,
                type: String
            }
        })), n
    }, v.j = v.prototype.j, d.prototype.j = function() {
        var n = Q;
        return n || (Q = n = y(d, {
            0: {
                name: "PhoneNumberDesc",
                I: "i18n.phonenumbers.PhoneNumberDesc"
            },
            2: {
                name: "national_number_pattern",
                c: 9,
                type: String
            },
            9: {
                name: "possible_length",
                v: !0,
                c: 5,
                type: Number
            },
            10: {
                name: "possible_length_local_only",
                v: !0,
                c: 5,
                type: Number
            },
            6: {
                name: "example_number",
                c: 9,
                type: String
            }
        })), n
    }, d.j = d.prototype.j, _.prototype.j = function() {
        var n = W;
        return n || (W = n = y(_, {
            0: {
                name: "PhoneMetadata",
                I: "i18n.phonenumbers.PhoneMetadata"
            },
            1: {
                name: "general_desc",
                c: 11,
                type: d
            },
            2: {
                name: "fixed_line",
                c: 11,
                type: d
            },
            3: {
                name: "mobile",
                c: 11,
                type: d
            },
            4: {
                name: "toll_free",
                c: 11,
                type: d
            },
            5: {
                name: "premium_rate",
                c: 11,
                type: d
            },
            6: {
                name: "shared_cost",
                c: 11,
                type: d
            },
            7: {
                name: "personal_number",
                c: 11,
                type: d
            },
            8: {
                name: "voip",
                c: 11,
                type: d
            },
            21: {
                name: "pager",
                c: 11,
                type: d
            },
            25: {
                name: "uan",
                c: 11,
                type: d
            },
            27: {
                name: "emergency",
                c: 11,
                type: d
            },
            28: {
                name: "voicemail",
                c: 11,
                type: d
            },
            29: {
                name: "short_code",
                c: 11,
                type: d
            },
            30: {
                name: "standard_rate",
                c: 11,
                type: d
            },
            31: {
                name: "carrier_specific",
                c: 11,
                type: d
            },
            33: {
                name: "sms_services",
                c: 11,
                type: d
            },
            24: {
                name: "no_international_dialling",
                c: 11,
                type: d
            },
            9: {
                name: "id",
                required: !0,
                c: 9,
                type: String
            },
            10: {
                name: "country_code",
                c: 5,
                type: Number
            },
            11: {
                name: "international_prefix",
                c: 9,
                type: String
            },
            17: {
                name: "preferred_international_prefix",
                c: 9,
                type: String
            },
            12: {
                name: "national_prefix",
                c: 9,
                type: String
            },
            13: {
                name: "preferred_extn_prefix",
                c: 9,
                type: String
            },
            15: {
                name: "national_prefix_for_parsing",
                c: 9,
                type: String
            },
            16: {
                name: "national_prefix_transform_rule",
                c: 9,
                type: String
            },
            18: {
                name: "same_mobile_and_fixed_line_pattern",
                c: 8,
                defaultValue: !1,
                type: Boolean
            },
            19: {
                name: "number_format",
                v: !0,
                c: 11,
                type: v
            },
            20: {
                name: "intl_number_format",
                v: !0,
                c: 11,
                type: v
            },
            22: {
                name: "main_country_for_code",
                c: 8,
                defaultValue: !1,
                type: Boolean
            },
            23: {
                name: "leading_digits",
                c: 9,
                type: String
            },
            26: {
                name: "leading_zero_possible",
                c: 8,
                defaultValue: !1,
                type: Boolean
            }
        })), n
    }, _.j = _.prototype.j, S.prototype.a = function(n) {
        throw new n.b, Error("Unimplemented")
    }, S.prototype.b = function(n, t) {
        if (11 == n.a || 10 == n.a) return t instanceof f ? t : this.a(n.i.prototype.j(), t);
        if (14 == n.a) {
            if ("string" == typeof t && X.test(t)) {
                var e = Number(t);
                if (0 < e) return e
            }
            return t
        }
        if (!n.h) return t;
        if (e = n.i, e === String) {
            if ("number" == typeof t) return String(t)
        } else if (e === Number && "string" == typeof t && ("Infinity" === t || "-Infinity" === t || "NaN" === t || X.test(t))) return Number(t);
        return t
    };
    var X = /^-?[0-9]+$/;
    t(w, S), w.prototype.a = function(n, t) {
        var e = new n.b;
        return e.g = this, e.a = t, e.b = {}, e
    }, t(x, w), x.prototype.b = function(n, t) {
        return 8 == n.a ? !!t : S.prototype.b.apply(this, arguments)
    }, x.prototype.a = function(n, t) {
        return x.M.a.call(this, n, t)
    };
    /*

     Copyright (C) 2010 The Libphonenumber Authors

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var nn = {
            380: ["UA"]
        },
        tn = {
            UA: [null, [null, null, "(?:[235-7]\\d|[89]0)\\d{6}", null, null, null, null, null, null, [8]],
                [null, null, "(?:(?:2[1-9]|3[1-79])\\d|5(?:33|5[257]))\\d{5}", null, null, null, "22212345"],
                [null, null, "(?:562|6\\d\\d|7(?:[189]\\d|6[07]|7[457-9]))\\d{5}", null, null, null, "62112345"],
                [null, null, "800\\d{5}", null, null, null, "80012345"],
                [null, null, "90[056]\\d{5}", null, null, null, "90012345"],
                [null, null, "808\\d{5}", null, null, null, "80812345"],
                [null, null, null, null, null, null, null, null, null, [-1]],
                [null, null, "3[08]\\d{6}", null, null, null, "30123456"], "UA", 380, "00", "0", null, null, "0", null, null, null, [
                    [null, "(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["22|3"], "0$1"],
                    [null, "(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[25-7]"], "0$1"],
                    [null, "(\\d{3})(\\d{5})", "$1 $2", ["[89]"], "0$1"]
                ], null, [null, null, null, null, null, null, null, null, null, [-1]], null, null, [null, null, null, null, null, null, null, null, null, [-1]],
                [null, null, "803\\d{5}", null, null, null, "80312345"], null, null, [null, null, null, null, null, null, null, null, null, [-1]]
            ]
        };
    A.b = function() {
        return A.a ? A.a : A.a = new A
    };
    var en = {
            0: "0",
            1: "1",
            2: "2",
            3: "3",
            4: "4",
            5: "5",
            6: "6",
            7: "7",
            8: "8",
            9: "9",
            "０": "0",
            "１": "1",
            "２": "2",
            "３": "3",
            "４": "4",
            "５": "5",
            "６": "6",
            "７": "7",
            "８": "8",
            "９": "9",
            "٠": "0",
            "١": "1",
            "٢": "2",
            "٣": "3",
            "٤": "4",
            "٥": "5",
            "٦": "6",
            "٧": "7",
            "٨": "8",
            "٩": "9",
            "۰": "0",
            "۱": "1",
            "۲": "2",
            "۳": "3",
            "۴": "4",
            "۵": "5",
            "۶": "6",
            "۷": "7",
            "۸": "8",
            "۹": "9"
        },
        rn = RegExp("[+＋]+"),
        ln = RegExp("([0-9０-９٠-٩۰-۹])"),
        an = /^\(?\$1\)?$/,
        un = new _;
    b(un, 11, "NA");
    var on = /\[([^\[\]])*\]/g,
        sn = /\d(?=[^,}][^,}])/g,
        fn = RegExp("^[-x‐-―−ー－-／  ­​⁠　()（）［］.\\[\\]/~⁓∼～]*(\\$\\d[-x‐-―−ー－-／  ­​⁠　()（）［］.\\[\\]/~⁓∼～]*)+$"),
        pn = /[- ]/;
    E.prototype.K = function() {
        this.C = "", r(this.i), r(this.u), r(this.m), this.s = 0, this.w = "", r(this.b), this.h = "", r(this.a), this.l = !0, this.A = this.o = this.F = !1, this.f = [], this.B = !1, this.g != this.J && (this.g = B(this, this.D))
    }, E.prototype.L = function(n) {
        return this.C = F(this, n)
    }, n("Cleave.AsYouTypeFormatter", E), n("Cleave.AsYouTypeFormatter.prototype.inputDigit", E.prototype.L), n("Cleave.AsYouTypeFormatter.prototype.clear", E.prototype.K)
}.call("object" == typeof global && global ? global : window);