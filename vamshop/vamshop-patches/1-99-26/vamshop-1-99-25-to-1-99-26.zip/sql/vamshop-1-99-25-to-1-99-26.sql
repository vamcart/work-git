SET SQL_MODE = "";

ALTER TABLE admin_access ADD faq1 INT( 1 ) NOT NULL;
UPDATE admin_access SET faq1 = 1 WHERE customers_id = 1 LIMIT 1;

DROP TABLE IF EXISTS faq1;
CREATE TABLE `faq1` (
  `faq1_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `question` text NOT NULL,
  `answer` text,
  `faq1_head_title` text,
  `faq1_head_desc` text,
  `faq1_head_keys` text,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `faq1_page_url` varchar(255) DEFAULT NULL,
  `likes` int(3) NOT NULL DEFAULT '0',
  `dislikes` int(3) NOT NULL DEFAULT '0',
  `show_popular_products` tinyint(1) NOT NULL DEFAULT '0',
  `show_discount_products` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(4) NOT NULL DEFAULT '0',
   PRIMARY KEY (faq1_id)  
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

update configuration SET set_function = "vam_cfg_select_option(array(\'true\', \'false\', \'optional\')," where configuration_group_id = 5;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('ACCOUNT_LAST_NAME', 'optional',  5, 1, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\', \'optional\'),');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('ACCOUNT_EMAIL', 'optional', 5, 9, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\', \'optional\'),');
