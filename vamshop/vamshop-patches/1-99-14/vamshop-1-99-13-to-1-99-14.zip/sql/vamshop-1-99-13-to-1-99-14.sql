SET SQL_MODE = "";

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DISPLAY_LIKES', 'true', 1, 41, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DISPLAY_DISLIKES', 'true', 1, 42, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

ALTER TABLE categories ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE categories ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE products ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE products ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE orders ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE orders ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE articles ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE articles ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE authors ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE authors ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE topics ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE topics ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE content_manager ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE content_manager ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE faq ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE faq ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE latest_news ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE latest_news ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE manufacturers ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE manufacturers ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE reviews ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE reviews ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE site_reviews ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE site_reviews ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE article_reviews ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE article_reviews ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE author_reviews ADD likes int(4) DEFAULT "0" NOT NULL;
ALTER TABLE author_reviews ADD dislikes int(4) DEFAULT "0" NOT NULL;

ALTER TABLE specification_description ADD specification_seo_url varchar(255) NOT NULL;
