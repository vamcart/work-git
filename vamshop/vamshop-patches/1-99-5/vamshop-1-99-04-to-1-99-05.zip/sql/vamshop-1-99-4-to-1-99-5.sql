SET SQL_MODE = "";

INSERT INTO `banners` (`banners_title`, `banners_description`, `banners_url`, `banners_image`, `banners_group`, `banners_html_text`, `expires_impressions`, `expires_date`, `date_scheduled`, `date_added`, `date_status_change`, `status`) VALUES
('Слайд 1', 'Описание слайда 1', 'https://vamshop.ru', 'slide1.jpg', 'slider_bootstrap', '', NULL, NULL, NULL, '2019-04-06 23:31:11', NULL, 1),
('Слайд 2', 'Описание слайда 2', 'https://vamshop.ru', 'slide2.jpg', 'slider_bootstrap', '', NULL, NULL, NULL, '2019-04-07 23:02:24', NULL, 1),
('Слайд 3', 'Описание слайда 3', 'https://vamshop.ru', 'slide3.jpg', 'slider_bootstrap', '', NULL, NULL, NULL, '2019-04-07 23:02:50', NULL, 1),
('Скидки', 'Все товары со скидкой', 'https://vamshop.ru', 'slide4.jpg', 'slider_bootstrap', '', NULL, NULL, NULL, '2019-04-07 23:03:55', NULL, 1),
('Популярные', 'Рекомендуемые товары', 'https://vamshop.ru', 'slide5.jpg', 'slider_bootstrap', '', NULL, NULL, NULL, '2019-04-07 23:04:12', NULL, 1);

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DEFAULT_NAVIGATION', 'slide_menu', 1, 38, NULL, '', NULL, 'vam_cfg_select_option(array(\'fullscreen_menu\', \'slide_menu\'),');

ALTER TABLE categories ADD label_id int(3) NOT NULL;
ALTER TABLE categories ADD icon VARCHAR(255) NOT NULL;

DELETE FROM configuration WHERE configuration_key = 'DEFAULT_SLIDER';
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DEFAULT_SLIDER', 'slider_bootstrap', 1, 36, NULL, '', NULL, 'vam_cfg_select_option(array(\'slider_bootstrap\', \'slider_pop_slide\', \'slider_basic\', \'slider_modern_slide_in\', \'slider_parallax_basic\', \'slider_starter_basic\'),');
