SET SQL_MODE = "";

ALTER TABLE admin_access ADD manufacturer_specials INT( 1 ) NOT NULL;
UPDATE admin_access SET manufacturer_specials = 1 WHERE customers_id = 1 LIMIT 1;

drop table if exists special_manufacturer;
create table special_manufacturer (
  special_id int(11) unsigned NOT NULL auto_increment,
  manuf_id int(11) unsigned NOT NULL default '0',
  discount decimal(5,2) NOT NULL default '0.00',
  discount_type enum('p','f') NOT NULL default 'f',
  special_date_added datetime NOT NULL default '0000-00-00 00:00:00',
  special_last_modified datetime NOT NULL default '0000-00-00 00:00:00',
  expire_date datetime NOT NULL default '0000-00-00 00:00:00',
  date_status_change datetime NOT NULL default '0000-00-00 00:00:00',
  status tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (special_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;
