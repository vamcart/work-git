ALTER TABLE coupons ADD sumWithDiscounts tinyint(4) NOT NULL DEFAULT 0;
