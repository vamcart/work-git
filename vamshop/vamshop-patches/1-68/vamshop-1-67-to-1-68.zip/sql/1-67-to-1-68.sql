ALTER TABLE admin_access ADD attributeManager INT( 1 ) NOT NULL;
UPDATE admin_access SET attributeManager = 1 WHERE customers_id = 1 LIMIT 1;

INSERT INTO `configuration` (`configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES
('FILTERS_MAIN_PAGE', 'False', 1610, 135, NULL, '2009-07-06 00:19:30', NULL, 'vam_cfg_select_option(array(''True'', ''False''), ');