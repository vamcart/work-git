SET SQL_MODE = "";

ALTER TABLE block ADD google varchar(255) default '1';
ALTER TABLE block ADD yandex varchar(255) default '1';
ALTER TABLE block ADD either varchar(255) default '1';