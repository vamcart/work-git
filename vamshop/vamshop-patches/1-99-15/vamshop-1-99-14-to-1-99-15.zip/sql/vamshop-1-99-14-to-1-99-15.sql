SET SQL_MODE = "";

ALTER TABLE topics_description ADD topics_meta_title text;
ALTER TABLE topics_description ADD topics_meta_description text;
ALTER TABLE topics_description ADD topics_meta_keywords text;

ALTER TABLE faq ADD faq_head_title TEXT NULL after answer;
ALTER TABLE faq ADD faq_head_desc TEXT NULL after faq_head_title;
ALTER TABLE faq ADD faq_head_keys TEXT NULL after faq_head_desc;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('DISPLAY_LAST_VIEWED', 'true', 17, 24, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

update configuration set configuration_value = "true" where configuration_key = "XSELL_CART";