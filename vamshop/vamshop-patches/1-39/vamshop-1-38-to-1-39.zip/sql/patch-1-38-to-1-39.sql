ALTER TABLE admin_access ADD category_specials INT( 1 ) NOT NULL;
UPDATE admin_access SET category_specials = 1 WHERE customers_id = 1 LIMIT 1;

drop table if exists special_category;
create table special_category (
  special_id int(11) unsigned NOT NULL auto_increment,
  categ_id int(11) unsigned NOT NULL default '0',
  discount decimal(5,2) NOT NULL default '0.00',
  discount_type enum('p','f') NOT NULL default 'f',
  special_date_added datetime NOT NULL default '0000-00-00 00:00:00',
  special_last_modified datetime NOT NULL default '0000-00-00 00:00:00',
  expire_date datetime NOT NULL default '0000-00-00 00:00:00',
  date_status_change datetime NOT NULL default '0000-00-00 00:00:00',
  status tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (special_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

drop table if exists special_product;
create table special_product (
  special_product_id int(11) unsigned NOT NULL auto_increment,
  special_id int(11) unsigned NOT NULL default '0',
  product_id int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (special_product_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_ACTIVE', 'true', 4, 40, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', 'vam_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_WIDTH', '120', 4, 41, '2003-12-15 12:10:45', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_HEIGHT', '80', 4, 42, NULL, '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_BEVEL', '', 4, 43, '2003-12-15 13:14:39', '0000-00-00 00:00:00', '', '');
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_GREYSCALE', '', 4, 44, '2003-12-15 13:13:37', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_ELLIPSE', '', 4, 45, '2003-12-15 13:14:57', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_ROUND_EDGES', '', 4, 46, '2003-12-15 13:19:45', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_MERGE', '', 4, 47, '2003-12-15 12:01:43', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_FRAME', '', 4, 48, '2003-12-15 13:19:37', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_DROP_SHADDOW', '', 4, 49, '2003-12-15 13:15:14', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO  configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('CATEGORIES_IMAGE_THUMBNAIL_MOTION_BLUR', '', 4, 50, '2003-12-15 12:02:19', '0000-00-00 00:00:00', NULL, NULL);

DELETE FROM configuration WHERE configuration_key = 'USE_WYSIWYG';
