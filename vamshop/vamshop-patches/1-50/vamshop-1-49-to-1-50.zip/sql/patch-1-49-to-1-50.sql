ALTER TABLE `address_book` ADD `entry_secondname` VARCHAR(255) NOT NULL AFTER `entry_firstname`;
ALTER TABLE `customers` ADD `customers_secondname` VARCHAR(255) NOT NULL AFTER `customers_firstname`;
ALTER TABLE `orders` ADD `customers_secondname` VARCHAR(255) NOT NULL AFTER `customers_firstname`;
ALTER TABLE `orders` ADD `delivery_secondname` VARCHAR(255) NOT NULL AFTER `delivery_firstname`;
ALTER TABLE `orders` ADD `billing_secondname` VARCHAR(255) NOT NULL AFTER `billing_firstname`;

DROP TABLE IF EXISTS address_format;
CREATE TABLE address_format (
  address_format_id int NOT NULL auto_increment,
  address_format varchar(255) NOT NULL,
  address_summary varchar(255) NOT NULL,
  PRIMARY KEY (address_format_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

INSERT INTO address_format VALUES (1, '$firstname $secondname $lastname$cr$streets$cr$city, $postcode$cr$statecomma$country','$city / $country');
INSERT INTO address_format VALUES (2, '$firstname $secondname $lastname$cr$streets$cr$city, $state    $postcode$cr$country','$city, $state / $country');
INSERT INTO address_format VALUES (3, '$firstname $secondname $lastname$cr$streets$cr$city$cr$postcode - $statecomma$country','$state / $country');
INSERT INTO address_format VALUES (4, '$firstname $secondname $lastname$cr$streets$cr$city ($postcode)$cr$country', '$postcode / $country');
INSERT INTO address_format VALUES (5, '$firstname $secondname $lastname$cr$streets$cr$postcode $city$cr$country','$city / $country');

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('ACCOUNT_SECOND_NAME', 'true',  5, 1, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
