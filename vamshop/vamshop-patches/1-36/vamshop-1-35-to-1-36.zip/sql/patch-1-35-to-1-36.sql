update configuration set configuration_group_id = '4' where configuration_key = 'USE_EP_IMAGE_MANIPULATOR';

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('YML_VENDOR', 'false', '23', '10', NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES   ('YML_REF_ID', 'ref=yml', '23', '11', NULL , '0000-00-00 00:00:00', NULL , NULL);
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('YML_REF_IP', 'true', '23', '12', NULL, '0000-00-00 00:00:00', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

ALTER TABLE categories ADD yml_bid INT(4) DEFAULT '0' NOT NULL;
ALTER TABLE categories ADD yml_cbid INT(4) DEFAULT '0' NOT NULL;

ALTER TABLE products ADD yml_bid INT(4) DEFAULT '0' NOT NULL;
ALTER TABLE products ADD yml_cbid INT(4) DEFAULT '0' NOT NULL;

CREATE TABLE post_index (Id int(6) unsigned NOT NULL auto_increment,tax_zone_id int(1) NOT NULL default '0',low int(7) NOT NULL default '0',high int(7) NOT NULL default '0',mono int(7) NOT NULL default '0', PRIMARY KEY  (`Id`));


insert into post_index (tax_zone_id, low,high, mono) values ('1', '101000', '663981', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '667000', '668551', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '901951', '901989', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '0', '0', '901991');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '0', '0', '901034');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '0', '0', '901072');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '0', '0', '901073');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '0', '0', '901075');
insert into post_index (tax_zone_id, low,high, mono) values ('1', '0', '0', '901993');
insert into post_index (tax_zone_id, low,high, mono) values ('4', '664000', '666960', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('4', '669000', '678997', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('4', '687000', '687510', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('5', '679000', '686442', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('5', '688000', '694923', '0');
insert into post_index (tax_zone_id, low,high, mono) values ('5', '0', '0', '901050');
insert into post_index (tax_zone_id, low,high, mono) values ('5', '0', '0', '901071');
