SET SQL_MODE = "";

ALTER TABLE admin_access ADD 	article_reviews INT( 1 ) NOT NULL;
UPDATE admin_access SET article_reviews = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD author_reviews INT( 1 ) NOT NULL;
UPDATE admin_access SET author_reviews = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD company_reviews INT( 1 ) NOT NULL;
UPDATE admin_access SET company_reviews = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD reviews_add INT( 1 ) NOT NULL;
UPDATE admin_access SET reviews_add = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD company_reviews_add INT( 1 ) NOT NULL;
UPDATE admin_access SET company_reviews_add = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD article_reviews_add INT( 1 ) NOT NULL;
UPDATE admin_access SET article_reviews_add = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD author_reviews_add INT( 1 ) NOT NULL;
UPDATE admin_access SET author_reviews_add = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD site_reviews INT( 1 ) NOT NULL;
UPDATE admin_access SET site_reviews = 1 WHERE customers_id = 1 LIMIT 1;

ALTER TABLE admin_access ADD site_reviews_add INT( 1 ) NOT NULL;
UPDATE admin_access SET site_reviews_add = 1 WHERE customers_id = 1 LIMIT 1;


ALTER TABLE articles ADD articles_image VARCHAR(255);
ALTER TABLE articles ADD articles_keywords VARCHAR(255);

ALTER TABLE reviews ADD customers_avatar VARCHAR(255) after customers_id;

DROP TABLE IF EXISTS article_reviews;
CREATE TABLE `article_reviews` (
  `reviews_id` int(11) NOT NULL auto_increment,
  `articles_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_avatar` varchar(255) NOT NULL,
  `customers_name` varchar(255) NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` varchar(255) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL default '0',
  PRIMARY KEY (reviews_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS article_reviews_description;
CREATE TABLE `article_reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text,
  PRIMARY KEY (reviews_id, languages_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS author_reviews;
CREATE TABLE `author_reviews` (
  `reviews_id` int(11) NOT NULL auto_increment,
  `authors_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_avatar` varchar(255) NOT NULL,
  `customers_name` varchar(255) NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` varchar(255) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL default '0',
  PRIMARY KEY (reviews_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS author_reviews_description;
CREATE TABLE `author_reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text,
  PRIMARY KEY (reviews_id, languages_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS company_reviews;
CREATE TABLE `company_reviews` (
  `reviews_id` int(11) NOT NULL auto_increment,
  `manufacturers_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_avatar` varchar(255) NOT NULL,
  `customers_name` varchar(255) NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` varchar(255) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL default '0',
  PRIMARY KEY (reviews_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS company_reviews_description;
CREATE TABLE `company_reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text,
  PRIMARY KEY (reviews_id, languages_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS site_reviews;
CREATE TABLE `site_reviews` (
  `reviews_id` int(11) NOT NULL auto_increment,
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_avatar` varchar(255) NOT NULL,
  `customers_name` varchar(255) NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` varchar(255) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL default '0',
  PRIMARY KEY (reviews_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS site_reviews_description;
CREATE TABLE `site_reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text,
  PRIMARY KEY (reviews_id, languages_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;