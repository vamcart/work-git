INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('YML_SALES_NOTES', '', '23', '14', NULL , '0000-00-00 00:00:00', NULL , NULL);

ALTER TABLE `faq` ADD `faq_page_url` VARCHAR(256) NOT NULL;
