ALTER TABLE `orders_status` ADD `answer_templates_id` int(10) AFTER `orders_status_id`;
ALTER TABLE `orders_status` ADD `restock` int(10) default 0 AFTER `answer_templates_id`;
