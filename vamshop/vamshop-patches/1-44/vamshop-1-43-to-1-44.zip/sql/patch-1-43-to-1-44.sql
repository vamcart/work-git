  ALTER TABLE `categories` ADD `categories_url` VARCHAR(256) NOT NULL;
  ALTER TABLE `products` ADD `products_page_url` VARCHAR(256) NOT NULL;
  ALTER TABLE `content_manager` ADD `content_page_url` VARCHAR(256) NOT NULL ;

DROP TABLE IF EXISTS affiliate_affiliate;
CREATE TABLE affiliate_affiliate (
  affiliate_id int(11) NOT NULL auto_increment,
  affiliate_lft int(11) NOT NULL,
  affiliate_rgt int(11) NOT NULL,
  affiliate_root int(11) NOT NULL,
  affiliate_gender char(1) NOT NULL default '',
  affiliate_firstname varchar(32) NOT NULL default '',
  affiliate_lastname varchar(32) NOT NULL default '',
  affiliate_dob datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_email_address varchar(96) NOT NULL default '',
  affiliate_telephone varchar(32) NOT NULL default '',
  affiliate_fax varchar(32) NOT NULL default '',
  affiliate_password varchar(40) NOT NULL default '',
  affiliate_homepage varchar(96) NOT NULL default '',
  affiliate_street_address varchar(64) NOT NULL default '',
  affiliate_suburb varchar(64) NOT NULL default '',
  affiliate_city varchar(32) NOT NULL default '',
  affiliate_postcode varchar(10) NOT NULL default '',
  affiliate_state varchar(32) NOT NULL default '',
  affiliate_country_id int(11) NOT NULL default '0',
  affiliate_zone_id int(11) NOT NULL default '0',
  affiliate_agb tinyint(4) NOT NULL default '0',
  affiliate_company varchar(60) NOT NULL default '',
  affiliate_company_taxid varchar(64) NOT NULL default '',
  affiliate_commission_percent DECIMAL(4,2) NOT NULL default '0.00',
  affiliate_payment_check varchar(100) NOT NULL default '',
  affiliate_payment_paypal varchar(64) NOT NULL default '',
  affiliate_payment_bank_name varchar(64) NOT NULL default '',
  affiliate_payment_bank_branch_number varchar(64) NOT NULL default '',
  affiliate_payment_bank_swift_code varchar(64) NOT NULL default '',
  affiliate_payment_bank_account_name varchar(64) NOT NULL default '',
  affiliate_payment_bank_account_number varchar(64) NOT NULL default '',
  affiliate_date_of_last_logon datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_number_of_logons int(11) NOT NULL default '0',
  affiliate_date_account_created datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_date_account_last_modified datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY (affiliate_id),
  KEY `affiliate_root` (`affiliate_root`),
  KEY `affiliate_rgt` (`affiliate_rgt`),
  KEY `affiliate_lft` (`affiliate_lft`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_banners;
CREATE TABLE affiliate_banners (
  affiliate_banners_id int(11) NOT NULL auto_increment,
  affiliate_banners_title varchar(64) NOT NULL default '',
  affiliate_products_id int(11) NOT NULL default '0',
  affiliate_banners_image varchar(64) NOT NULL default '',
  affiliate_banners_group varchar(10) NOT NULL default '',
  affiliate_banners_html_text text,
  affiliate_expires_impressions int(7) default '0',
  affiliate_expires_date datetime default NULL,
  affiliate_date_scheduled datetime default NULL,
  affiliate_date_added datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_date_status_change datetime default NULL,
  affiliate_status int(1) NOT NULL default '1',
  PRIMARY KEY  (affiliate_banners_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_banners_history;
CREATE TABLE affiliate_banners_history (
  affiliate_banners_history_id int(11) NOT NULL auto_increment,
  affiliate_banners_products_id int(11) NOT NULL default '0',
  affiliate_banners_id int(11) NOT NULL default '0',
  affiliate_banners_affiliate_id int(11) NOT NULL default '0',
  affiliate_banners_shown int(11) NOT NULL default '0',
  affiliate_banners_clicks tinyint(4) NOT NULL default '0',
  affiliate_banners_history_date date NOT NULL default '0000-00-00',
  PRIMARY KEY  (affiliate_banners_history_id,affiliate_banners_products_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_clickthroughs;
CREATE TABLE affiliate_clickthroughs (
  affiliate_clickthrough_id int(11) NOT NULL auto_increment,
  affiliate_id int(11) NOT NULL default '0',
  affiliate_clientdate datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_clientbrowser varchar(200) default 'Нет данных',
  affiliate_clientip varchar(50) default 'Нет данных',
  affiliate_clientreferer varchar(200) default 'не определено (возможно прямая ссылка)',
  affiliate_products_id int(11) default '0',
  affiliate_banner_id int(11) NOT NULL default '0',
  PRIMARY KEY  (affiliate_clickthrough_id),
  KEY refid (affiliate_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_payment;
CREATE TABLE affiliate_payment (
  affiliate_payment_id int(11) NOT NULL auto_increment,
  affiliate_id int(11) NOT NULL default '0',
  affiliate_payment decimal(15,2) NOT NULL default '0.00',
  affiliate_payment_tax decimal(15,2) NOT NULL default '0.00',
  affiliate_payment_total decimal(15,2) NOT NULL default '0.00',
  affiliate_payment_date datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_payment_last_modified datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_payment_status int(5) NOT NULL default '0',
  affiliate_firstname varchar(32) NOT NULL default '',
  affiliate_lastname varchar(32) NOT NULL default '',
  affiliate_street_address varchar(64) NOT NULL default '',
  affiliate_suburb varchar(64) NOT NULL default '',
  affiliate_city varchar(32) NOT NULL default '',
  affiliate_postcode varchar(10) NOT NULL default '',
  affiliate_country varchar(32) NOT NULL default '0',
  affiliate_company varchar(60) NOT NULL default '',
  affiliate_state varchar(32) NOT NULL default '0',
  affiliate_address_format_id int(5) NOT NULL default '0',
  affiliate_last_modified datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (affiliate_payment_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_payment_status;
CREATE TABLE affiliate_payment_status (
  affiliate_payment_status_id int(11) NOT NULL default '0',
  affiliate_language_id int(11) NOT NULL default '1',
  affiliate_payment_status_name varchar(32) NOT NULL default '',
  PRIMARY KEY  (affiliate_payment_status_id,affiliate_language_id),
  KEY idx_affiliate_payment_status_name (affiliate_payment_status_name)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_payment_status_history;
CREATE TABLE affiliate_payment_status_history (
  affiliate_status_history_id int(11) NOT NULL auto_increment,
  affiliate_payment_id int(11) NOT NULL default '0',
  affiliate_new_value int(5) NOT NULL default '0',
  affiliate_old_value int(5) default NULL,
  affiliate_date_added datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_notified int(1) default '0',
  PRIMARY KEY  (affiliate_status_history_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS affiliate_sales;
CREATE TABLE affiliate_sales (
  affiliate_id int(11) NOT NULL default '0',
  affiliate_date datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_browser varchar(100) NOT NULL default '',
  affiliate_ipaddress varchar(20) NOT NULL default '',
  affiliate_orders_id int(11) NOT NULL default '0',
  affiliate_value decimal(15,2) NOT NULL default '0.00',
  affiliate_payment decimal(15,2) NOT NULL default '0.00',
  affiliate_clickthroughs_id int(11) NOT NULL default '0',
  affiliate_billing_status int(5) NOT NULL default '0',
  affiliate_payment_date datetime NOT NULL default '0000-00-00 00:00:00',
  affiliate_payment_id int(11) NOT NULL default '0',
  affiliate_percent  DECIMAL(4,2)  NOT NULL default '0.00',
  affiliate_salesman int(11) NOT NULL default '0',
  affiliate_level tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (affiliate_id,affiliate_orders_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

INSERT INTO affiliate_payment_status VALUES (0, 1, 'Ожидает оплаты');
INSERT INTO affiliate_payment_status VALUES (1, 1, 'Оплачен');

INSERT INTO configuration_group VALUES (28, 'CG_AFFILIATE_PROGRAM', 'Партнёрская программа', 'Настройки партнёрской программы', 50, 1);
INSERT INTO configuration VALUES ('', 'AFFILIATE_EMAIL_ADDRESS', 'affiliate@localhost.com', 28, 1, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_PERCENT', '15.0000', 28, 2, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_THRESHOLD', '30.00', 28, 3, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_COOKIE_LIFETIME', '7200', 28, 4, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_BILLING_TIME', '30', 28, 5, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_PAYMENT_ORDER_MIN_STATUS', '3', 28, 6, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_USE_CHECK', 'true', 28, 7, NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'AFFILIATE_USE_PAYPAL', 'false', 28, 8, NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'AFFILIATE_USE_BANK', 'false', 28, 9, NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'AFFILATE_INDIVIDUAL_PERCENTAGE', 'true', 28, 10, NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'AFFILATE_USE_TIER', 'false', 28, 11, NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'AFFILIATE_TIER_LEVELS', '0', 28, 12, NULL, now(), NULL, NULL);
INSERT INTO configuration VALUES ('', 'AFFILIATE_TIER_PERCENTAGE', '8.00;5.00;1.00', 28, 13, NULL, now(), NULL, NULL);

ALTER TABLE admin_access ADD affiliate_affiliates INT(1);
ALTER TABLE admin_access ADD affiliate_banners INT(1);
ALTER TABLE admin_access ADD affiliate_clicks INT(1);
ALTER TABLE admin_access ADD affiliate_contact INT(1);
ALTER TABLE admin_access ADD affiliate_invoice INT(1);
ALTER TABLE admin_access ADD affiliate_payment INT(1);
ALTER TABLE admin_access ADD affiliate_popup_image INT(1);
ALTER TABLE admin_access ADD affiliate_sales INT(1);
ALTER TABLE admin_access ADD affiliate_statistics INT(1);
ALTER TABLE admin_access ADD affiliate_summary INT(1);
UPDATE admin_access SET affiliate_affiliates=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_banners=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_clicks=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_contact=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_invoice=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_payment=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_popup_image=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_sales=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_statistics=1 WHERE customers_id=1;
UPDATE admin_access SET affiliate_summary=1 WHERE customers_id=1;

INSERT INTO cm_file_flags VALUES (2, 'affiliate');

INSERT INTO content_manager VALUES (9, 0, 0, '', 1, 'Правила партнёрской программы', 'Правила и условия партнёрской программы', '<b>1. Участники партнёрской программы.</b>
<br />
Участниками партнёрской программы могут быть физические лица. Под физическими лицами понимаются граждане РФ, иностранные граждане, лица без гражданства, а так же предприниматели без образования юридического лица.
<br />
<br />
<b>2. Оплата услуг партнёра.</b>
<br />
Мы будем выплачивать Вам комиссию, установленную в размере <b>15%</b> от стоимости <b>оплаченного</b> заказа.
<br />
<br />
<b>3. Способы оплаты.</b>
<br />
Все партнёрские выплаты производятся в доларах США через электронную платёжную систему <b>WebMoney</b>, Вы можете ознакомиться с данной системой по адресу <b><a href="http://www.webmoney.ru" target="_blank">http://www.webmoney.ru</a></b>
<br />
<br />
<b>4. Минимальная сумма к оплате.</b>
<br />
Минимальная сумма к оплате установлена в размере <b>30$</b>. В случае, если заработанная Вами партнёрская комиссия не превышает <b>30$</b>, деньги остаются на Вашем аккаунте до тех пор, пока сумма комиссии не достигнет по крайней мере <b>30$</b>. Оплата партнёрских комиссий производится каждые <b>2 недели</b>.
<br />
<br />
<b>5. Партнёрская комиссия.</b>
<br />
Партнёрская комиссия будет выплачена только если заказ оформлен и оплачен покупателем, которого привели Вы.
<br /><br />
Партнёрская комиссия начисляется только за <b>оплаченные заказы.</b>
<br /><br />
Партнёрская комиссия не будет выплачена, если:
<br />
&nbsp;<b>а)</b> Посетитель, пришедший с Вашего сайта не будет учтён нашей системой по техническим причинам (отключены "Cookies" и т.д.).
<br />
&nbsp;<b>б)</b> Посетитель перешёл в магазин по партнёрской ссылке другого партнёра.
<br />
&nbsp;<b>в)</b> Посетиитель, оформивший заказ через Вашу партнёрскую ссылку не оплатил его.
<br />
<br />
<b>6. Условия.</b>
<br />
Покупатели, совершающие заказы через партнёров считаются нашими покупателями и подчиняются правилам нашего магазина. Правила работы магазина могут быть изменены нами без предварительного уведомления.
<br />
<br />
<b>7. Разногласия</b>
<br />
В случае возникновения разногласий, стороны будут стремиться урегулировать возникшие разногласия путем переговоров. В случае, если стороны не придут к соглашению, то спор подлежит рассмотрению в суде РФ.
<br />
<br />', '', 0, 2, '', 1, 9, 0,'','','','');
INSERT INTO content_manager VALUES (10, 0, 0, '', 1, 'Информация', 'Информация о партнёрской программе', '<b>1. Участники партнёрской программы.</b>
<br />
Участниками партнёрской программы могут быть физические лица. Под физическими лицами понимаются граждане РФ, иностранные граждане, лица без гражданства, а так же предприниматели без образования юридического лица.
<br />
<br />
<b>2. Оплата услуг партнёра.</b>
<br />
Мы будем выплачивать Вам комиссию, установленную в размере <b>15%</b> от стоимости <b>оплаченного</b> заказа.
<br />
<br />
<b>3. Способы оплаты.</b>
<br />
Все партнёрские выплаты производятся в доларах США через электронную платёжную систему <b>WebMoney</b>, Вы можете ознакомиться с данной системой по адресу <b><a href="http://www.webmoney.ru" target="_blank">http://www.webmoney.ru</a></b>
<br />
<br />
<b>4. Минимальная сумма к оплате.</b>
<br />
Минимальная сумма к оплате установлена в размере <b>30$</b>. В случае, если заработанная Вами партнёрская комиссия не превышает <b>30$</b>, деньги остаются на Вашем аккаунте до тех пор, пока сумма комиссии не достигнет по крайней мере <b>30$</b>. Оплата партнёрских комиссий производится каждые <b>2 недели</b>.
<br />
<br />
<b>5. Партнёрская комиссия.</b>
<br />
Партнёрская комиссия будет выплачена только если заказ оформлен и оплачен покупателем, которого привели Вы.
<br /><br />
Партнёрская комиссия начисляется только за <b>оплаченные заказы.</b>
<br /><br />
Партнёрская комиссия не будет выплачена, если:
<br />
&nbsp;<b>а)</b> Посетитель, пришедший с Вашего сайта не будет учтён нашей системой по техническим причинам (отключены "Cookies" и т.д.).
<br />
&nbsp;<b>б)</b> Посетитель перешёл в магазин по партнёрской ссылке другого партнёра.
<br />
&nbsp;<b>в)</b> Посетиитель, оформивший заказ через Вашу партнёрскую ссылку не оплатил его.
<br />
<br />
<b>6. Условия.</b>
<br />
Покупатели, совершающие заказы через партнёров считаются нашими покупателями и подчиняются правилам нашего магазина. Правила работы магазина могут быть изменены нами без предварительного уведомления.
<br />
<br />
<b>7. Разногласия</b>
<br />
В случае возникновения разногласий, стороны будут стремиться урегулировать возникшие разногласия путем переговоров. В случае, если стороны не придут к соглашению, то спор подлежит рассмотрению в суде РФ.
<br />
<br />', '', 0, 2, '', 1, 10, 0,'','','','');
INSERT INTO content_manager VALUES (11, 0, 0, '', 1, 'Вопросы и ответы', 'Вопросы и ответы', 'Список частозадаваемых вопросов по партнёрской программе.<br>
<br>
<ul>
<li>Как мне получить заработанные у вас деньги?</a>
<li>Как и в каком месте лучше всего рамещать партнёрские ссылки?</a>
<li>Могу ли я изменять HTML-код, который мне нужно ставить на сайт?</a>
<li>Что будет если покупатель, который пришёл с моего сайте не оплатит заказ?</a>
</ul>
<hr width="90%">
<BR>
<FONT COLOR="#000000" size="4"><B><U>FAQ</U></B></FONT>
<p style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"><font color="maroon">Как мне получить заработанные у вас деньги?</font><br>
Чтобы получить выплату партнёрской комиссии, на Вашем аккаунте должно быть как минимум <b>30$</b>. В случае, если заработанная Вами партнёрская комиссия не превышает <b>30$</b>, деньги остаются на Вашем аккаунте до тех пор, пока сумма комиссии не достигнет по крайней мере <b>30$</b>. Оплата партнёрских комиссий производится каждые <b>2 недели</b>. Выплаты производятся на Ваш кошелёк в системе WebMoney.</p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"></p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0">&nbsp;</p>
<p style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"><font color="maroon">Как и в каком месте лучше всего рамещать партнёрские ссылки?</font><a name="2"></a><br>
Лучше всего размещать партнёрские ссылки сразу на всех страницах Вашего сайта, в ниболее заметных местах, используйте различные партнёрские ссылки: баннеры, ссылки на конкретные товары и т.д. Размещать рекламу в верхней части страниц всегда эффективнее, чем в нижней. Вы можете размещать партнёрские ссылки не только у себя на сайте, а так же в баннеробменных сетях, почтовых рассылках и т.д.</p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"></p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0">&nbsp;</p>
<p style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"><font color="maroon">Могу ли я изменять HTML-код, который мне нужно ставить на сайт?</font><a name="3"></a><br>
Да, Вы можете изменять HTML-код по своему усмотрению, можете создавать свои ссылки самостоятельно на разные страницы нашего магазина, главное чтобы в адресе ссылки был указан ваш Партнёрский ID. Например: <b>http://адресмагазина/?ref=yourid</b>, где <b>yourid</b> это Ваш партнёрский номер.</p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"></p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0">&nbsp;</p>
<p style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"><font color="maroon">Что будет если покупатель, который пришёл с моего сайта не оплатит заказ?</font><a name="4"></a><br>
Вы не получите свою комиссию, т.к. комиссия начисляется только за <b>оплаченные</b> заказы.</p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0"></p>
<p align="right" style="line-height: 100%; word-spacing: 0; text-indent: 0; margin: 0">&nbsp;</p>', '', 0, 2, '', 1, 11, 0,'','','','');
