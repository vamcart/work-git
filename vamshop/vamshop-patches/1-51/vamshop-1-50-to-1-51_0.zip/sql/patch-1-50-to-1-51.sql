INSERT INTO configuration_group VALUES ('29', 'CG_BOXES', 'Боксы', 'Боксы', '29', '1');

#configuration_group_id 29

INSERT INTO configuration VALUES ('', 'SET_BOX_CATEGORIES', 'true', '29', '1', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_FILTERS', 'true', '29', '2', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_CONTENT', 'true', '29', '3', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_INFORMATION', 'true', '29', '4', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_ADD_QUICKIE', 'true', '29', '5', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_LAST_VIEWED', 'true', '29', '6', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_REVIEWS', 'true', '29', '7', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_SEARCH', 'true', '29', '8', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_SPECIALS', 'true', '29', '9', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_FEATURED', 'true', '29', '10', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_LATESTNEWS', 'true', '29', '11', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_ARTICLES', 'true', '29', '12', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_ARTICLESNEW', 'true', '29', '13', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_AUTHORS', 'true', '29', '14', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_CART', 'true', '29', '15', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_LOGIN', 'true', '29', '16', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_ADMIN', 'true', '29', '17', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_DOWNLOADS', 'true', '29', '18', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_AFFILIATE', 'true', '29', '19', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_WHATSNEW', 'true', '29', '20', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_NEWSLETTER', 'true', '29', '21', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_BESTSELLERS', 'true', '29', '22', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_INFOBOX', 'true', '29', '23', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_CURRENCIES', 'true', '29', '24', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_LANGUAGES', 'true', '29', '25', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_MANUFACTURERS', 'true', '29', '26', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_MANUFACTURERS_INFO', 'true', '29', '27', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO configuration VALUES ('', 'SET_BOX_FAQ', 'true', '29', '28', NULL, now(), NULL,'vam_cfg_select_option(array(\'true\', \'false\'), ');

ALTER TABLE admin_access ADD parameters INT( 1 ) NOT NULL;
UPDATE admin_access SET parameters = 1 WHERE customers_id = 1 LIMIT 1;
ALTER TABLE admin_access ADD parameters_export INT( 1 ) NOT NULL;
UPDATE admin_access SET parameters_export = 1 WHERE customers_id = 1 LIMIT 1;

DROP TABLE IF EXISTS products_parameters;
create table `products_parameters` (
  `products_parameters_id` int(10) unsigned NOT NULL auto_increment,
  `products_parameters_name` varchar(255) NOT NULL default '',
  `products_parameters_title` varchar(255) NOT NULL default '',
  `products_parameters_order` int(11) NOT NULL default '0',
  `categories_id` int(11) NOT NULL default '0',
  `products_parameters_type` enum('p','g') NOT NULL default 'p',
  `products_parameters_group` int(11) NOT NULL default '0',
  `products_parameters_useinsearch` tinyint(1) NOT NULL default '0',
  `products_parameters_intervals` text NOT NULL,
  `products_parameters_titlename` varchar(255) NOT NULL default '',
  `products_parameters_titlesuff` varchar(10) NOT NULL default '',
  `products_parameters_useinsdesc` tinyint(1) NOT NULL default '0',
  `products_parameters_maxopened` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`products_parameters_id`),
  KEY `category_id` (`categories_id`),
  KEY `products_parameters_group` (`products_parameters_group`),
  KEY `products_parameters_useinsearch` (`products_parameters_useinsearch`),
  KEY `products_parameters_useinsdesc` (`products_parameters_useinsdesc`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS products_parameters2products;
create table `products_parameters2products` (
  `products_parameters_id` int(10) unsigned NOT NULL default '0',
  `products_id` int(10) unsigned NOT NULL default '0',
  `products_parameters_values_id` int(8) NOT NULL,
  `products_parameters2products_value` varchar(255) NOT NULL default '',
  `products_parameters2products_md5` varchar(32) NOT NULL default '',
  `products_parameters2products_order` int(11) NOT NULL default '0',
  PRIMARY KEY  (`products_parameters_id`,`products_id`),
  KEY `products_id` (`products_id`),
  KEY `products_parameters2products_md5` (`products_parameters2products_md5`),
  KEY `products_parameters_values_id` (`products_parameters_values_id`),
  KEY `products_parameters_id` (`products_parameters_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS products_parameters_values;
create table `products_parameters_values` (
  `products_parameters_values_id` int(8) NOT NULL auto_increment,
  `products_parameters_id` int(8) NOT NULL,
  `parameters_value` varchar(255) NOT NULL,
  PRIMARY KEY  (`products_parameters_values_id`),
  KEY `products_parameters_values_id` (`products_parameters_values_id`),
  KEY `products_parameters_id` (`products_parameters_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;
