SET SQL_MODE = "";

DROP TABLE IF EXISTS latest_news_to_brands;
CREATE TABLE latest_news_to_brands (
  news_id int NOT NULL,
  manufacturers_id int NOT NULL,
  PRIMARY KEY (news_id,manufacturers_id),
  KEY idx_products_id (manufacturers_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;
