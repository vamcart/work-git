<?php
	function vam_get_manufacturer_rating_count($products_id = 0) {
	  
		$reviews_query = vam_db_query("select count(*) as total from ".TABLE_COMPANY_REVIEWS." r, ".TABLE_COMPANY_REVIEWS_DESCRIPTION." rd where r.manufacturers_id = '".(int)$products_id."' and r.reviews_id = rd.reviews_id and rd.languages_id = '".$_SESSION['languages_id']."'");
		$reviews = vam_db_fetch_array($reviews_query);
		return $reviews['total'];
	}	