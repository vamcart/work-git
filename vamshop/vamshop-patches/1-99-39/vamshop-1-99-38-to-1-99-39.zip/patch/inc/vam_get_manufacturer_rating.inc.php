<?php
	function vam_get_manufacturer_rating($products_id = 0) {

		$reviews_query = vam_db_query("select count(*) as total, TRUNCATE(SUM(reviews_rating),2) as rating from ".TABLE_COMPANY_REVIEWS." r, ".TABLE_COMPANY_REVIEWS_DESCRIPTION." rd where r.manufacturers_id = '".(int)$products_id."' and r.reviews_id = rd.reviews_id and rd.languages_id = '".$_SESSION['languages_id']."'");
		$reviews = vam_db_fetch_array($reviews_query);
		if ($reviews['total'] > 0 && $reviews['rating'] > 0) {
		return $reviews['rating']/$reviews['total'];
		}
	}