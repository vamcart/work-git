<?php

include ('includes/application_top.php');



	
require_once (DIR_FS_INC.'vam_get_cookie_info.inc.php');


$cookie_info = vam_get_cookie_info();

if (isset ($_POST['productID'])) {
	$pID = $_POST['productID'];
	$action = $_POST['action'];
	

	if (isset ($_COOKIE['compare_cookie'])) {
		$compare = $_COOKIE['compare_cookie'];
			
	}
		
	if($action=='true') {
	


		if (strpos($compare, $pID)===false)
		$compare.=",".$pID;


		if (substr($compare, 0, 1)==',')
		$compare=	substr($compare, 1);

		echo "Товар добавлен в сравнение."; 
		
		//Запись в таблицу favorites
          $sql_data_array = array('products_id'   => vam_db_prepare_input($pID),
                                  'customer_id'    => vam_db_prepare_input(($_SESSION['customer_id'] > 0) ? $_SESSION['customer_id'] : 0),
                                  'status' => '1',
                                  'date_added' => 'now()');
          vam_db_perform(TABLE_COMPARE, $sql_data_array);		
		
	} else {
			
			$compareArr = explode(",", $compare);
			if(strpos($compare,",")==false)
			$compareArr[]=	$compare;
			$compareArr = array_unique($compareArr);
			//echo strpos($compare,",");
		
			$pIDFound = array_search($pID, $compareArr); 
			
			//if($pIDFound!=false)
			{
				//echo $pIDFound;
				//echo var_dump($compareArr);
				unset($compareArr[$pIDFound]);

				$compare = implode(",", $compareArr);
				
				//if ($pIDFound==0)
				//$compare="";
				//echo $compare;
			}
			
			//vam_db_query("DELETE FROM ".TABLE_FAVORITES." WHERE products_id = '".vam_db_input($pID)."' " . (($_SESSION['customer_id'] > 0) ? " AND customer_id =  " . $_SESSION['customer_id'] : " AND customer_id = 0") . " order by id desc limit 1");
			
			vam_db_query("UPDATE ".TABLE_COMPARE." SET status = 0, date_deleted = now() WHERE products_id = '".vam_db_input($pID)."' " . (($_SESSION['customer_id'] > 0) ? " AND customer_id =  " . $_SESSION['customer_id'] : " AND customer_id = 0") . " order by id desc limit 1");

         //$sql_data_array = array('status' => '0',
         //                         'date_deleted' => 'now()');
			//vam_db_perform(TABLE_FAVORITES, $sql_data_array, 'update', 'products_id = \''.vam_db_input($pID).'\' order by id limit 1');
		
	}
	vam_setcookie('compare_cookie', $compare, time() + 60 * 60*24*30, $cookie_info['cookie_path'], $cookie_info['cookie_domain']);
}


?>