<?php
/* --------------------------------------------------------------
   $Id: notifications.php 1180 2007-04-02 11:13:01Z VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   --------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(latest_news.php,v 1.33 2003/05/07); www.oscommerce.com 

   Released under the GNU General Public License 
   --------------------------------------------------------------*/

  require('includes/application_top.php');
  require_once(DIR_FS_INC . 'vam_wysiwyg_tiny.inc.php');
  require_once (DIR_FS_INC.'vam_image_submit.inc.php');
  require_once (DIR_WS_FUNCTIONS . 'products_specifications.php');

// initiate template engine for mail
$vamTemplate = new vamTemplate;

  require_once (DIR_FS_INC.'vam_php_mail.inc.php');
  require_once(DIR_FS_INC . 'vam_wysiwyg_tiny.inc.php');

  
  if ($_GET['action']) {
    switch ($_GET['action']) {

      case 'delete_notifications_confirm': //user has confirmed deletion of notifications.
        if ($_POST['id']) {
          $id = vam_db_prepare_input($_POST['id']);
          vam_db_query("delete from " . TABLE_NOTIFICATIONS . " where id = '" . vam_db_input($id) . "'");
        }

   //     vam_redirect(vam_href_link(FILENAME_NOTIFICATIONS));
        break;

    }
  }
  
// Start Batch Delete
if (isset($_POST['submit']) && isset($_POST['groups'])){
	
// delete customers
 
 if (($_POST['submit'] == BUTTON_SUBMIT)){

  foreach ($_POST['groups'] as $notification_id){

    $customers_deleted = false;
			if ($this_customerID != 1) {
			vam_db_query("delete from ".TABLE_NOTIFICATIONS." where id = '".vam_db_input($notification_id)."'");

          $customers_deleted = true;
         }

  } // End foreach ID loop
  
        if ($customers_deleted == true) {
         $messageStack->add_session(BUS_CUSTOMER . $this_customerID . ' ' . BUS_DELETE_SUCCESS, 'success');
        } else {
          $messageStack->add_session(BUS_CUSTOMER . $this_customerID . ' ' . BUS_DELETE_WARNING, 'warning');
        }
          
 }

// /delete customers

   vam_redirect(vam_href_link(FILENAME_NOTIFICATIONS),vam_get_all_get_params());
}
// End Batch Delete  
?>
<!DOCTYPE html>
<html <?php echo HTML_PARAMS; ?>>
<head>
<!--<meta name="viewport" content="initial-scale=1.0, width=device-width" />-->
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $_SESSION['language_charset']; ?>"> 
<title><?php echo TITLE; ?></title>
<!-- Header JS, CSS -->
<?php require(DIR_FS_ADMIN.DIR_WS_INCLUDES . 'header_include.php'); ?>
		        <script type="text/javascript">
        var lastChecked = null;
 
        $(document).ready(function() {
                $('input:checkbox').click(function(event) {
                        if(!lastChecked) {
                                lastChecked = this;
                                return;
                        }
 
                        if(event.shiftKey) {
                                var start = $('input:checkbox').index(this);
                                var end = $('input:checkbox').index(lastChecked);
 
                                for(i=Math.min(start,end);i<=Math.max(start,end);i++) {
                                        $('input:checkbox')[i].checked = lastChecked.checked;
                                }
                        }
 
                        lastChecked = this;
                });
        });
        </script>
</head>
<body>
<!-- header //-->
<?php require(DIR_WS_INCLUDES . 'header.php'); ?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
<?php if (ADMIN_DROP_DOWN_NAVIGATION == 'false') { ?>
    <td width="<?php echo BOX_WIDTH; ?>" align="left" valign="top">
<!-- left_navigation //-->
<?php require(DIR_WS_INCLUDES . 'column_left.php'); ?>
<!-- left_navigation_eof //-->
    </td>
<?php } ?>
<!-- body_text //-->
    <td class="boxCenter" valign="top">
    
<?php 
$manual_link = 'add-notifications';
if ($_GET['action'] == 'new_notifications' and isset($_GET['id'])) {
$manual_link = 'edit-notifications';
}  
if ($_GET['action'] == 'delete_notifications') {
$manual_link = 'delete-notifications';
}  
?>
        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td class="pageHeading" colspan="2"><?php echo HEADING_TITLE; ?></td>
          </tr>
        </table>
  
  </td>
  </tr>
  <tr>
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?php
  if ($_GET['action'] == 'new_notifications') { //insert or edit a notifications
    if ( isset($_GET['id']) ) { //editing exsiting notifications
      $notifications_query = vam_db_query("select * from " . TABLE_NOTIFICATIONS . " where id = '" . $_GET['id'] . "'");
      $notifications = vam_db_fetch_array($notifications_query);
    } else { //adding new notifications
      $notifications = array();
    }
    
if ($notifications['show_popular_products'] == '1'){ $show_popular_products_checked = true; } else { $show_popular_products_checked = false; }    
if ($notifications['show_discount_products'] == '1'){ $show_discount_products_checked = true; } else { $show_discount_products_checked = false; }    
?>
      <tr><?php echo vam_draw_form('new_notifications', FILENAME_NOTIFICATIONS, isset($_GET['id']) ? vam_get_all_get_params(array('action')) . 'action=update_notifications' : vam_get_all_get_params(array('action')) . 'action=insert_notifications', 'post', 'enctype="multipart/form-data"'); ?>
        <td><table border="0" cellspacing="0" cellpadding="2" width="100%">
          <tr>
            <td class="main"><?php echo TEXT_NOTIFICATIONS_NAME; ?>:</td>
            <td class="main"><?php echo vam_draw_separator('pixel_trans.gif', '24', '15') . '&nbsp;' . $notifications['name']; ?></td>
          </tr>
          <tr>
            <td class="main"><?php echo TEXT_NOTIFICATIONS_EMAIL_ADDRESS; ?>:</td>
            <td class="main"><?php echo vam_draw_separator('pixel_trans.gif', '24', '15') . '&nbsp;' . $notifications['email_address']; ?></td>
          </tr>
          <tr>
            <td class="main"><?php echo TEXT_NOTIFICATIONS_SUBJECT; ?>:</td>
            <td class="main"><?php echo vam_draw_separator('pixel_trans.gif', '24', '15') . '&nbsp;' . $notifications['subject']; ?></td>
          </tr>
          <tr>
            <td class="main" colspan="2"><?php echo TEXT_NOTIFICATIONS_BODY; ?>:</td>
          </tr>
          <tr>
            <td class="main" colspan="2"><?php echo $notifications['body']; ?></td>
          </tr>

          <tr>
            <td colspan="2"><?php echo vam_draw_separator('pixel_trans.gif', '1', '10'); ?></td>
          </tr>
          

<?php
if ( isset($_GET['id']) ) {
?>
          <tr>
            <td class="main"><?php echo TEXT_NOTIFICATIONS_DATE; ?>:</td>
            <td class="main"><?php echo vam_draw_separator('pixel_trans.gif', '24', '15') . '&nbsp;' .  $notifications['created']; ?></td>
          </tr>

          <tr>
            <td colspan="2"><?php echo vam_draw_separator('pixel_trans.gif', '1', '10'); ?></td>
          </tr>

<?php
}
?>

        </table></td>
      </tr>
      <tr>
        <td><?php echo vam_draw_separator('pixel_trans.gif', '1', '10'); ?></td>
      </tr>
      <tr>
        <td class="main" align="right">
          <?php
            isset($_GET['id']) ? $cancel_button = '&nbsp;&nbsp;<a class="button" href="' . vam_href_link(FILENAME_NOTIFICATIONS, 'id=' . $_GET['id']) . '"><span>' . vam_image(DIR_WS_IMAGES . 'icons/buttons/cancel.png', '', '12', '12') . '&nbsp;' . BUTTON_BACK . '</span></a>' : $cancel_button = '';
            echo $cancel_button;
          ?>
        </td>
      </tr>
      </form>
<?php

  } else {
?>
      </tr>
      
<?php
echo vam_draw_form('multi_action_form', FILENAME_NOTIFICATIONS,vam_get_all_get_params());
?>      
      
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="top"><table border="0" width="100%" cellspacing="2" cellpadding="0" class="contentListingTable">
              <tr class="dataTableHeadingRow">
                <td class="dataTableHeadingContent"><input type="checkbox" onClick="javascript:CheckAll(this.checked);"></td>
                <td class="dataTableHeadingContent"><?php echo TABLE_HEADING_NOTIFICATIONS_ID; ?></td>
                <td class="dataTableHeadingContent"><?php echo TABLE_HEADING_NOTIFICATIONS_NAME; ?></td>
                <td class="dataTableHeadingContent" align="center"><?php echo TABLE_HEADING_NOTIFICATIONS_EMAIL; ?></td>
                <td class="dataTableHeadingContent" align="center"><?php echo TABLE_HEADING_NOTIFICATIONS_SUBJECT; ?></td>
                <td class="dataTableHeadingContent" align="center"><?php echo TABLE_HEADING_NOTIFICATIONS_STATUS; ?></td>
                <td class="dataTableHeadingContent" align="right"><?php echo TABLE_HEADING_NOTIFICATIONS_ACTION; ?>&nbsp;</td>
              </tr>
<?php
    $rows = 0;

    $notifications_count = 0;
    $notifications_query_raw = 'select * from ' . TABLE_NOTIFICATIONS . ' order by id desc';

	$notifications_split = new splitPageResults($_GET['page'], MAX_DISPLAY_ADMIN_PAGE, $notifications_query_raw, $notifications_query_numrows);

    $notifications_query = vam_db_query($notifications_query_raw);
	    
    while ($notifications = vam_db_fetch_array($notifications_query)) {
      $notifications_count++;
      $rows++;
      
		if (((!$_GET['id']) || (@ $_GET['id'] == $notifications['id'])) && (!$fInfo)) {
			$fInfo = new objectInfo($notifications);
		}

		if ((is_object($fInfo)) && ($notifications['id'] == $fInfo->id)) {
            echo '<tr class="dataTableRowSelected" onmouseover="this.style.cursor=\'hand\'">' . "\n";
        } else {
            echo '<tr class="dataTableRow" onmouseover="this.className=\'dataTableRowOver\';this.style.cursor=\'hand\'" onmouseout="this.className=\'dataTableRow\'">' . "\n";
        }		
?>
                <td class="dataTableContent" align="center"><input type="checkbox" name="groups[]" value="<?php echo $notifications['id'];?>"></td>
                <td class="dataTableContent" align="center"><?php echo $notifications['id']; ?></td>
                <td class="dataTableContent"><?php echo $notifications['name']; ?></td>
                <td class="dataTableContent"><?php echo $notifications['email_address']; ?></td>
                <td class="dataTableContent"><?php echo $notifications['subject']; ?></td>
                <td class="dataTableContent" align="center">
<?php
      if ($notifications['viewed'] >= '1') {
        echo vam_image(DIR_WS_IMAGES . 'icon_status_green.gif', YES, 10, 10);
      } else {
        echo vam_image(DIR_WS_IMAGES . 'icon_status_red.gif', NO, 10, 10);
      }
?></td>                
                <td class="dataTableContent" align="right"><?php if ($notifications['id'] == $_GET['id']) { echo vam_image(DIR_WS_IMAGES . 'icon_arrow_right.gif', ''); } else { echo '<a href="' . vam_href_link(FILENAME_NOTIFICATIONS, vam_get_all_get_params(array('id','action', 'flag')) . 'id=' . $notifications['id']) . '">' . vam_image(DIR_WS_IMAGES . 'icon_info.gif', IMAGE_ICON_INFO) . '</a>'; } ?>&nbsp;</td>
              </tr>
<?php
    }

?>

<?php
echo '<tr class="dataTableContent" align="center"><td colspan="8" nobr="nobr" align="left">' .
     '<a class="button" href="javascript:SwitchCheck()"><span>' . vam_image(DIR_WS_IMAGES . 'icons/buttons/reverse.png', '', '12', '12') . '&nbsp;' . BUTTON_REVERSE_SELECTION . '</span></a>&nbsp;<span class="button"><button name="submit" type="submit" value="' . BUTTON_SUBMIT . '">' . vam_image(DIR_WS_IMAGES . 'icons/buttons/submit.png', '', '12', '12') . '&nbsp;' . BUS_DELETE . '</button></span></td></tr>';
?>
</form>

              <tr>
                <td colspan="8"><table border="0" width="100%" cellspacing="0" cellpadding="2">
                  <tr>
                    <td class="smallText" colspan="2"><?php echo '<br>' . TEXT_NOTIFICATIONS_ITEMS . '&nbsp;' . $notifications_count; ?></td>
                  </tr>																																		  
                </table></td>
              </tr>
              <tr>
                <td colspan="8"><table border="0" width="100%" cellspacing="0" cellpadding="2">
                  <tr>
                    <td class="smallText" valign="top"><?php echo $notifications_split->display_count($notifications_query_numrows, MAX_DISPLAY_ADMIN_PAGE, $_GET['page'], TEXT_DISPLAY_NUMBER_OF_NOTIFICATIONS); ?></td>
                    <td class="smallText" align="right"><?php echo $notifications_split->display_links($notifications_query_numrows, MAX_DISPLAY_ADMIN_PAGE, MAX_DISPLAY_PAGE_LINKS, $_GET['page'], vam_get_all_get_params(array('page', 'action', 'x', 'y', 'id'))); ?></td>
                  </tr>              
                </table></td>
              </tr>
            </table></td>
<?php
    $heading = array();
    $contents = array();
    switch ($_GET['action']) {
      case 'delete_notifications': //generate box for confirming a notificationsdeletion
        $heading[] = array('text'   => '<b>' . TEXT_INFO_HEADING_DELETE_ITEM . '</b>');
        
        $contents = array('form'    => vam_draw_form('notifications', FILENAME_NOTIFICATIONS, vam_get_all_get_params(array('action')) . 'action=delete_notifications_confirm') . vam_draw_hidden_field('id', $_GET['id']));
        $contents[] = array('text'  => TEXT_DELETE_ITEM_INTRO);
        $contents[] = array('text'  => '<br><b>' . $selected_item['question'] . '</b>');
        
        $contents[] = array('align' => 'center',
                            'text'  => '<br><span class="button"><button type="submit" value="' . BUTTON_DELETE .'">' . vam_image(DIR_WS_IMAGES . 'icons/buttons/delete.png', '', '12', '12') . '&nbsp;' . BUTTON_DELETE . '</button></span><a class="button" href="' . vam_href_link(FILENAME_NOTIFICATIONS,  vam_get_all_get_params(array ('id', 'action')).'id=' . $selected_item['id']) . '"><span>' . vam_image(DIR_WS_IMAGES . 'icons/buttons/cancel.png', '', '12', '12') . '&nbsp;' . BUTTON_CANCEL . '</span></a>');
        break;

      default:
        if ($rows > 0) {
          if (is_object($fInfo)) { //an item is selected, so make the side box
            $heading[] = array('text' => '<b>' . $fInfo->name . '</b>');

            $contents[] = array('align' => 'center', 
                                'text' => '<a class="button" href="' . vam_href_link(FILENAME_NOTIFICATIONS, vam_get_all_get_params(array ('id', 'action')).'id=' . $fInfo->id . '&action=new_notifications') . '"><span>' . vam_image(DIR_WS_IMAGES . 'icons/buttons/edit.png', '', '12', '12') . '&nbsp;' . BUTTON_VIEW . '</span></a> <a class="button" href="' . vam_href_link(FILENAME_NOTIFICATIONS,  vam_get_all_get_params(array ('id', 'action')).'id=' . $fInfo->id . '&action=delete_notifications') . '"><span>' . vam_image(DIR_WS_IMAGES . 'icons/buttons/delete.png', '', '12', '12') . '&nbsp;' . BUTTON_DELETE . '</span></a>');

            $contents[] = array('text' => '<strong>'.TEXT_NOTIFICATIONS_SUBJECT.':</strong><br>' . $fInfo->subject);
            //$contents[] = array('text' => '<strong>'.TEXT_NOTIFICATIONS_BODY.':</strong><br>' . vam_break_string(strip_tags($fInfo->body), 128, '...'));
            $contents[] = array('text' => '<strong>'.TABLE_HEADING_DATE.':</strong> ' . vam_break_string(strip_tags($fInfo->created), 128, '...'));
          }
        } else { // create category/product info
          $heading[] = array('text' => '<b>' . EMPTY_CATEGORY . '</b>');

          $contents[] = array('text' => sprintf(TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS, $parent_categories_name));
        }
        break;
    }

    if ( (vam_not_null($heading)) && (vam_not_null($contents)) ) {
      echo '            <td width="25%" valign="top">' . "\n";

      $box = new box;
      echo $box->infoBox($heading, $contents);

      echo '            </td>' . "\n";
    }
?>
          </tr>
        </table></td>
      </tr>
<?php
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?><!-- footer_eof //-->
<br>
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>
