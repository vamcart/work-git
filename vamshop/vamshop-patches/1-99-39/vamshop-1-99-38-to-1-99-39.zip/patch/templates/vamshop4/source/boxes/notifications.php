<?php
/* -----------------------------------------------------------------------------------------
   $Id: wishlist.php 1281 2007-02-07 12:30:44 VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   -----------------------------------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(wishlist.php,v 1.18 2003/02/10); www.oscommerce.com
   (c) 2003	 nextcommerce (wishlist.php,v 1.15 2003/08/17); www.nextcommerce.org 
   (c) 2004	 xt:Commerce (wishlist.php,v 1.15 2003/08/13); xt-commerce.com 

   Released under the GNU General Public License 
   ---------------------------------------------------------------------------------------*/
$box = new vamTemplate;
$box->assign('tpl_path', 'templates/'.CURRENT_TEMPLATE.'/');

$all_sql = "
      SELECT * 
      FROM " . TABLE_NOTIFICATIONS . "
      WHERE
          customer_id = '".$_SESSION['customer_id']."' and viewed = 0 
      ORDER BY id DESC
      ";
      
$all_sql = vam_db_query($all_sql);      
if ($_SESSION['customer_id'] > 0) {      
$notifications_count = vam_db_num_rows($all_sql);
} else {
$notifications_count = 0;
}

$box->assign('TOTAL_QUANTITY', $notifications_count);

$box->caching = 0;
$box->assign('language', $_SESSION['language']);
$box_notifications = $box->fetch(CURRENT_TEMPLATE.'/boxes/box_notifications.html');
$vamTemplate->assign('box_NOTIFICATIONS', $box_notifications);
?>