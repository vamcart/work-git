<?php
/* -----------------------------------------------------------------------------------------
   $Id: categories.php 1302 2007-02-07 12:30:44 VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   -----------------------------------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(categories.php,v 1.23 2002/11/12); www.oscommerce.com 
   (c) 2003	 nextcommerce (categories.php,v 1.10 2003/08/17); www.nextcommerce.org
   (c) 2004	 xt:Commerce (categories.php,v 1.10 2003/08/13); xt-commerce.com 

   Released under the GNU General Public License 
   -----------------------------------------------------------------------------------------
   Third Party contributions:
   Enable_Disable_Categories 1.3        	Autor: Mikel Williams | mikel@ladykatcostumes.com

   Released under the GNU General Public License 
   ---------------------------------------------------------------------------------------*/
// reset var
$start = microtime();
$box = new vamTemplate;
$box_content = '';
$id = '';

$box->assign('language', $_SESSION['language']);
// set cache ID
if (!CacheCheck()) {
	$cache=false;
	$box->caching = 0;
} else {
	$cache=true;
	$box->caching = 1;
	$box->cache_lifetime = CACHE_LIFETIME;
	$box->cache_modified_check = CACHE_CHECK;
	$cache_id = $_SESSION['language'].$_SESSION['customers_status']['customers_status_id'].$current_category_id;
}

if(!$box->isCached(CURRENT_TEMPLATE.'/boxes/box_manufacturer_left.html', $cache_id) || !$cache){

$box->assign('tpl_path', 'templates/'.CURRENT_TEMPLATE.'/');

if ($_GET['filter_id'] > 0) $_GET['manufacturers_id'] = $_GET['filter_id'];

 $manufacturers_query = "SELECT m.*, mi.* FROM ".TABLE_MANUFACTURERS." as m 
                         left join ".TABLE_MANUFACTURERS_INFO." as mi 
                         on mi.manufacturers_id = m.manufacturers_id 
                         where m.manufacturers_id = '".$_GET['manufacturers_id']."' and mi.languages_id = '".$_SESSION['languages_id']."' 
                         and m.manufacturers_status = 1 order by m.sort_order, m.manufacturers_name asc limit ".MAX_DISPLAY_SEARCH_RESULTS."
                         ";

 // db Cache
 $manufacturers_query = vamDBquery($manufacturers_query);
 $module_content = array();
 $manufacturers_image = '';
 
 
 //$categories_man_query = "select distinct c.categories_id as id, cd.categories_name as name from ".TABLE_PRODUCTS." p, ".TABLE_PRODUCTS_TO_CATEGORIES." p2c, ".TABLE_CATEGORIES." c, ".TABLE_CATEGORIES_DESCRIPTION." cd where p.products_status = '1' and c.categories_status = '1' and p.products_id = p2c.products_id and p2c.categories_id = c.categories_id and p2c.categories_id = cd.categories_id and cd.language_id = '".(int) $_SESSION['languages_id']."' and p.manufacturers_id = '2' order by c.sort_order, cd.categories_name asc";
 //$categories_man_query = vam_db_query($categories_man_query);
 //$categories_man = vam_db_fetch_array($categories_man_query);

 //while ($categories_man = vam_db_fetch_array($categories_man_query)) {
 	
 //echo $categories_man['categories_id'] . ' ff';
 
 //} 
 
$categories_man_query = '';

$manufacturers = vam_db_fetch_array($manufacturers_query,true);


//echo var_dump($manufacturers);

 //while ($manufacturers = vam_db_fetch_array($manufacturers_query,true)) {

   $manufacturers_image = DIR_FS_CATALOG . DIR_WS_IMAGES . $manufacturers['manufacturers_image'];
 
	if(file_exists($manufacturers_image) && is_file($manufacturers_image)) {
		list($width, $height, $type, $attr) = getimagesize($manufacturers_image);
	}
	
		$star_rating = '';
		for($i=0;$i<number_format(vam_get_manufacturer_rating($manufacturers['manufacturers_id']));$i++)	{
		$star_rating .= '<span class="star-rating rating"><i class="star-rating-icon fas fa-star active"></i></span> ';
		}
		//$star_rating = '<span class="rating"><i class="far fa-star"></i></span> ';

$cats = array();
$categories_man_query = vam_db_query("select distinct c.categories_id, c.categories_image, cd.categories_name from ".TABLE_PRODUCTS." p, ".TABLE_PRODUCTS_TO_CATEGORIES." p2c, ".TABLE_CATEGORIES." c, ".TABLE_CATEGORIES_DESCRIPTION." cd where p.products_status = '1' and c.categories_status = '1' and p.products_id = p2c.products_id and p2c.categories_id = c.categories_id and p2c.categories_id = cd.categories_id and cd.language_id = '".(int) $_SESSION['languages_id']."' and p.manufacturers_id = '".$manufacturers['manufacturers_id']."' order by c.sort_order, cd.categories_name asc");

 while ($categories_man = vam_db_fetch_array($categories_man_query)) {
 	
 $cats[] = array(
 
 'CATEGORIES_ID' => $categories_man['categories_id'],
 'CATEGORIES_URL' => vam_href_link(FILENAME_DEFAULT, 'cat='.$categories_man['categories_id']),
 'CATEGORIES_NAME' => $categories_man['categories_name'],
 'CATEGORIES_IMAGE' => $categories_man['categories_image']
 
 );
 
 } 
 		
   $module_content=array('PRODUCTS_ID'  => $manufacturers['manufacturers_id'],
                           'PRODUCTS_NAME'  => $manufacturers['manufacturers_name'],
                           'PRODUCTS_SHORT_DESCRIPTION'  => $manufacturers['manufacturers_description'],
                           'PRODUCTS_IMAGE' => DIR_WS_IMAGES . $manufacturers['manufacturers_image'],
                           'PRODUCTS_IMAGE_WIDTH' => $width,
                           'PRODUCTS_IMAGE_HEIGHT' => $height,
                           'PRODUCTS_LINK'  => vam_href_link(FILENAME_DEFAULT, 'manufacturers_id='.$manufacturers['manufacturers_id']),
                           'CATS'  => $cats,
                           'REVIEWS_TOTAL'=> vam_get_manufacturer_rating_count($manufacturers['manufacturers_id']), 
                           'REVIEWS_TOTAL_RATING'=> vam_get_manufacturer_rating($manufacturers['manufacturers_id']), 
                           'REVIEWS_STAR_RATING'=> $star_rating
                           
   );
 //}
 
//echo var_dump($module_content);

$box->assign('module_data', $module_content);

}

// set cache ID
if (!$cache) {
	$box_manufacturer_info_left = $box->fetch(CURRENT_TEMPLATE.'/boxes/box_manufacturer_left.html');
} else {
	$box_manufacturer_info_left = $box->fetch(CURRENT_TEMPLATE.'/boxes/box_manufacturer_left.html', $cache_id);
}

$module->assign('box_MANUFACTURER_LEFT', $box_manufacturer_info_left);
?>