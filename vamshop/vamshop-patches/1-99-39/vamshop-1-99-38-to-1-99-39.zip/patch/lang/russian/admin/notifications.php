<?php
/* --------------------------------------------------------------
   $Id: faq.php 899 2007-04-02 17:36:57 VaM $

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   --------------------------------------------------------------
   based on: 
   (c) 2003	 osCommerce (latest_news.php,v 1.4 2003/08/14); oscommerce.com

   Released under the GNU General Public License 
   --------------------------------------------------------------*/

define('HEADING_TITLE', 'Уведомления');

define('TABLE_HEADING_NOTIFICATIONS_ID', 'Номер');
define('TABLE_HEADING_NOTIFICATIONS_NAME', 'Имя');
define('TABLE_HEADING_NOTIFICATIONS_EMAIL', 'Email');
define('TABLE_HEADING_NOTIFICATIONS_SUBJECT', 'Тема');
define('TABLE_HEADING_NOTIFICATIONS_STATUS', 'Уведомление прочитано');
define('TABLE_HEADING_NOTIFICATIONS_ACTION', 'Действие');

define('TEXT_NOTIFICATIONS_ITEMS', 'Количество уведомлений:');
define('TEXT_INFO_HEADING_DELETE_ITEM', 'Удалить уведомление');
define('TEXT_DELETE_ITEM_INTRO', 'Вы уверены, что хотите удалить это уведомление?');

define('TEXT_NOTIFICATIONS_SUBJECT', 'Тема');
define('TEXT_NOTIFICATIONS_BODY', 'Сообщение');
define('TEXT_NOTIFICATIONS_NAME', 'Имя');
define('TEXT_NOTIFICATIONS_EMAIL_ADDRESS', 'Email');

define('TEXT_NOTIFICATIONS_DATE', 'Дата');

// Сборка VaM

define('EMPTY_CATEGORY', 'Нет уведомлений');
define('TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS', 'На данный момент ни одного уведомления клиентам не отправлено.');

define('BUTTON_VIEW', 'Смотреть уведомление');


define('BUS_DELETE','Удалить отмеченные');
define('BUS_CUSTOMER','Уведомления ');
define('BUS_DELETE_SUCCESS','удалёны!');
define('BUS_DELETE_WARNING','не удалёны!');
define('BUS_DELETE_CUSTOMERS','Удалить выбранные уведомления');


?>