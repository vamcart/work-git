
ALTER TABLE admin_access ADD products_options INT( 1 ) NOT NULL;
UPDATE admin_access SET products_options = 1 WHERE customers_id = 1 LIMIT 1;

DROP TABLE IF EXISTS products_options_images;
CREATE TABLE products_options_images (
  image_id INT NOT NULL auto_increment,
  products_options_values_id INT NOT NULL ,
  image_nr SMALLINT NOT NULL ,
  image_name VARCHAR( 254 ) NOT NULL ,
  PRIMARY KEY ( image_id )
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

ALTER TABLE products_options ADD products_options_length INT(11) DEFAULT '32' NOT NULL;
ALTER TABLE products_options ADD products_options_size INT(11) DEFAULT '32' NOT NULL;
ALTER TABLE products_options ADD products_options_rows INT(11) DEFAULT '4' NOT NULL;
ALTER TABLE products_options ADD products_options_type INT(11) DEFAULT '1' NOT NULL;

ALTER TABLE products_options_values ADD products_options_values_description TEXT;

ALTER TABLE customers_basket_attributes ADD products_options_value_text TEXT;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES   ('STAY_PAGE_EDIT', 'false', 1, 31, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');
