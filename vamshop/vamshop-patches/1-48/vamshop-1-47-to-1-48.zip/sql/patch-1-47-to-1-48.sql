ALTER TABLE `articles` ADD `articles_page_url` VARCHAR(256) NOT NULL;
ALTER TABLE `topics` ADD `topics_page_url` VARCHAR(256) NOT NULL;
ALTER TABLE `latest_news` ADD `news_page_url` VARCHAR(256) NOT NULL;

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('STORE_TELEPHONE', '', 1, 3, NULL, '', NULL, 'vam_cfg_textarea(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('STORE_ICQ', '', 1, 3, NULL, '', NULL, 'vam_cfg_textarea(');
INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('STORE_SKYPE', '', 1, 3, NULL, '', NULL, 'vam_cfg_textarea(');

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('QUICK_CHECKOUT', 'false',  17, 18, NULL, '', NULL, 'vam_cfg_select_option(array(\'true\', \'false\'),');

INSERT INTO configuration (configuration_key, configuration_value, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MAX_DISPLAY_ARTICLES_CONTENT', '150', 26, 15, 'NULL', '', NULL, NULL);

ALTER TABLE `articles` ADD `sort_order` int(4) NOT NULL DEFAULT '0';
