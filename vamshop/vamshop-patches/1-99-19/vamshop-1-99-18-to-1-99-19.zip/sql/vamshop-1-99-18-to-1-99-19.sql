SET SQL_MODE = "";
ALTER TABLE manufacturers ADD `manufacturers_status` TINYINT(1) NOT NULL DEFAULT '1';